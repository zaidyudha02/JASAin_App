package com.example.data.dao

import androidx.room.*
import com.example.data.entity.Booking
import com.example.data.entity.Message
import com.example.data.entity.ServiceListing
import com.example.data.entity.UserProfile
import com.example.data.entity.JasaInNotification
import kotlinx.coroutines.flow.Flow

@Dao
interface ListingDao {
    @Query("SELECT * FROM service_listings ORDER BY id DESC")
    fun getAllListings(): Flow<List<ServiceListing>>

    @Query("SELECT * FROM service_listings WHERE category = :category ORDER BY id DESC")
    fun getListingsByCategory(category: String): Flow<List<ServiceListing>>

    @Query("SELECT * FROM service_listings WHERE partnerName = :partnerName ORDER BY id DESC")
    fun getListingsByPartner(partnerName: String): Flow<List<ServiceListing>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertListing(listing: ServiceListing)

    @Delete
    suspend fun deleteListing(listing: ServiceListing)

    @Query("DELETE FROM service_listings WHERE id = :id")
    suspend fun deleteListingById(id: Int)
}

@Dao
interface BookingDao {
    @Query("SELECT * FROM bookings ORDER BY id DESC")
    fun getAllBookings(): Flow<List<Booking>>

    @Query("SELECT * FROM bookings WHERE customerName = :customerName ORDER BY id DESC")
    fun getBookingsForCustomer(customerName: String): Flow<List<Booking>>

    @Query("SELECT * FROM bookings WHERE partnerName = :partnerName ORDER BY id DESC")
    fun getBookingsForPartner(partnerName: String): Flow<List<Booking>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: Booking)

    @Query("UPDATE bookings SET status = :status WHERE id = :id")
    suspend fun updateBookingStatus(id: Int, status: String)

    @Query("UPDATE bookings SET rating = :rating, reviewText = :reviewText WHERE id = :id")
    suspend fun updateBookingReview(id: Int, rating: Int, reviewText: String)

    @Query("UPDATE bookings SET partnerResponse = :partnerResponse WHERE id = :id")
    suspend fun updateBookingResponse(id: Int, partnerResponse: String)

    @Delete
    suspend fun deleteBooking(booking: Booking)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE chatPartnerName = :chatPartnerName ORDER BY timestamp ASC")
    fun getMessagesForChat(chatPartnerName: String): Flow<List<Message>>

    @Query("SELECT DISTINCT chatPartnerName FROM messages")
    fun getActiveChatPartners(): Flow<List<String>>

    @Query("SELECT * FROM messages ORDER BY timestamp DESC")
    fun getAllMessages(): Flow<List<Message>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: Message)
}

@Dao
interface ProfileDao {
    @Query("SELECT * FROM user_profile WHERE id = 1")
    fun getProfileFlow(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profile WHERE id = 1")
    suspend fun getProfileDirect(): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: UserProfile)

    @Update
    suspend fun updateProfile(profile: UserProfile)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE recipientName = :recipientName ORDER BY timestamp DESC")
    fun getNotificationsForUser(recipientName: String): Flow<List<JasaInNotification>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: JasaInNotification)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: Int)

    @Query("UPDATE notifications SET isRead = 1 WHERE recipientName = :recipientName")
    suspend fun markAllAsRead(recipientName: String)

    @Query("DELETE FROM notifications WHERE id = :id")
    suspend fun deleteNotification(id: Int)
}
