package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey
    val id: Int = 1,
    val name: String,
    val phone: String,
    val email: String,
    val address: String,
    val balance: Double = 500000.0,
    val currentRole: String = "PELANGGAN",
    val partnerRating: Float = 5.0f,
    val partnerCategory: String? = null,
    val partnerDescription: String? = null,
    val partnerAvailability: String? = null,
    val partnerPortfolioJson: String? = null,
    val isKycVerified: Boolean = false,
    val isRegisteredAsPartner: Boolean = false,
    val kycNik: String? = null,
    val kycRealName: String? = null,
    val profilePictureUri: String? = null
)

@Entity(tableName = "service_listings")
data class ServiceListing(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val category: String,
    val price: Double,
    val priceUnit: String,
    val description: String,
    val partnerName: String,
    val partnerPhone: String,
    val partnerRating: Float = 5.0f,
    val location: String,
    val availability: String = "Pagi, Siang, Sore, Malam"
)

@Entity(tableName = "bookings")
data class Booking(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val serviceListingId: Int,
    val serviceTitle: String,
    val serviceCategory: String,
    val partnerName: String,
    val customerName: String,
    val price: Double,
    val priceUnit: String,
    val bookingDate: String,
    val bookingTime: String,
    val address: String,
    val status: String = "Diajukan",
    val note: String = "",
    val rating: Int? = null,
    val reviewText: String? = null,
    val partnerResponse: String? = null
)

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val chatPartnerName: String,
    val senderRole: String,
    val senderName: String,
    val messageText: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class PaymentTransaction(
    val id: String = "",
    val bookingId: Int = 0,
    val customerName: String = "",
    val partnerName: String = "",
    val serviceTitle: String = "",
    val amount: Double = 0.0,
    val status: String = "", // "HOLD (Escrow)", "RELEASED (Selesai)", "REFUNDED"
    val timestamp: Long = System.currentTimeMillis(),
    val description: String = ""
)

@Entity(tableName = "notifications")
data class JasaInNotification(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val type: String, // "NEW_BOOKING", "STATUS_CHANGE", "NEW_REVIEW"
    val recipientName: String, // For filtering (the partner's or customer's name)
    val bookingId: Int? = null
)

