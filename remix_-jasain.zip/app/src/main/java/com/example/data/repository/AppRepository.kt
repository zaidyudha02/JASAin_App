package com.example.data.repository

import com.example.data.dao.BookingDao
import com.example.data.dao.ListingDao
import com.example.data.dao.MessageDao
import com.example.data.dao.ProfileDao
import com.example.data.dao.NotificationDao
import com.example.data.entity.Booking
import com.example.data.entity.Message
import com.example.data.entity.ServiceListing
import com.example.data.entity.UserProfile
import com.example.data.entity.JasaInNotification
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class AppRepository(
    private val listingDao: ListingDao,
    private val bookingDao: BookingDao,
    private val messageDao: MessageDao,
    private val profileDao: ProfileDao,
    private val notificationDao: NotificationDao
) {
    val allListings: Flow<List<ServiceListing>> = listingDao.getAllListings()
    val allBookings: Flow<List<Booking>> = bookingDao.getAllBookings()
    val allMessagesFlow: Flow<List<Message>> = messageDao.getAllMessages()
    val userProfileFlow: Flow<UserProfile?> = profileDao.getProfileFlow()

    fun getNotificationsForUser(recipientName: String): Flow<List<JasaInNotification>> {
        return notificationDao.getNotificationsForUser(recipientName)
    }

    suspend fun insertNotification(notification: JasaInNotification) {
        notificationDao.insertNotification(notification)
    }

    suspend fun markAsRead(id: Int) {
        notificationDao.markAsRead(id)
    }

    suspend fun markAllAsRead(recipientName: String) {
        notificationDao.markAllAsRead(recipientName)
    }

    suspend fun deleteNotification(id: Int) {
        notificationDao.deleteNotification(id)
    }

    fun getListingsByCategory(category: String): Flow<List<ServiceListing>> {
        return listingDao.getListingsByCategory(category)
    }

    fun getListingsByPartner(partnerName: String): Flow<List<ServiceListing>> {
        return listingDao.getListingsByPartner(partnerName)
    }

    fun getBookingsForCustomer(customerName: String): Flow<List<Booking>> {
        return bookingDao.getBookingsForCustomer(customerName)
    }

    fun getBookingsForPartner(partnerName: String): Flow<List<Booking>> {
        return bookingDao.getBookingsForPartner(partnerName)
    }

    fun getMessagesForChat(chatPartnerName: String): Flow<List<Message>> {
        return messageDao.getMessagesForChat(chatPartnerName)
    }

    fun getActiveChatPartners(): Flow<List<String>> {
        return messageDao.getActiveChatPartners()
    }

    suspend fun getUserProfileDirect(): UserProfile? {
        return profileDao.getProfileDirect()
    }

    suspend fun insertListing(listing: ServiceListing) {
        listingDao.insertListing(listing)
    }

    suspend fun deleteListing(listing: ServiceListing) {
        listingDao.deleteListing(listing)
    }

    suspend fun deleteListingById(id: Int) {
        listingDao.deleteListingById(id)
    }

    suspend fun insertBooking(booking: Booking) {
        bookingDao.insertBooking(booking)
    }

    suspend fun updateBookingStatus(id: Int, status: String) {
        bookingDao.updateBookingStatus(id, status)
    }

    suspend fun updateBookingReview(id: Int, rating: Int, reviewText: String) {
        bookingDao.updateBookingReview(id, rating, reviewText)
    }

    suspend fun updateBookingResponse(id: Int, partnerResponse: String) {
        bookingDao.updateBookingResponse(id, partnerResponse)
    }

    suspend fun deleteBooking(booking: Booking) {
        bookingDao.deleteBooking(booking)
    }

    suspend fun insertMessage(message: Message) {
        messageDao.insertMessage(message)
    }

    suspend fun insertProfile(profile: UserProfile) {
        profileDao.insertProfile(profile)
    }

    suspend fun updateProfile(profile: UserProfile) {
        profileDao.updateProfile(profile)
    }

    suspend fun seedDatabaseIfEmpty() {
        // 1. Seed profile if empty
        val profileDirect = profileDao.getProfileDirect()
        if (profileDirect == null) {
            val defaultProfile = UserProfile(
                id = 1,
                name = "Budi Santoso",
                phone = "081234567890",
                email = "budi.santoso@gmail.com",
                address = "Jl. Ahmad Yani Km. 4.5, Banjarmasin, Kalimantan Selatan",
                balance = 750000.0,
                currentRole = "PELANGGAN",
                partnerRating = 4.8f,
                partnerCategory = "Servis AC & Elektronik",
                partnerDescription = "Spesialis servis AC & peralatan elektronik rumah tangga. Pelayanan cepat, rapi, dan bergaransi 30 hari!"
            )
            profileDao.insertProfile(defaultProfile)
        }

        // 2. Seed listings if empty
        val currentListings = listingDao.getAllListings().first()
        if (currentListings.isEmpty()) {
            val seedListings = listOf(
                ServiceListing(
                    title = "Cuci AC Split Jet Cleaning Premium",
                    category = "Servis AC & Elektronik",
                    price = 75000.0,
                    priceUnit = "unit",
                    description = "Pembersihan AC menyeluruh menggunakan jet pump bertekanan tinggi meliputi evaporator, fan blower, talang air, filter, dan cover body. Menjadikan AC kembali dingin maksimal dan hemat listrik.",
                    partnerName = "Suryajaya Teknik Banjarmasin",
                    partnerPhone = "085512345678",
                    partnerRating = 4.9f,
                    location = "Banjarmasin",
                    availability = "Pagi, Siang"
                ),
                ServiceListing(
                    title = "Deep Home Cleaning Service (Harian)",
                    category = "Kebersihan",
                    price = 50000.0,
                    priceUnit = "jam",
                    description = "Layanan pembersihan rumah tinggal, apartemen, atau ruko privat menyeluruh. Menyapu, mengepel, membersihkan debu meja & lemari, menata tempat tidur, dan merapikan ruangan. Minimal order 2 jam.",
                    partnerName = "Siti Clean Banjarbaru",
                    partnerPhone = "081299998888",
                    partnerRating = 4.8f,
                    location = "Banjarbaru",
                    availability = "Siang, Sore"
                ),
                ServiceListing(
                    title = "Les Privat Matematika & Fisika SMA Terpercaya",
                    category = "Edukasi",
                    price = 120000.0,
                    priceUnit = "sesi",
                    description = "Bimbingan belajar Matematika & Fisika langsung ke rumah untuk jenjang SMA Kelas 10-12. Sangat membantu untuk persiapan ujian sekolah, ulangan harian, dan latihan soal UTBK/SNBT. Metode belajar santai tapi efektif. 1 sesi = 90 menit.",
                    partnerName = "Pak Ahmad Martapura, M.Pd.",
                    partnerPhone = "089876543210",
                    partnerRating = 5.0f,
                    location = "Martapura",
                    availability = "Sore, Malam"
                ),
                ServiceListing(
                    title = "Pijat Tradisional Refleksi Capek & Pegal",
                    category = "Kecantikan & Kesehatan",
                    price = 90000.0,
                    priceUnit = "jam",
                    description = "Jasa pijat panggilan seluruh tubuh untuk meringankan letih, lelah, dan otot kaku setelah beraktivitas seharian. Menggunakan minyak therapy herbal alami berkualitas tinggi. Terapis profesional berpengalaman dan sopan.",
                    partnerName = "Mba Ratih Reflexology Kalsel",
                    partnerPhone = "087711223344",
                    partnerRating = 4.7f,
                    location = "Banjarmasin",
                    availability = "Sore, Malam"
                ),
                ServiceListing(
                    title = "Solusi Atap Bocor & Perbaikan Plafon Rembes kalsel",
                    category = "Pertukangan",
                    price = 180000.0,
                    priceUnit = "m2",
                    description = "Menangani kebocoran atap genteng, beton, asbes, seng, waterproofing dak beton, dan penggantian plafon gypsum yang lapuk akibat rembesan air hujan. Konsultasi gratis dan garansi pengerjaan rapi.",
                    partnerName = "CV Mandiri Sejahtera Pelaihari",
                    partnerPhone = "0811987654",
                    partnerRating = 4.6f,
                    location = "Pelaihari",
                    availability = "Pagi, Siang"
                ),
                ServiceListing(
                    title = "Reparasi Mesin Cuci & Kulkas Panggilan Rumah",
                    category = "Servis AC & Elektronik",
                    price = 150000.0,
                    priceUnit = "kunjungan",
                    description = "Mengatasi mesin cuci macet, bocor air, berisik tidak berputar, atau kulkas tidak dingin, mati total, kompresor mati. Biaya kunjungan sudah termasuk pengecekan menyeluruh. Sparepart bergaransi resmi.",
                    partnerName = "Hadi Elektronik Kandangan",
                    partnerPhone = "081344556677",
                    partnerRating = 4.8f,
                    location = "Kandangan",
                    availability = "Pagi, Siang, Sore"
                ),
                ServiceListing(
                    title = "Jasa Hair & Makeup Artist Wisuda (MUA Banjarmasin)",
                    category = "Kecantikan & Kesehatan",
                    price = 250000.0,
                    priceUnit = "kegiatan",
                    description = "Jasa rias wajah custom untuk wisuda, lamaran, bridesmaid, photoshoot, maupun pesta kasual. Menggunakan kosmetik premium berstandar aman dan flawless look yang tahan seharian. Sudah termasuk hairdo/hijab do.",
                    partnerName = "Chintya MUA Banjarbaru",
                    partnerPhone = "085290901010",
                    partnerRating = 4.9f,
                    location = "Banjarbaru",
                    availability = "Pagi, Siang, Sore"
                ),
                ServiceListing(
                    title = "Bimbingan Belajar Bahasa Inggris Percakapan Dasar",
                    category = "Edukasi",
                    price = 100000.0,
                    priceUnit = "sesi",
                    description = "Fokus melatih kelancaran speaking, pronunciation, dan kepercayaandirian berbicara bahasa Inggris dalam kehidupan sehari-hari maupun profesional kerja. Cocok untuk pemula dan menengah. 1 sesi = 90 menit.",
                    partnerName = "Miss Emily Courses Bjm",
                    partnerPhone = "081900221144",
                    partnerRating = 4.9f,
                    location = "Banjarmasin",
                    availability = "Pagi, Sore, Malam"
                )
            )
            for (listing in seedListings) {
                listingDao.insertListing(listing)
            }
        }

        // 3. Seed bookings if empty
        val currentBookings = bookingDao.getAllBookings().first()
        if (currentBookings.isEmpty()) {
            val seedBookings = listOf(
                Booking(
                    serviceListingId = 1,
                    serviceTitle = "Cuci AC Split Jet Cleaning Premium",
                    serviceCategory = "Servis AC & Elektronik",
                    partnerName = "Suryajaya Teknik Banjarmasin",
                    customerName = "Budi Santoso",
                    price = 75000.0,
                    priceUnit = "unit",
                    bookingDate = "2026-06-18",
                    bookingTime = "10:00",
                    address = "Jl. Ahmad Yani Km. 4.5, Banjarmasin, Kalimantan Selatan",
                    status = "Selesai",
                    note = "Dua unit AC Panasonic diletakkan di ruang tamu dan kamar tidur.",
                    rating = 5,
                    reviewText = "Sangat puas dengan hasilnya! AC kembali dingin dan harum. Mas Suryajaya bekerja dengan rapi serta tepat waktu.",
                    partnerResponse = "Terima kasih pak Budi atas ulasan dan kepercayaannya! Ditunggu pemesanan berikutnya."
                ),
                Booking(
                    serviceListingId = 2,
                    serviceTitle = "Deep Home Cleaning Service (Harian)",
                    serviceCategory = "Kebersihan",
                    partnerName = "Siti Clean Banjarbaru",
                    customerName = "Budi Santoso",
                    price = 100000.0, // 2 hours
                    priceUnit = "2 jam",
                    bookingDate = "2026-06-22",
                    bookingTime = "09:00",
                    address = "Jl. Ahmad Yani Km. 4.5, Banjarmasin, Kalimantan Selatan",
                    status = "Diajukan",
                    note = "Tolong bersihkan sela-sela lemari pakaian juga ya kak."
                )
            )
            for (booking in seedBookings) {
                bookingDao.insertBooking(booking)
            }
        }

        // 4. Seed Messages if empty
        val currentMessages = messageDao.getAllMessages().first()
        if (currentMessages.isEmpty()) {
            val seedMessages = listOf(
                Message(
                    chatPartnerName = "JASAin-AI",
                    senderRole = "AI",
                    senderName = "JASAin-AI",
                    messageText = "Halo kak Budi! Saya JASAin-AI, asisten virtual Anda. Ada yang bisa saya bantu hari ini terkait layanan jasa kami di JASAin?",
                    timestamp = System.currentTimeMillis() - 1000000
                ),
                Message(
                    chatPartnerName = "Suryajaya Teknik",
                    senderRole = "PELANGGAN",
                    senderName = "Budi Santoso",
                    messageText = "Halo kak Suryajaya, untuk pencucian AC di daerah Senayan apa bisa besok lusa pagi?",
                    timestamp = System.currentTimeMillis() - 7200000 // 2 hours ago
                ),
                Message(
                    chatPartnerName = "Suryajaya Teknik",
                    senderRole = "MITRA",
                    senderName = "Suryajaya Teknik",
                    messageText = "Halo selamat siang pak Budi, tentu bisa sekali. Jam 09:00 atau jam 11:00 ya pak biar dijadwalkan?",
                    timestamp = System.currentTimeMillis() - 3600000 // 1 hour ago
                ),
                Message(
                    chatPartnerName = "Suryajaya Teknik",
                    senderRole = "PELANGGAN",
                    senderName = "Budi Santoso",
                    messageText = "Jam 10:00 siang saja ya kak, terima kasih banyak sebelumnya.",
                    timestamp = System.currentTimeMillis() - 1800000 // 30 mins ago
                ),
                Message(
                    chatPartnerName = "Siti Clean & Rapih",
                    senderRole = "PELANGGAN",
                    senderName = "Budi Santoso",
                    messageText = "Halo kak Siti, untuk order harian pembersihan rumah besok tanggal 22 Juni pagi jam 9 pagi siap kak?",
                    timestamp = System.currentTimeMillis() - 60000 // 1 min ago
                )
            )
            for (msg in seedMessages) {
                messageDao.insertMessage(msg)
            }
        }
    }
}
