package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Column
import androidx.lifecycle.ViewModelProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.CompositionLocalProvider
import com.example.data.db.AppDatabase
import com.example.data.repository.AppRepository
import com.example.ui.components.JasaInBottomNavBar
import com.example.ui.components.LocalThemeToggle
import com.example.ui.components.LocalIsDarkState
import com.example.ui.components.LocalIsEnglishState
import com.example.ui.components.LocalLanguageToggle
import com.example.ui.components.LocalUserRole
import com.example.ui.components.LocalUserRoleToggle
import com.example.ui.screen.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.JasaInViewModel
import com.example.ui.viewmodel.JasaInViewModelFactory
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.example.ui.components.formatRupiah
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Divider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.style.TextAlign

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Firebase early to prevent Realtime Listeners from crashing at startup
        try {
            if (FirebaseApp.getApps(applicationContext).isEmpty()) {
                val options = FirebaseOptions.Builder()
                    .setApplicationId("1:4493191c-ed6e-4b4f-979a-106169c99f72:android:6ea2783850123acf0e")
                    .setApiKey("AIzaSyB-fakeKeyWithFirebaseForResiliency-1234")
                    .setProjectId("jasain-aistudio")
                    .build()
                FirebaseApp.initializeApp(applicationContext, options)
                android.util.Log.d("FirebaseInit", "Early FirebaseApp initialization inside MainActivity successful.")
            }
        } catch (e: Exception) {
            android.util.Log.e("FirebaseInit", "Early FirebaseApp initialization in MainActivity failed: ${e.message}")
        }

        // Core Database, Repository & ViewModel Factory bindings
        val database = AppDatabase.getDatabase(applicationContext)
        val repository = AppRepository(
            database.listingDao(),
            database.bookingDao(),
            database.messageDao(),
            database.profileDao(),
            database.notificationDao()
        )
        val viewModelFactory = JasaInViewModelFactory(repository)
        val viewModel: JasaInViewModel = ViewModelProvider(this, viewModelFactory)[JasaInViewModel::class.java]
        viewModel.initFirebaseApp(applicationContext)

        setContent {
            val isDark by viewModel.isDarkMode.collectAsState()
            val isEnglish by viewModel.isEnglish.collectAsState()
            val profile by viewModel.userProfile.collectAsState()
            val currentRole = profile?.currentRole ?: "PELANGGAN"

            CompositionLocalProvider(
                LocalThemeToggle provides { viewModel.toggleDarkMode() },
                LocalIsDarkState provides isDark,
                LocalIsEnglishState provides isEnglish,
                LocalLanguageToggle provides { viewModel.toggleLanguage() },
                LocalUserRole provides currentRole,
                LocalUserRoleToggle provides { viewModel.toggleUserMode() }
            ) {
                MyApplicationTheme(darkTheme = isDark) {
                    MainAppScreenContent(viewModel)
                }
            }
        }
    }
}

@Composable
fun MainAppScreenContent(viewModel: JasaInViewModel) {
    val activeScreen = viewModel.activeScreen

    // Decide if bottom navigation should be visible on active screen
    val showBottomBar = when (activeScreen) {
        "LOGIN", "PELANGGAN_CHAT_DETAIL", "MITRA_CHAT_DETAIL", "PELANGGAN_BOOKING_FORM", "PELANGGAN_PARTNER_REGISTRATION" -> false
        else -> true
    }

    val reviewPartnerName = viewModel.reviewPartnerName
    if (reviewPartnerName != null) {
        ServiceReviewsDialog(
            partnerName = reviewPartnerName,
            onDismiss = { viewModel.closeReviews() },
            viewModel = viewModel
        )
    }

    val bookingModalListing = viewModel.bookingModalListing
    if (bookingModalListing != null) {
        BookingModal(
            listing = bookingModalListing,
            viewModel = viewModel,
            onDismiss = { viewModel.bookingModalListing = null }
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            bottomBar = {
                if (showBottomBar) {
                    JasaInBottomNavBar(
                        activeScreen = activeScreen,
                        onNavigate = { viewModel.navigateTo(it) }
                    )
                }
            }
        ) { innerPadding ->
            // Animated transition for premium look and feel
            AnimatedContent(
                targetState = activeScreen,
                transitionSpec = {
                    fadeIn(animationSpec = spring()) togetherWith fadeOut(animationSpec = spring())
                },
                modifier = Modifier.padding(innerPadding),
                label = "screen_routing_transition"
            ) { screen ->
                when (screen) {
                    "LOGIN" -> AuthScreen(viewModel)
                    "PELANGGAN_HOME" -> PelangganHomeScreen(viewModel)
                    "PELANGGAN_DETAIL" -> PelangganDetailScreen(viewModel)
                    "PELANGGAN_BOOKING_FORM" -> PelangganBookingFormScreen(viewModel)
                    "PELANGGAN_TRANSAKSI" -> PelangganTransaksiScreen(viewModel)
                    "PELANGGAN_CHAT_LIST" -> PelangganChatListScreen(viewModel)
                    "PELANGGAN_CHAT_DETAIL" -> PelangganChatDetailScreen(viewModel)
                    "PELANGGAN_PROFILE" -> PelangganProfileScreen(viewModel)
                    "PELANGGAN_PARTNER_REGISTRATION" -> PelangganPartnerRegistrationScreen(viewModel)
                    "PELANGGAN_VISION" -> PelangganVisionScreen(viewModel)

                    // Mitra Screens
                    "MITRA_HOME" -> MitraHomeScreen(viewModel)
                    "MITRA_MY_LISTINGS" -> MitraMyListingsScreen(viewModel)
                    "MITRA_ADD_LISTING" -> MitraAddListingScreen(viewModel)
                    "MITRA_CHAT_LIST" -> PelangganChatListScreen(viewModel) // Shares unified chat list screen
                    "MITRA_CHAT_DETAIL" -> PelangganChatDetailScreen(viewModel) // Shares unified chat detail
                    "MITRA_PROFILE" -> MitraProfileScreen(viewModel)
                }
            }
        }

        if (viewModel.isGlobalLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .testTag("global_loading_overlay")
                    .pointerInput(Unit) {},
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    modifier = Modifier.padding(32.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            strokeWidth = 4.dp,
                            modifier = Modifier.testTag("global_loading_indicator")
                        )
                        Text(
                            text = "Mohon Tunggu...",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        val toastMessage = viewModel.toastMessage
        val toastType = viewModel.toastType
        AnimatedVisibility(
            visible = toastMessage != null,
            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 80.dp, start = 16.dp, end = 16.dp)
                .fillMaxWidth()
        ) {
            if (toastMessage != null) {
                val (bgColor, icon, iconColor) = when (toastType) {
                    "ERROR" -> Triple(
                        MaterialTheme.colorScheme.errorContainer,
                        Icons.Filled.Warning,
                        MaterialTheme.colorScheme.onErrorContainer
                    )
                    "INFO" -> Triple(
                        MaterialTheme.colorScheme.secondaryContainer,
                        Icons.Filled.Info,
                        MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    else -> Triple(
                        MaterialTheme.colorScheme.primaryContainer,
                        Icons.Filled.CheckCircle,
                        MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .testTag("global_toast_notification"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = bgColor),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(iconColor.copy(alpha = 0.12f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = "Toast Status",
                                tint = iconColor,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Text(
                            text = toastMessage,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = iconColor,
                            modifier = Modifier.weight(1f)
                        )

                        IconButton(
                            onClick = { viewModel.dismissToast() },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Close Toast",
                                modifier = Modifier.size(16.dp),
                                tint = iconColor.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BookingModal(
    listing: com.example.data.entity.ServiceListing,
    viewModel: JasaInViewModel,
    onDismiss: () -> Unit
) {
    val userProfile by viewModel.userProfile.collectAsState()
    
    var date by remember { mutableStateOf("25-06-2026") }
    var time by remember { mutableStateOf("10:00") }
    var address by remember { mutableStateOf(userProfile?.address ?: "") }
    var specialInstructions by remember { mutableStateOf("") }
    
    var errorMsg by remember { mutableStateOf<String?>(null) }
    
    var isBookingSubmitted by remember { mutableStateOf(false) }

    val dateError = if (date.isNotEmpty() || isBookingSubmitted) {
        if (date.isBlank()) {
            "Tanggal pelaksanaan wajib diisi!"
        } else if (!date.trim().matches(Regex("\\d{2}-\\d{2}-\\d{4}"))) {
            "Format tanggal harus DD-MM-YYYY (contoh: 25-06-2026)!"
        } else {
            null
        }
    } else null

    val timeError = if (time.isNotEmpty() || isBookingSubmitted) {
        if (time.isBlank()) {
            "Jam pelaksanaan wajib diisi!"
        } else if (!time.trim().matches(Regex("\\d{2}:\\d{2}"))) {
            "Format waktu harus HH:MM (contoh: 10:00)!"
        } else {
            null
        }
    } else null

    val addressError = if (address.isNotEmpty() || isBookingSubmitted) {
        if (address.isBlank()) {
            "Alamat lengkap wajib diisi!"
        } else if (address.trim().length < 10) {
            "Alamat terlalu pendek, mohon berikan alamat lengkap (min 10 karakter)!"
        } else {
            null
        }
    } else null
    
    val balance = userProfile?.balance ?: 500000.0
    val hasEnoughFunds = balance >= listing.price
    
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("booking_modal_root"),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Booking Layanan Jasa",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Tutup Modal"
                        )
                    }
                }
                
                // Listing Card Details
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = listing.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Oleh: ${listing.partnerName}",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                        Text(
                            text = formatRupiah(listing.price),
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 16.sp
                        )
                    }
                }
                
                // Form Inputs
                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it; errorMsg = null },
                    label = { Text("Tanggal Pelaksanaan") },
                    placeholder = { Text("Format: DD-MM-YYYY") },
                    leadingIcon = { Icon(Icons.Default.CalendarToday, null) },
                    isError = dateError != null,
                    modifier = Modifier.fillMaxWidth().testTag("modal_book_date_input"),
                    singleLine = true
                )
                if (dateError != null) {
                    Text(
                        text = dateError,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 11.sp,
                        modifier = Modifier.fillMaxWidth().padding(start = 4.dp, top = 2.dp)
                    )
                }
                
                OutlinedTextField(
                    value = time,
                    onValueChange = { time = it; errorMsg = null },
                    label = { Text("Jam Pelaksanaan") },
                    placeholder = { Text("misal: 10:00 WIB") },
                    leadingIcon = { Icon(Icons.Default.AccessTime, null) },
                    isError = timeError != null,
                    modifier = Modifier.fillMaxWidth().testTag("modal_book_time_input"),
                    singleLine = true
                )
                if (timeError != null) {
                    Text(
                        text = timeError,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 11.sp,
                        modifier = Modifier.fillMaxWidth().padding(start = 4.dp, top = 2.dp)
                    )
                }
                
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it; errorMsg = null },
                    label = { Text("Alamat Lengkap") },
                    leadingIcon = { Icon(Icons.Default.PinDrop, null) },
                    isError = addressError != null,
                    modifier = Modifier.fillMaxWidth().testTag("modal_book_address_input")
                )
                if (addressError != null) {
                    Text(
                        text = addressError,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 11.sp,
                        modifier = Modifier.fillMaxWidth().padding(start = 4.dp, top = 2.dp)
                    )
                }
                
                OutlinedTextField(
                    value = specialInstructions,
                    onValueChange = { specialInstructions = it },
                    label = { Text("Instruksi Khusus / Catatan") },
                    leadingIcon = { Icon(Icons.Default.NoteAdd, null) },
                    placeholder = { Text("misal: Pintu pagar hitam, mohon bawa tangga lipat.") },
                    modifier = Modifier.fillMaxWidth().testTag("modal_book_instructions_input")
                )
                
                // Saldo check
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (hasEnoughFunds) {
                            Color(0xFFE8F5E9).copy(alpha = 0.5f)
                        } else {
                            MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)
                        }
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Saldo JASApay Anda:", fontSize = 11.sp)
                            Text(formatRupiah(balance), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Biaya Jasa:", fontSize = 11.sp)
                            Text(formatRupiah(listing.price), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                        
                        Divider(color = Color.LightGray.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 4.dp))
                        
                        if (!hasEnoughFunds) {
                            Text(
                                text = "Saldo kurang! Silakan top up terlebih dahulu.",
                                color = MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        } else {
                            Text(
                                text = "Saldo mencukupi untuk Pembayaran Escrow JASApay.",
                                color = Color(0xFF2E7D32),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
                
                val currentError = errorMsg
                if (currentError != null) {
                    Text(
                        text = currentError,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
                
                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Batal")
                    }
                    
                    Button(
                        onClick = {
                            isBookingSubmitted = true
                            val hasErrors = dateError != null || timeError != null || addressError != null
                            if (hasErrors) {
                                errorMsg = "Mohon perbaiki kesalahan input pada form booking!"
                            } else if (!hasEnoughFunds) {
                                errorMsg = "Saldo JASApay Anda tidak mencukupi!"
                            } else {
                                viewModel.createBooking(listing, date.trim(), time.trim(), address.trim(), specialInstructions.trim())
                                onDismiss()
                            }
                        },
                        modifier = Modifier.weight(1.5f).testTag("modal_book_submit_button"),
                        enabled = hasEnoughFunds,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Konfirmasi", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
