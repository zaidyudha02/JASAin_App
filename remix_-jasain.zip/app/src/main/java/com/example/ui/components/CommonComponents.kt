package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.entity.ServiceListing
import com.example.data.entity.JasaInNotification
import com.example.ui.viewmodel.JasaInViewModel
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.window.Dialog
import java.text.NumberFormat
import java.util.*

val JasaInAccent = androidx.compose.ui.graphics.Color(0xFFFFB300)
val JasaInPrimary = androidx.compose.ui.graphics.Color(0xFF006A60)

val LocalThemeToggle = staticCompositionLocalOf<() -> Unit> { {} }
val LocalIsDarkState = staticCompositionLocalOf { false }
val LocalIsEnglishState = staticCompositionLocalOf { false }
val LocalLanguageToggle = staticCompositionLocalOf<() -> Unit> { {} }
val LocalUserRole = staticCompositionLocalOf { "PELANGGAN" }
val LocalUserRoleToggle = staticCompositionLocalOf<() -> Unit> { {} }

@Composable
fun JasaInTopAppBar(
    title: String,
    onMenuClick: (() -> Unit)? = null,
    onBackClick: (() -> Unit)? = null,
    showModeTabs: Boolean = false,
    viewModel: JasaInViewModel? = null,
    actions: @Composable (RowScope.() -> Unit)? = null
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp
    ) {
        Column(
            modifier = Modifier
                .statusBarsPadding()
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (onBackClick != null) {
                        IconButton(
                            onClick = onBackClick,
                            modifier = Modifier.testTag("appbar_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Kembali",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    } else if (onMenuClick != null) {
                        IconButton(
                            onClick = onMenuClick,
                            modifier = Modifier.testTag("appbar_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Menu Utama",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    Text(
                        text = title,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.testTag("appbar_title")
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (actions != null) {
                        actions()
                    }

                    if (viewModel != null) {
                        val notifications by viewModel.notifications.collectAsState()
                        val unreadCount = notifications.count { !it.isRead }
                        var showNotifDialog by remember { androidx.compose.runtime.mutableStateOf(false) }

                        IconButton(
                            onClick = { showNotifDialog = true },
                            modifier = Modifier.testTag("appbar_notification_button")
                        ) {
                            BadgedBox(
                                badge = {
                                    if (unreadCount > 0) {
                                        Badge {
                                            Text(
                                                text = unreadCount.toString(),
                                                modifier = Modifier.testTag("notification_badge_count")
                                            )
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (unreadCount > 0) Icons.Default.NotificationsActive else Icons.Default.Notifications,
                                    contentDescription = "Notifikasi",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        if (showNotifDialog) {
                            NotificationsDialog(
                                viewModel = viewModel,
                                onDismiss = { showNotifDialog = false }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SmartArAiButton(
    selected: Boolean,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ar_ai_breath")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    val borderColors = listOf(
        MaterialTheme.colorScheme.primary,
        MaterialTheme.colorScheme.secondary,
        JasaInAccent
    )

    Box(
        modifier = Modifier
            .size(72.dp)
            .clickable(
                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .testTag("nav_smart_ar_ai"),
        contentAlignment = Alignment.Center
    ) {
        // Glowing background effect
        Box(
            modifier = Modifier
                .size(54.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    alpha = glowAlpha
                }
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            JasaInAccent.copy(alpha = 0.8f),
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                            Color.Transparent
                        )
                    ),
                    shape = CircleShape
                )
        )

        // Main circular button with Camera Logo
        Box(
            modifier = Modifier
                .size(48.dp)
                .graphicsLayer {
                    scaleX = if (selected) 1.1f else 1.0f
                    scaleY = if (selected) 1.1f else 1.0f
                }
                .background(
                    brush = Brush.linearGradient(
                        colors = if (selected) {
                            listOf(JasaInAccent, MaterialTheme.colorScheme.primary)
                        } else {
                            listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary)
                        }
                    ),
                    shape = CircleShape
                )
                .border(
                    width = 2.dp,
                    brush = Brush.sweepGradient(borderColors),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.PhotoCamera,
                contentDescription = "Smart AR AI",
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun JasaInBottomNavBar(
    activeScreen: String,
    onNavigate: (String) -> Unit
) {
    val currentRole = LocalUserRole.current
    val isMitra = currentRole == "MITRA"

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 16.dp
    ) {
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Row(
                modifier = Modifier
                    .navigationBarsPadding()
                    .widthIn(max = 600.dp)
                    .fillMaxWidth()
                    .height(72.dp)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                if (!isMitra) {
                    // Pelanggan Navigation Tabs
                    NavBarItem(
                        icon = Icons.Default.Home,
                        label = "Beranda",
                        selected = activeScreen == "PELANGGAN_HOME" || activeScreen == "PELANGGAN_DETAIL" || activeScreen == "PELANGGAN_BOOKING_FORM",
                        onClick = { onNavigate("PELANGGAN_HOME") },
                        tag = "nav_pelanggan_home"
                    )
                    NavBarItem(
                        icon = Icons.Default.List,
                        label = "Transaksi",
                        selected = activeScreen == "PELANGGAN_TRANSAKSI",
                        onClick = { onNavigate("PELANGGAN_TRANSAKSI") },
                        tag = "nav_pelanggan_trx"
                    )
                    SmartArAiButton(
                        selected = activeScreen == "PELANGGAN_VISION",
                        onClick = { onNavigate("PELANGGAN_VISION") }
                    )
                    NavBarItem(
                        icon = Icons.Default.Email,
                        label = "Pesan",
                        selected = activeScreen == "PELANGGAN_CHAT_LIST" || activeScreen == "PELANGGAN_CHAT_DETAIL",
                        onClick = { onNavigate("PELANGGAN_CHAT_LIST") },
                        tag = "nav_pelanggan_chat"
                    )
                    NavBarItem(
                        icon = Icons.Default.Person,
                        label = "Profil",
                        selected = activeScreen == "PELANGGAN_PROFILE",
                        onClick = { onNavigate("PELANGGAN_PROFILE") },
                        tag = "nav_pelanggan_profile"
                    )
                } else {
                    // Mitra Navigation Tabs
                    NavBarItem(
                        icon = Icons.Default.Home,
                        label = "Dashboard",
                        selected = activeScreen == "MITRA_HOME",
                        onClick = { onNavigate("MITRA_HOME") },
                        tag = "nav_mitra_home"
                    )
                    NavBarItem(
                        icon = Icons.Default.List,
                        label = "Jasa Saya",
                        selected = activeScreen == "MITRA_MY_LISTINGS" || activeScreen == "MITRA_ADD_LISTING",
                        onClick = { onNavigate("MITRA_MY_LISTINGS") },
                        tag = "nav_mitra_listings"
                    )
                    SmartArAiButton(
                        selected = activeScreen == "PELANGGAN_VISION",
                        onClick = { onNavigate("PELANGGAN_VISION") }
                    )
                    NavBarItem(
                        icon = Icons.Default.Email,
                        label = "Chat Mitra",
                        selected = activeScreen == "MITRA_CHAT_LIST" || activeScreen == "MITRA_CHAT_DETAIL",
                        onClick = { onNavigate("MITRA_CHAT_LIST") },
                        tag = "nav_mitra_chat"
                    )
                    NavBarItem(
                        icon = Icons.Default.Settings,
                        label = "Profil Mitra",
                        selected = activeScreen == "MITRA_PROFILE",
                        onClick = { onNavigate("MITRA_PROFILE") },
                        tag = "nav_mitra_profile"
                    )
                }
            }
        }
    }
}

@Composable
fun NavBarItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    val color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
    val bgSelectColor = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent

    Column(
        modifier = Modifier
            .testTag(tag)
            .width(76.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(46.dp, 28.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(bgSelectColor),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = color
        )
    }
}

// Helpers
fun formatRupiah(amount: Double): String {
    val format = NumberFormat.getCurrencyInstance(Locale("in", "ID"))
    return format.format(amount).replace("Rp", "Rp ").substringBefore(",")
}

@Composable
fun CategoryIconMapper(category: String, modifier: Modifier = Modifier, tint: Color = Color.White) {
    val icon = when (category) {
        "Semua" -> Icons.Default.Apps
        "Favorit" -> Icons.Default.Favorite
        "Rumah Tangga", "Kebersihan", "Pertukangan", "Kebersihan & Laundry", "Pertukangan & Renovasi" -> Icons.Default.CleaningServices
        "Elektronik", "Servis AC & Elektronik" -> Icons.Default.Air
        "Edukasi", "Les Privat & Konsultasi" -> Icons.Default.School
        "Kecantikan & Kesehatan", "Kecantikan, Pijat & Spa", "Layanan Kesehatan" -> Icons.Default.Spa
        "Katering & Konsumsi" -> Icons.Default.LocalDining
        "Keamanan & Supir" -> Icons.Default.LocalTaxi
        "Event & Media" -> Icons.Default.CameraAlt
        else -> Icons.Default.Construction
    }

    Icon(
        imageVector = icon,
        contentDescription = category,
        modifier = modifier,
        tint = tint
    )
}

fun getCategoryColor(category: String): Color {
    return when (category) {
        "Semua" -> Color(0xFF6366F1) // Indigo Accent
        "Favorit" -> Color(0xFFE11D48) // Rose Red Accent
        "Rumah Tangga", "Kebersihan", "Pertukangan", "Kebersihan & Laundry", "Pertukangan & Renovasi" -> Color(0xFF006A60) // Primary Teal
        "Elektronik", "Servis AC & Elektronik" -> Color(0xFF0284C7) // Sky Blue Accent
        "Edukasi", "Les Privat & Konsultasi" -> Color(0xFFE0533C) // Cozy Coral Accent
        "Kecantikan & Kesehatan", "Kecantikan, Pijat & Spa", "Layanan Kesehatan" -> Color(0xFFD97706) // Warm Ochre
        "Katering & Konsumsi" -> Color(0xFFB12704)
        "Keamanan & Supir" -> Color(0xFF4A5568)
        "Event & Media" -> Color(0xFF805AD5)
        else -> Color(0xFF3F4947) // Soft Slate Gray
    }
}

fun getCategoryDrawableId(category: String?): Int {
    return when (category) {
        "Rumah Tangga", "Kebersihan", "Pertukangan", "Kebersihan & Laundry", "Pertukangan & Renovasi" -> R.drawable.cat_rumah_tangga_1782034913734
        "Elektronik", "Servis AC & Elektronik" -> R.drawable.cat_elektronik_1782034929844
        "Edukasi", "Les Privat & Konsultasi" -> R.drawable.cat_edukasi_1782034947019
        "Kecantikan & Kesehatan", "Kecantikan, Pijat & Spa", "Layanan Kesehatan" -> R.drawable.cat_kesehatan_1782034964081
        else -> R.drawable.cat_rumah_tangga_1782034913734
    }
}

@Composable
fun StarRatingBar(rating: Float, modifier: Modifier = Modifier) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
    ) {
        Icon(
            imageVector = Icons.Default.Star,
            contentDescription = "Rating $rating",
            tint = JasaInAccent,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = rating.toString(),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun UserRoleToggle(
    modifier: Modifier = Modifier,
    currentRole: String = LocalUserRole.current, // "PELANGGAN" or "MITRA"
    onToggle: () -> Unit = LocalUserRoleToggle.current,
    isPrimaryBackground: Boolean = false
) {
    val isMitra = currentRole == "MITRA"
    val isEnglish = LocalIsEnglishState.current

    // Colors adjusted for background context
    val containerBg = if (isPrimaryBackground) {
        Color.White.copy(alpha = 0.12f)
    } else {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
    }

    val unselectedColor = if (isPrimaryBackground) {
        Color.White.copy(alpha = 0.7f)
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
    }

    val borderStroke = if (isPrimaryBackground) {
        BorderStroke(1.dp, Color.White.copy(alpha = 0.18f))
    } else {
        BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(containerBg)
            .border(borderStroke, RoundedCornerShape(20.dp))
            .clickable { onToggle() }
            .padding(2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Pelanggan (Customer) option
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(
                    if (!isMitra) {
                        if (isPrimaryBackground) Color.White else MaterialTheme.colorScheme.primary
                    } else {
                        Color.Transparent
                    }
                )
                .padding(horizontal = 10.dp, vertical = 5.dp)
                .testTag("toggle_customer_mode"),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = if (!isMitra) {
                        if (isPrimaryBackground) MaterialTheme.colorScheme.primary else Color.White
                    } else {
                        unselectedColor
                    },
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isEnglish) "Customer" else "Pelanggan",
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = if (!isMitra) {
                        if (isPrimaryBackground) MaterialTheme.colorScheme.primary else Color.White
                    } else {
                        unselectedColor
                    }
                )
            }
        }

        // Mitra (Partner) option
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(
                    if (isMitra) {
                        if (isPrimaryBackground) Color.White else MaterialTheme.colorScheme.secondary
                    } else {
                        Color.Transparent
                    }
                )
                .padding(horizontal = 10.dp, vertical = 5.dp)
                .testTag("toggle_partner_mode"),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Storefront,
                    contentDescription = null,
                    tint = if (isMitra) {
                        if (isPrimaryBackground) MaterialTheme.colorScheme.primary else Color.White
                    } else {
                        unselectedColor
                    },
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isEnglish) "Partner" else "Mitra",
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = if (isMitra) {
                        if (isPrimaryBackground) MaterialTheme.colorScheme.primary else Color.White
                    } else {
                        unselectedColor
                    }
                )
            }
        }
    }
}

@Composable
fun AppModeTabRow(
    modifier: Modifier = Modifier,
    currentRole: String = LocalUserRole.current,
    onToggle: () -> Unit = LocalUserRoleToggle.current,
    isInverse: Boolean = false
) {
    val isMitra = currentRole == "MITRA"
    val isEnglish = LocalIsEnglishState.current
    
    val containerColor = if (isInverse) {
        Color.White.copy(alpha = 0.15f)
    } else {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    }
    
    val activeTabColor = if (isInverse) {
        Color.White
    } else {
        MaterialTheme.colorScheme.primary
    }
    
    val activeTextColor = if (isInverse) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.onPrimary
    }
    
    val inactiveTextColor = if (isInverse) {
        Color.White.copy(alpha = 0.8f)
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(containerColor)
            .padding(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Tab 1: Pelanggan
        Box(
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(if (!isMitra) activeTabColor else Color.Transparent)
                .clickable { if (isMitra) onToggle() }
                .padding(vertical = 10.dp)
                .testTag("app_mode_tab_pelanggan"),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = if (!isMitra) activeTextColor else inactiveTextColor,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isEnglish) "Customer Mode" else "Mode Pelanggan",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = if (!isMitra) activeTextColor else inactiveTextColor
                )
            }
        }

        // Tab 2: Mitra
        Box(
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(if (isMitra) activeTabColor else Color.Transparent)
                .clickable { if (!isMitra) onToggle() }
                .padding(vertical = 10.dp)
                .testTag("app_mode_tab_mitra"),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Storefront,
                    contentDescription = null,
                    tint = if (isMitra) activeTextColor else inactiveTextColor,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isEnglish) "Partner Mode" else "Mode Mitra",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = if (isMitra) activeTextColor else inactiveTextColor
                )
            }
        }
    }
}

@Composable
fun ServiceCategoryGrid(
    viewModel: JasaInViewModel,
    modifier: Modifier = Modifier
) {
    val listings by viewModel.allListings.collectAsState()
    val activeRole = LocalUserRole.current
    val activeCategory by viewModel.selectedCategory.collectAsState()
    val profile by viewModel.userProfile.collectAsState()
    
    val currentPartnerName = profile?.name ?: "Budi Santoso"
    
    val categories = listOf(
        "Rumah Tangga",
        "Elektronik",
        "Edukasi",
        "Kecantikan & Kesehatan"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Category,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                val isEnglish = LocalIsEnglishState.current
                val headerText = if (activeRole == "MITRA") {
                    if (isEnglish) "My Service Categories" else "Kategori Layanan Mitra Saya"
                } else {
                    if (isEnglish) "Explore Service Categories" else "Eksplorasi Kategori Jasa"
                }
                Text(
                    text = headerText,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
            
            if (activeCategory != "Semua") {
                val isEnglish = LocalIsEnglishState.current
                Text(
                    text = if (isEnglish) "View All" else "Lihat Semua",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .clickable { viewModel.updateSelectedCategory("Semua") }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("reset_category_grid")
                )
            }
        }
        
        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
            val columns = when {
                maxWidth >= 720.dp -> 4
                maxWidth >= 500.dp -> 3
                else -> 2
            }
            
            val chunked = categories.chunked(columns)
            
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                for (rowItems in chunked) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        for (category in rowItems) {
                            CategoryGridItem(
                                category = category,
                                activeRole = activeRole,
                                isSelected = activeCategory == category,
                                count = getListingCountForCategory(listings, category, activeRole, currentPartnerName),
                                onClick = {
                                    if (activeCategory == category) {
                                        viewModel.updateSelectedCategory("Semua")
                                    } else {
                                        viewModel.updateSelectedCategory(category)
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        
                        // Fill any empty spots on the last row if it's not fully filled
                        if (rowItems.size < columns) {
                            val emptySpots = columns - rowItems.size
                            for (j in 0 until emptySpots) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CategoryGridItem(
    category: String,
    activeRole: String,
    isSelected: Boolean,
    count: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val categoryColor = getCategoryColor(category)
    val isEnglish = LocalIsEnglishState.current
    
    val cardBgColor = if (isSelected) {
        categoryColor.copy(alpha = 0.12f)
    } else {
        MaterialTheme.colorScheme.surface
    }
    
    val borderColor = if (isSelected) {
        categoryColor
    } else {
        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
    }
    
    val titleText = when (category) {
        "Rumah Tangga" -> if (isEnglish) "Home Services" else "Rumah Tangga"
        "Elektronik" -> if (isEnglish) "Electronics" else "Elektronik"
        "Edukasi" -> if (isEnglish) "Education" else "Edukasi"
        "Kecantikan & Kesehatan" -> if (isEnglish) "Beauty & Wellness" else "Kecantikan/Kesehatan"
        else -> category
    }

    val subtitleText = when (category) {
        "Rumah Tangga" -> if (isEnglish) "Cleaning & Repair" else "Bersih & Renovasi"
        "Elektronik" -> if (isEnglish) "AC, TV & Gadget" else "Servis AC, TV & Lab"
        "Edukasi" -> if (isEnglish) "Private Tutoring" else "Les Privat & Tutor"
        "Kecantikan & Kesehatan" -> if (isEnglish) "Spa, Massage & Care" else "Spa, Pijat & Perawatan"
        else -> if (isEnglish) "Service Solutions" else "Layanan Jasa"
    }

    Card(
        modifier = modifier
            .height(115.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("category_grid_item_$category"),
        colors = CardDefaults.cardColors(containerColor = cardBgColor),
        border = BorderStroke(1.5.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 1.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(categoryColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        CategoryIconMapper(
                            category = category,
                            tint = categoryColor,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(categoryColor)
                        )
                    }
                }
                
                Column {
                    Text(
                        text = titleText,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = subtitleText,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    val label = if (isEnglish) {
                        if (activeRole == "MITRA") {
                            if (count == 1) "Provider" else "Providers"
                        } else {
                            if (count == 1) "Service" else "Services"
                        }
                    } else {
                        if (activeRole == "MITRA") "Penyedia" else "Pilihan"
                    }
                    Text(
                        text = "$count $label",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = categoryColor,
                        modifier = Modifier
                            .background(categoryColor.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}

private fun getListingCountForCategory(
    listings: List<ServiceListing>,
    category: String,
    role: String,
    currentPartnerName: String
): Int {
    val relevantListings = if (role == "MITRA") {
        listings.filter { it.partnerName == currentPartnerName }
    } else {
        listings
    }
    
    return relevantListings.count {
        when (category) {
            "Rumah Tangga" -> it.category == "Rumah Tangga" || it.category == "Kebersihan" || it.category == "Pertukangan" || it.category == "Kebersihan & Laundry" || it.category == "Pertukangan & Renovasi"
            "Elektronik" -> it.category == "Elektronik" || it.category == "Servis AC & Elektronik"
            "Edukasi" -> it.category == "Edukasi" || it.category == "Les Privat & Konsultasi"
            "Kecantikan & Kesehatan" -> it.category == "Kecantikan & Kesehatan" || it.category == "Kecantikan, Pijat & Spa" || it.category == "Layanan Kesehatan"
            else -> it.category == category
        }
    }
}

@Composable
fun NotificationsDialog(
    viewModel: JasaInViewModel,
    onDismiss: () -> Unit
) {
    val notifications by viewModel.notifications.collectAsState()
    
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .heightIn(max = 500.dp)
                .testTag("notifications_dialog_root"),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notifications",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Notifikasi Anda",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Tutup"
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${notifications.size} Notifikasi",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    if (notifications.isNotEmpty()) {
                        TextButton(
                            onClick = { viewModel.markAllNotificationsAsRead() },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(
                                text = "Tandai semua dibaca",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                if (notifications.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "Kosong",
                            tint = Color.LightGray.copy(alpha = 0.5f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Belum Ada Notifikasi",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Semua pemberitahuan pesanan atau ulasan akan muncul di sini.",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(notifications) { notif ->
                            NotificationItem(
                                notification = notif,
                                onReadClick = { viewModel.markNotificationAsRead(notif.id) },
                                onDeleteClick = { viewModel.deleteNotification(notif.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NotificationItem(
    notification: JasaInNotification,
    onReadClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onReadClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (notification.isRead) {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            } else {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
            }
        ),
        border = if (!notification.isRead) {
            BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
        } else null
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            // Icon according to type
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        color = when (notification.type) {
                            "NEW_BOOKING" -> Color(0xFFE3F2FD)
                            "STATUS_CHANGE" -> Color(0xFFE8F5E9)
                            "NEW_REVIEW" -> Color(0xFFFFF8E1)
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        },
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (notification.type) {
                        "NEW_BOOKING" -> Icons.Default.Receipt
                        "STATUS_CHANGE" -> Icons.Default.Sync
                        "NEW_REVIEW" -> Icons.Default.Star
                        else -> Icons.Default.Info
                    },
                    contentDescription = null,
                    tint = when (notification.type) {
                        "NEW_BOOKING" -> Color(0xFF1E88E5)
                        "STATUS_CHANGE" -> Color(0xFF4CAF50)
                        "NEW_REVIEW" -> Color(0xFFFFB300)
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    modifier = Modifier.size(18.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = notification.title,
                        fontWeight = if (!notification.isRead) FontWeight.Bold else FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    
                    // Time format helper
                    Text(
                        text = formatRelativeTime(notification.timestamp),
                        fontSize = 9.sp,
                        color = Color.Gray
                    )
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = notification.message,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                if (!notification.isRead) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Tandai sudah dibaca",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.clickable { onReadClick() }
                    )
                }
            }
            
            Spacer(modifier = Modifier.width(4.dp))
            
            IconButton(
                onClick = onDeleteClick,
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Hapus",
                    tint = Color.Gray,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

fun formatRelativeTime(timestamp: Long): String {
    val diff = System.currentTimeMillis() - timestamp
    return when {
        diff < 60000 -> "Baru saja"
        diff < 3600000 -> "${diff / 60000} menit lalu"
        diff < 86400000 -> "${diff / 3600000} jam lalu"
        else -> "${diff / 86400000} hari lalu"
    }
}
