package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val JasaInPrimary = Color(0xFF006A60)      // Sleek Teal
val JasaInPrimaryDark = Color(0xFF004D44)  // Darker Forest Teal
val JasaInSecondary = Color(0xFF4B6350)
val JasaInAccent = Color(0xFFFFB300)       // Vivid Amber
val JasaInBackground = Color(0xFFFAFAFA)
val JasaInSurface = Color(0xFFFFFFFF)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
