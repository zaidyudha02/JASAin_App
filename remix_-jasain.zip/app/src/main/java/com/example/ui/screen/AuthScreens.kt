package com.example.ui.screen

import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.JasaInViewModel
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(viewModel: JasaInViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var isLoginMode by remember { mutableStateOf(true) }
    
    // Role selection state: "PELANGGAN" (Customer) or "MITRA" (Partner)
    var selectedRole by remember { mutableStateOf("PELANGGAN") }
    var showGooglePicker by remember { mutableStateOf(false) }

    // Login Inputs
    var email by remember { mutableStateOf("budi.santoso@gmail.com") }
    var pin by remember { mutableStateOf("1234") }
    
    // Register Inputs
    var regName by remember { mutableStateOf("") }
    var regPhone by remember { mutableStateOf("") }
    var regEmail by remember { mutableStateOf("") }
    var regAddress by remember { mutableStateOf("") }
    var regPin by remember { mutableStateOf("") }
    
    var isRegSubmitted by remember { mutableStateOf(false) }
    
    val regNameError = if (regName.isNotEmpty() || isRegSubmitted) {
        if (regName.isBlank()) "Nama lengkap wajib diisi!"
        else if (regName.trim().length < 3) "Nama lengkap minimal 3 karakter!"
        else null
    } else null

    val regPhoneError = if (regPhone.isNotEmpty() || isRegSubmitted) {
        if (regPhone.isBlank()) "No. HP / WhatsApp wajib diisi!"
        else if (regPhone.trim().length < 10 || regPhone.trim().length > 15) "No. HP tidak valid (10-15 digit)!"
        else if (!regPhone.trim().all { it.isDigit() || it == '+' }) "No. HP hanya boleh berisi angka dan '+'!"
        else null
    } else null

    val regEmailError = if (regEmail.isNotEmpty() || isRegSubmitted) {
        if (regEmail.isBlank()) "Alamat email wajib diisi!"
        else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(regEmail.trim()).matches()) "Format email tidak valid!"
        else null
    } else null

    val regAddressError = if (regAddress.isNotEmpty() || isRegSubmitted) {
        if (regAddress.isBlank()) "Alamat tinggal wajib diisi!"
        else if (regAddress.trim().length < 10) "Alamat terlalu pendek, mohon berikan alamat lengkap!"
        else null
    } else null

    val regPinError = if (regPin.isNotEmpty() || isRegSubmitted) {
        if (regPin.isBlank()) "PIN sandi wajib diisi!"
        else if (regPin.length < 6) "PIN sandi minimal 6 karakter!"
        else null
    } else null
    
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    
    val coroutineScope = rememberCoroutineScope()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // App Branding
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Build,
                    contentDescription = "Logo JASAin",
                    tint = Color.White,
                    modifier = Modifier.size(48.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "JASAin",
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Marketplace Jasa No. 1 di Indonesia",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Switch Login/Register
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
                    .padding(4.dp)
            ) {
                Button(
                    onClick = { 
                        isLoginMode = true
                        errorMsg = null
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tab_login"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isLoginMode) MaterialTheme.colorScheme.primary else Color.Transparent,
                        contentColor = if (isLoginMode) Color.White else MaterialTheme.colorScheme.primary
                    ),
                    shape = RoundedCornerShape(10.dp),
                    elevation = null
                ) {
                    Text("Masuk", fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = { 
                        isLoginMode = false
                        errorMsg = null
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tab_daftar"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (!isLoginMode) MaterialTheme.colorScheme.primary else Color.Transparent,
                        contentColor = if (!isLoginMode) Color.White else MaterialTheme.colorScheme.primary
                    ),
                    shape = RoundedCornerShape(10.dp),
                    elevation = null
                ) {
                    Text("Daftar Baru", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Dual-Mode Selection: Customer vs Partner Profile
            Text(
                text = "Pilih Profil Akun Anda:",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.align(Alignment.Start).padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Customer Profile Selection Box
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(84.dp)
                        .clickable { selectedRole = "PELANGGAN" },
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedRole == "PELANGGAN") {
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        }
                    ),
                    border = if (selectedRole == "PELANGGAN") {
                        androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
                    } else null,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Pelanggan / Customer",
                            tint = if (selectedRole == "PELANGGAN") MaterialTheme.colorScheme.primary else Color.Gray,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Customer",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (selectedRole == "PELANGGAN") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Pesan Jasa",
                            fontSize = 9.sp,
                            color = Color.Gray
                        )
                    }
                }

                // Partner Profile Selection Box
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(84.dp)
                        .clickable { selectedRole = "MITRA" },
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedRole == "MITRA") {
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        }
                    ),
                    border = if (selectedRole == "MITRA") {
                        androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
                    } else null,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Handshake,
                            contentDescription = "Mitra / Partner",
                            tint = if (selectedRole == "MITRA") MaterialTheme.colorScheme.primary else Color.Gray,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Partner",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (selectedRole == "MITRA") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Penyedia Jasa",
                            fontSize = 9.sp,
                            color = Color.Gray
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Info Alert Card about Selected Mode
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (selectedRole == "PELANGGAN") Icons.Default.SupportAgent else Icons.Default.PointOfSale,
                        contentDescription = "Role desc",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (selectedRole == "PELANGGAN") {
                            "Customer: Hubungi teknisi, pesan perbaikan AC, pipa bocor, kelistrikan & pantau langsung!"
                        } else {
                            "Partner: Kelola listing keahlian Anda, terima order perbaikan dlm radar Anda, dapatkan pendapatan!"
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            if (isLoginMode) {
                // Username/Email Field
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it; errorMsg = null },
                    label = { Text("Email Akun") },
                    leadingIcon = { Icon(Icons.Default.Email, "Email") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_email"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // PIN / Password Field
                OutlinedTextField(
                    value = pin,
                    onValueChange = { 
                        pin = it
                        errorMsg = null
                    },
                    label = { Text("PIN Kunjungan / Sandi (Sandi Firebase Auth)") },
                    leadingIcon = { Icon(Icons.Default.Lock, "PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_pin"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = "Demo Sandi PIN: 1234",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            } else {
                // Registration Form
                OutlinedTextField(
                    value = regName,
                    onValueChange = { regName = it; errorMsg = null },
                    label = { Text("Nama Lengkap") },
                    leadingIcon = { Icon(Icons.Default.Person, "Nama") },
                    isError = regNameError != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reg_name"),
                    singleLine = true
                )
                if (regNameError != null) {
                    Text(
                        text = regNameError,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 11.sp,
                        modifier = Modifier.fillMaxWidth().padding(start = 4.dp, top = 2.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = regPhone,
                    onValueChange = { regPhone = it; errorMsg = null },
                    label = { Text("No. HP / WhatsApp") },
                    leadingIcon = { Icon(Icons.Default.Phone, "WhatsApp") },
                    isError = regPhoneError != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reg_phone"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                )
                if (regPhoneError != null) {
                    Text(
                        text = regPhoneError,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 11.sp,
                        modifier = Modifier.fillMaxWidth().padding(start = 4.dp, top = 2.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = regEmail,
                    onValueChange = { regEmail = it; errorMsg = null },
                    label = { Text("Alamat Email Login") },
                    leadingIcon = { Icon(Icons.Default.Email, "Email") },
                    isError = regEmailError != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reg_email"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
                if (regEmailError != null) {
                    Text(
                        text = regEmailError,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 11.sp,
                        modifier = Modifier.fillMaxWidth().padding(start = 4.dp, top = 2.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = regAddress,
                    onValueChange = { regAddress = it; errorMsg = null },
                    label = { Text("Alamat Tinggal / Domisili") },
                    leadingIcon = { Icon(Icons.Default.Home, "Alamat") },
                    isError = regAddressError != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reg_address"),
                    placeholder = { Text("misal: Jl. Sudirman No 12, Jakarta") }
                )
                if (regAddressError != null) {
                    Text(
                        text = regAddressError,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 11.sp,
                        modifier = Modifier.fillMaxWidth().padding(start = 4.dp, top = 2.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = regPin,
                    onValueChange = { regPin = it; errorMsg = null },
                    label = { Text("Buat PIN Keamanan / Sandi (Min 6 Karakter)") },
                    leadingIcon = { Icon(Icons.Default.Lock, "Sandi") },
                    visualTransformation = PasswordVisualTransformation(),
                    isError = regPinError != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reg_pin"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
                if (regPinError != null) {
                    Text(
                        text = regPinError,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 11.sp,
                        modifier = Modifier.fillMaxWidth().padding(start = 4.dp, top = 2.dp)
                    )
                }
            }

            // Error Display
            AnimatedVisibility(visible = errorMsg != null) {
                errorMsg?.let { err ->
                    Spacer(modifier = Modifier.height(16.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = err,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(12.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Action Button
            Button(
                onClick = {
                    if (isLoginMode) {
                        if (email.isBlank() || pin.length < 4) {
                            errorMsg = "Mohon masukkan email yang valid dan sandi pin minimal 4 karakter!"
                        } else {
                            isLoading = true
                            coroutineScope.launch {
                                val success = viewModel.loginAction(context, email, pin, selectedRole)
                                isLoading = false
                                if (!success) {
                                    errorMsg = "Gagal login. Periksa email atau sandi Anda!"
                                }
                            }
                        }
                    } else {
                        isRegSubmitted = true
                        val hasErrors = regNameError != null || regPhoneError != null || regEmailError != null || regAddressError != null || regPinError != null
                        if (hasErrors) {
                            errorMsg = "Mohon lengkapi semua field pendaftaran dengan benar!"
                        } else {
                            isLoading = true
                            viewModel.registerAction(
                                context,
                                regName.trim(),
                                regPhone.trim(),
                                regEmail.trim(),
                                regAddress.trim(),
                                regPin,
                                selectedRole
                            ) { success, firebaseError ->
                                isLoading = false
                                if (success) {
                                    isLoginMode = true
                                    email = regEmail
                                    pin = regPin
                                    errorMsg = if (firebaseError != null) {
                                        "Pendaftaran lokal berhasil! Firebase: ${firebaseError}. Menggunakan mode hybrid."
                                    } else {
                                        "Pendaftaran berhasil tersinkron ke Firebase Auth! Silakan masuk."
                                    }
                                } else {
                                    errorMsg = "Pendaftaran gagal!"
                                }
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("auth_submit_button"),
                enabled = !isLoading,
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    val roleLabel = if (selectedRole == "PELANGGAN") "Customer" else "Partner"
                    Text(
                        text = if (isLoginMode) "Masuk Sebagai $roleLabel" else "Daftar Akun $roleLabel Baru",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }

            if (isLoginMode) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { showGooglePicker = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("google_login_button"),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.onBackground
                    )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "G",
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF4285F4),
                            fontSize = 18.sp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Masuk dengan Google",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            if (showGooglePicker) {
                GoogleAccountChooserDialog(
                    selectedRole = selectedRole,
                    onAccountSelected = { chosenEmail, chosenName ->
                        showGooglePicker = false
                        isLoading = true
                        coroutineScope.launch {
                            val success = viewModel.loginWithGoogleAction(
                                context = context,
                                idToken = null,
                                selectedRole = selectedRole,
                                customEmail = chosenEmail,
                                customName = chosenName
                            )
                            isLoading = false
                            if (!success) {
                                errorMsg = "Gagal login dengan akun Google!"
                            }
                        }
                    },
                    onDismiss = { showGooglePicker = false }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Engine status banner
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (viewModel.isUsingFirebase) Icons.Default.CloudQueue else Icons.Default.CloudOff,
                        contentDescription = "Firebase status icon",
                        tint = if (viewModel.isUsingFirebase) MaterialTheme.colorScheme.primary else Color.Gray,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Status: ${viewModel.firebaseEngineMessage}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (viewModel.isUsingFirebase) MaterialTheme.colorScheme.primary else Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun GoogleAccountChooserDialog(
    selectedRole: String,
    onAccountSelected: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header with Google colorful branding representation
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Text("G", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color(0xFF4285F4))
                    Text("o", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color(0xFFEA4335))
                    Text("o", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color(0xFFFBBC05))
                    Text("g", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color(0xFF4285F4))
                    Text("l", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color(0xFF34A853))
                    Text("e", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color(0xFFEA4335))
                }

                Text(
                    text = "Pilih akun Google Anda",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
                
                Text(
                    text = "untuk masuk ke JASAin sebagai ${if (selectedRole == "PELANGGAN") "Customer" else "Partner"}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
                )

                // Account 1: Customer Google Account
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onAccountSelected("budi.google@gmail.com", "Budi Santoso") }
                        .padding(bottom = 8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFF4285F4), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("B", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Budi Santoso", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("budi.google@gmail.com", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }

                // Account 2: Partner Google Account
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onAccountSelected("mitra.google@gmail.com", "Mitra Mandiri") }
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFF34A853), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("M", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Mitra Mandiri", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("mitra.google@gmail.com", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }

                // Cancel button
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Batal", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

