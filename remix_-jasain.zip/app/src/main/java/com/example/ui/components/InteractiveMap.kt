package com.example.ui.components

import android.annotation.SuppressLint
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Helper to map general Indonesian city/area names to coordinates
object CoordinateMapper {
    data class LatLng(val latitude: Double, val longitude: Double)

    fun getCoords(locationName: String): LatLng {
        return when (locationName.lowercase().trim()) {
            "banjarmasin" -> LatLng(-3.3167, 114.5901)
            "banjarbaru" -> LatLng(-3.4333, 114.8333)
            "martapura" -> LatLng(-3.4167, 114.8500)
            "pelaihari" -> LatLng(-3.7917, 114.7750)
            "kandangan" -> LatLng(-2.7833, 115.2500)
            "barabai" -> LatLng(-2.5833, 115.3833)
            "amuntai" -> LatLng(-2.4167, 115.2500)
            "tanjung" -> LatLng(-2.1833, 115.4000)
            "batulicin" -> LatLng(-3.4500, 116.0000)
            "kotabaru" -> LatLng(-3.2333, 116.2167)
            "marabahan" -> LatLng(-3.0000, 114.7667)
            "paringin" -> LatLng(-2.3333, 115.4667)
            "rantau" -> LatLng(-2.9333, 115.1500)
            else -> LatLng(-3.3167, 114.5901) // Default Banjarmasin Center
        }
    }
}

/**
 * JS Bridge interface for our Leaflet WebView OpenStreetMap
 */
class WebAppInterface(private val onAddressResult: (String, Double, Double) -> Unit) {
    @JavascriptInterface
    fun onAddressSelected(address: String, lat: Double, lng: Double) {
        onAddressResult(address, lat, lng)
    }
}

/**
 * Interactive OSM Map view using WebView + Leaflet
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun OpenStreetMapWebView(
    latitude: Double,
    longitude: Double,
    locationLabel: String,
    onAddressSelected: (String, Double, Double) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val webView = remember { WebView(context) }
    val scope = rememberCoroutineScope()
    var isMapLoaded by remember { mutableStateOf(false) }

    val leafletHtml = remember(latitude, longitude, locationLabel) {
        """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
            <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
            <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
            <style>
                body { padding: 0; margin: 0; }
                html, body, #map { height: 100%; width: 100vw; background-color: #f4f6f9; }
                .leaflet-bar { border: none !important; box-shadow: 0 4px 12px rgba(0,0,0,0.15) !important; }
                .leaflet-control-zoom-in, .leaflet-control-zoom-out { background-color: #2E7D32 !important; color: white !important; font-weight: bold; border-radius: 8dp !important; margin: 2px !important; }
            </style>
        </head>
        <body>
            <div id="map"></div>
            <script>
                var map;
                var marker;
                try {
                    map = L.map('map', { zoomControl: true }).setView([$latitude, $longitude], 14);
                    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        maxZoom: 19,
                        attribution: '© OpenStreetMap JASAin'
                    }).addTo(map);

                    marker = L.marker([$latitude, $longitude], { draggable: true }).addTo(map);
                    if ('$locationLabel' !== '') {
                        marker.bindPopup('<b>' + '$locationLabel' + '</b>').openPopup();
                    }

                    function triggerReverseGeocode(lat, lng) {
                        fetch('https://nominatim.openstreetmap.org/reverse?format=json&lat=' + lat + '&lon=' + lng + '&zoom=18&addressdetails=1', {
                            headers: {
                                'User-Agent': 'JASAin_Android_Client_App'
                            }
                        })
                        .then(function(resp) { return resp.json(); })
                        .then(function(data) {
                            var road = data.address.road || data.address.suburb || data.address.neighbourhood || '';
                            var city = data.address.city || data.address.municipality || data.address.city_district || data.address.county || '';
                            var state = data.address.state || '';
                            var fullAddr = data.display_name || (road + ', ' + city + ', ' + state);
                            
                            // fallback simpler name
                            var simpleNameStrStr = "";
                            if (road && city) {
                                simpleNameStrStr = road + ", " + city;
                            } else {
                                simpleNameStrStr = fullAddr;
                            }
                            
                            if (window.AndroidBridge) {
                                window.AndroidBridge.onAddressSelected(simpleNameStrStr, lat, lng);
                            }
                        })
                        .catch(function(err) {
                            if (window.AndroidBridge) {
                                window.AndroidBridge.onAddressSelected('Jalan Srikaya, ' + (lat.toFixed(5)) + ', ' + (lng.toFixed(5)), lat, lng);
                            }
                        });
                    }

                    marker.on('dragend', function(e) {
                        var pos = marker.getLatLng();
                        triggerReverseGeocode(pos.lat, pos.lng);
                    });

                    map.on('click', function(e) {
                        marker.setLatLng(e.latlng);
                        triggerReverseGeocode(e.latlng.lat, e.latlng.lng);
                    });

                } catch(e) {
                    document.getElementById('map').innerHTML = '<div style="padding: 20px; text-align: center; font-family: sans-serif;">Peta sedang dimuat secara aman...</div>';
                }
            </script>
        </body>
        </html>
        """.trimIndent()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            factory = { context ->
                webView.apply {
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        allowContentAccess = true
                        allowFileAccess = true
                        useWideViewPort = true
                        loadWithOverviewMode = true
                    }
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            isMapLoaded = true
                        }
                    }
                    addJavascriptInterface(
                        WebAppInterface { address, lat, lng ->
                            scope.launch {
                                onAddressSelected(address, lat, lng)
                            }
                        },
                        "AndroidBridge"
                    )
                    loadDataWithBaseURL(null, leafletHtml, "text/html", "UTF-8", null)
                }
            },
            update = {
                // Leaflet HTML handles its updates, keep baseline reactive values
            },
            modifier = Modifier.fillMaxSize()
        )

        if (!isMapLoaded) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Memuat Hub Lokasi JASAin...",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

/**
 * Beautiful Overlay Dialog allowing full-screen location pinpoint picking
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapSelectionDialog(
    initialLocation: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    val initialCoords = remember(initialLocation) { CoordinateMapper.getCoords(initialLocation) }
    var chosenAddress by remember { mutableStateOf(initialLocation) }
    var currentCoords by remember { mutableStateOf(initialCoords) }
    var isSearching by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Text(
                            "Pinpoint Alamat Kursi/Maps",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, "Kembali")
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            },
            bottomBar = {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(16.dp, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)),
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(20.dp)
                            .navigationBarsPadding(),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    "Lokasi Terpilih Melalui Pin JASAin",
                                    fontSize = 11.sp,
                                    color = Color.Gray,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = chosenAddress,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Button(
                            onClick = {
                                onConfirm(chosenAddress)
                                onDismiss()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("confirm_map_location_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Gunakan Alamat Ini", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Interactive OpenStreetMap view
                OpenStreetMapWebView(
                    latitude = currentCoords.latitude,
                    longitude = currentCoords.longitude,
                    locationLabel = chosenAddress,
                    onAddressSelected = { matchedAddress, lat, lng ->
                        chosenAddress = matchedAddress
                        currentCoords = CoordinateMapper.LatLng(lat, lng)
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Search Panel Overlaid on Map (Floating)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .shadow(8.dp, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("Cari area, kelurahan, kota...", fontSize = 12.sp) },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp),
                                textStyle = TextStyle(fontSize = 13.sp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                    focusedBorderColor = MaterialTheme.colorScheme.primary
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(
                                onClick = {
                                    if (searchQuery.isNotBlank()) {
                                        isSearching = true
                                        scope.launch {
                                            delay(800) // simulated geocode lookup
                                            val coords = CoordinateMapper.getCoords(searchQuery)
                                            currentCoords = coords
                                            chosenAddress = searchQuery
                                            isSearching = false
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                            ) {
                                if (isSearching) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        modifier = Modifier.size(20.dp),
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "Cari",
                                        tint = Color.White
                                    )
                                }
                            }
                        }

                        // Preset popular landmarks
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "Lokasi Populer JASAin:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Gray,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf("Jakarta Pusat", "Jakarta Selatan", "Bandung").forEach { city ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f))
                                        .clickable {
                                            searchQuery = city
                                            currentCoords = CoordinateMapper.getCoords(city)
                                            chosenAddress = "$city, Jawa Barat/DKI Jakarta"
                                        }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(city, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Embedded Mini Map component for Listing Detail Page
 */
@Composable
fun ServiceDetailMiniMap(
    locationName: String,
    partnerName: String,
    modifier: Modifier = Modifier
) {
    val coords = remember(locationName) { CoordinateMapper.getCoords(locationName) }
    var showInteractiveMap by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f),
                shape = RoundedCornerShape(16.dp)
            )
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .background(Color(0xFFE3F2FD))
            ) {
                // Static decorative rendering representing road maps via Compose Canvas
                MapDrawingCanvas(
                    targetCoords = coords,
                    partnerName = partnerName,
                    modifier = Modifier.fillMaxSize()
                )

                // Top Pin badge
                Box(
                    modifier = Modifier
                        .padding(12.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .align(Alignment.TopStart)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = locationName,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Description bar below mini map
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Radius Layanan Terdekat",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Jasa terdekat dari area Anda (Estimasi: 3.5 km)",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                Button(
                    onClick = { showInteractiveMap = true },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer)
                ) {
                    Icon(Icons.Default.Map, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Peta Live", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showInteractiveMap) {
        MapSelectionDialog(
            initialLocation = locationName,
            onDismiss = { showInteractiveMap = false },
            onConfirm = {}
        )
    }
}

/**
 * Beautiful vector mapping engine utilizing Jetpack Compose Canvas to show road/grids/markers
 */
@Composable
fun MapDrawingCanvas(
    targetCoords: CoordinateMapper.LatLng,
    partnerName: String,
    modifier: Modifier = Modifier
) {
    val baseGreen = MaterialTheme.colorScheme.primary
    val baseAccent = MaterialTheme.colorScheme.secondary
    
    // Infinite anim for pulsing marker
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 12f,
        targetValue = 28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height

        // Background terrain pattern
        drawRect(color = Color(0xFFF1F8E9)) // Light eco green maps

        // Roads/Grids
        val strokeRoad = 8f
        val strokeMainRoad = 16f
        val roadColor = Color.White
        val mainRoadColor = Color(0xFFFFF9C4)

        // Draw horizontal/vertical highway roads
        drawLine(
            color = mainRoadColor,
            start = Offset(0f, height * 0.4f),
            end = Offset(width, height * 0.45f),
            strokeWidth = strokeMainRoad
        )
        drawLine(
            color = mainRoadColor,
            start = Offset(width * 0.25f, 0f),
            end = Offset(width * 0.35f, height),
            strokeWidth = strokeMainRoad
        )

        // Local smaller roads
        drawLine(
            color = roadColor,
            start = Offset(0f, height * 0.15f),
            end = Offset(width, height * 0.15f),
            strokeWidth = strokeRoad
        )
        drawLine(
            color = roadColor,
            start = Offset(0f, height * 0.75f),
            end = Offset(width, height * 0.72f),
            strokeWidth = strokeRoad
        )
        drawLine(
            color = roadColor,
            start = Offset(width * 0.7f, 0f),
            end = Offset(width * 0.65f, height),
            strokeWidth = strokeRoad
        )

        // Draw green park area
        drawCircle(
            color = Color(0xFFDCEDC8),
            radius = width * 0.18f,
            center = Offset(width * 0.85f, height * 0.25f)
        )

        // Draw blue river path
        val riverPoints = listOf(
            Offset(0f, height * 0.85f),
            Offset(width * 0.3f, height * 0.9f),
            Offset(width * 0.6f, height * 0.78f),
            Offset(width, height * 0.92f)
        )
        for (i in 0 until riverPoints.size - 1) {
            drawLine(
                color = Color(0xFFB3E5FC),
                start = riverPoints[i],
                end = riverPoints[i + 1],
                strokeWidth = 14f,
                cap = StrokeCap.Round
            )
        }

        // Draw User Pin & Partner Pin
        val userLoc = Offset(width * 0.35f, height * 0.65f)
        val partnerLoc = Offset(width * 0.65f, height * 0.35f)

        // Dotted Connection Line (Rute)
        drawLine(
            color = baseGreen.copy(alpha = 0.5f),
            start = userLoc,
            end = partnerLoc,
            strokeWidth = 4f,
            cap = StrokeCap.Round
        )

        // Pulsing radar effect on Partner
        drawCircle(
            color = baseGreen.copy(alpha = pulseAlpha),
            radius = pulseRadius,
            center = partnerLoc
        )

        // Partner Pin (Green)
        drawCircle(color = baseGreen, radius = 9f, center = partnerLoc)
        drawCircle(color = Color.White, radius = 4f, center = partnerLoc)

        // User Pin (Accent Blue / Red)
        drawCircle(color = Color(0xFFE53935), radius = 7f, center = userLoc)
        drawCircle(color = Color.White, radius = 3.5f, center = userLoc)
    }
}

/**
 * Animated real-time tracking arrival map for accepted bookings
 */
@Composable
fun TrackingArrivalMap(
    booking: com.example.data.entity.Booking,
    modifier: Modifier = Modifier
) {
    val coords = remember(booking.address) { CoordinateMapper.getCoords(booking.address) }
    
    // Status animation timeline
    var progressVal by remember { mutableStateOf(0.1f) }
    val animatedProgress by animateFloatAsState(
        targetValue = progressVal,
        animationSpec = tween(durationMillis = 15000, easing = LinearEasing),
        label = "progress"
    )

    // Automatically animate the transit when shown
    LaunchedEffect(key1 = booking.id) {
        progressVal = 1.0f
    }

    val distanceRemaining = remember(animatedProgress) {
        val rem = 3.8 * (1.0f - animatedProgress)
        if (rem < 0.1) "Tiba di tujuan" else "%.1f km lagi".format(rem)
    }

    val durationMinutesStr = remember(animatedProgress) {
        val min = (12 * (1.0f - animatedProgress)).toInt()
        if (min < 1) "Dalam 1 menit" else "Instan ($min menit)"
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f),
                shape = RoundedCornerShape(16.dp)
            )
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(Color(0xFFE8F5E9))
            ) {
                // Tracking Grid Canvas
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // Draw land
                    drawRect(color = Color(0xFFECEFF1))

                    // Road Grid Lines
                    val roadColor = Color.White
                    val lineStroke = 12f

                    // Draw nice circular route
                    val pathX = listOf(w * 0.15f, w * 0.45f, w * 0.75f, w * 0.85f)
                    val pathY = listOf(h * 0.8f, h * 0.45f, h * 0.35f, h * 0.15f)

                    // Draw background roads
                    drawLine(color = roadColor, start = Offset(0f, h * 0.45f), end = Offset(w, h * 0.45f), strokeWidth = lineStroke)
                    drawLine(color = roadColor, start = Offset(w * 0.45f, 0f), end = Offset(w * 0.45f, h), strokeWidth = lineStroke)

                    // Draw Service Router Lane
                    val routerColor = Color(0xFFC8E6C9)
                    drawLine(color = routerColor, start = Offset(w * 0.15f, h * 0.8f), end = Offset(w * 0.45f, h * 0.45f), strokeWidth = 24f, cap = StrokeCap.Round)
                    drawLine(color = routerColor, start = Offset(w * 0.45f, h * 0.45f), end = Offset(w * 0.85f, h * 0.25f), strokeWidth = 24f, cap = StrokeCap.Round)

                    // Active traveling line
                    val activeColor = Color(0xFF4CAF50)
                    val activeStart = Offset(w * 0.15f, h * 0.8f)
                    val midPoint = Offset(w * 0.45f, h * 0.45f)
                    val activeEnd = Offset(w * 0.85f, h * 0.25f)

                    // Calculate current animated location vector
                    val currentPos = if (animatedProgress < 0.5f) {
                        val t = animatedProgress / 0.5f
                        Offset(
                            activeStart.x + (midPoint.x - activeStart.x) * t,
                            activeStart.y + (midPoint.y - activeStart.y) * t
                        )
                    } else {
                        val t = (animatedProgress - 0.5f) / 0.5f
                        Offset(
                            midPoint.x + (activeEnd.x - midPoint.x) * t,
                            midPoint.y + (activeEnd.y - midPoint.y) * t
                        )
                    }

                    // Draw traveling path trailing line
                    if (animatedProgress < 0.5f) {
                        drawLine(color = activeColor, start = activeStart, end = currentPos, strokeWidth = 8f, cap = StrokeCap.Round)
                    } else {
                        drawLine(color = activeColor, start = activeStart, end = midPoint, strokeWidth = 8f, cap = StrokeCap.Round)
                        drawLine(color = activeColor, start = midPoint, end = currentPos, strokeWidth = 8f, cap = StrokeCap.Round)
                    }

                    // Target client marker flag (Home)
                    drawCircle(color = Color(0xFFE53935), radius = 10f, center = activeEnd)
                    drawCircle(color = Color.White, radius = 5f, center = activeEnd)

                    // Partner Vehicle pulsing dot marker
                    drawCircle(color = activeColor.copy(alpha = 0.3f), radius = 24f, center = currentPos)
                    drawCircle(color = activeColor, radius = 8f, center = currentPos)
                    drawCircle(color = Color.White, radius = 4.5f, center = currentPos)
                }

                // Overlay Status Card
                Box(
                    modifier = Modifier
                        .padding(12.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black.copy(alpha = 0.75f))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .align(Alignment.BottomStart)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.DirectionsBike,
                            contentDescription = "Motor",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Mitra OTW: $distanceRemaining ($durationMinutesStr)",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Expanded detail list
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "Pelacakan Lokasi Penyedia [LIVE OSM]",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalShipping,
                        contentDescription = "Posisi",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = "Area Pelayanan: ${booking.address}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "Mitra ${booking.partnerName} sedang menuju ke alamat Anda.",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MitraMapWebView(
    latitude: Double,
    longitude: Double,
    listings: List<com.example.data.entity.ServiceListing>,
    onMitraSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val webView = remember { WebView(context) }
    val scope = rememberCoroutineScope()
    var isMapLoaded by remember { mutableStateOf(false) }

    val leafletHtml = remember(latitude, longitude, listings) {
        val markersJs = StringBuilder()
        listings.forEach { listing ->
            val coords = CoordinateMapper.getCoords(listing.location)
            val jitterLat = coords.latitude + ((listing.id % 13) - 6) * 0.0015
            val jitterLng = coords.longitude + (((listing.id * 7) % 13) - 6) * 0.0015
            
            markersJs.append("""
                var marker${listing.id} = L.marker([$jitterLat, $jitterLng], {
                    icon: L.icon({
                        iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
                        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
                        iconSize: [25, 41],
                        iconAnchor: [12, 41],
                        popupAnchor: [1, -34],
                        shadowSize: [41, 41]
                    })
                }).addTo(map);
                marker${listing.id}.bindTooltip("<b>${listing.partnerName}</b><br>${listing.title}", { permanent: false, direction: 'top' });
                marker${listing.id}.on('click', function() {
                    if (window.AndroidBridge) {
                        window.AndroidBridge.onMitraSelected(${listing.id});
                    }
                });
            """.trimIndent())
        }

        """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
            <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
            <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
            <style>
                body { padding: 0; margin: 0; }
                html, body, #map { height: 100%; width: 100vw; background-color: #f4f6f9; }
                .leaflet-bar { border: none !important; box-shadow: 0 4px 12px rgba(0,0,0,0.15) !important; }
                .leaflet-control-zoom-in, .leaflet-control-zoom-out { background-color: #2E7D32 !important; color: white !important; font-weight: bold; }
            </style>
        </head>
        <body>
            <div id="map"></div>
            <script>
                var map;
                try {
                    map = L.map('map', { zoomControl: true }).setView([$latitude, $longitude], 13);
                    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        maxZoom: 19,
                        attribution: '© OpenStreetMap JASAin'
                    }).addTo(map);

                    var userMarker = L.marker([$latitude, $longitude], {
                        icon: L.icon({
                            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
                            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
                            iconSize: [25, 41],
                            iconAnchor: [12, 41],
                            popupAnchor: [1, -34],
                            shadowSize: [41, 41]
                        })
                    }).addTo(map);
                    userMarker.bindPopup("<b>Lokasi Anda</b>").openPopup();

                    $markersJs

                } catch(e) {
                    document.getElementById('map').innerHTML = '<div style="padding: 20px; text-align: center; font-family: sans-serif;">Peta sedang dimuat secara aman...</div>';
                }
            </script>
        </body>
        </html>
        """.trimIndent()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            factory = { context ->
                webView.apply {
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        allowContentAccess = true
                        allowFileAccess = true
                        useWideViewPort = true
                        loadWithOverviewMode = true
                    }
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            isMapLoaded = true
                        }
                    }
                    addJavascriptInterface(
                        WebAppInterface { address, lat, lng ->
                            // Address callback signature matching
                        },
                        "AndroidBridgeAddress"
                    )
                    addJavascriptInterface(
                        object {
                            @JavascriptInterface
                            fun onMitraSelected(id: Int) {
                                scope.launch {
                                    onMitraSelected(id)
                                }
                            }
                        },
                        "AndroidBridge"
                    )
                    loadDataWithBaseURL(null, leafletHtml, "text/html", "UTF-8", null)
                }
            },
            update = {
                webView.loadDataWithBaseURL(null, leafletHtml, "text/html", "UTF-8", null)
            },
            modifier = Modifier.fillMaxSize()
        )

        if (!isMapLoaded) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Memuat Radar Mitra Terdekat...",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MitraMapExplorerDialog(
    listings: List<com.example.data.entity.ServiceListing>,
    initialLocation: String,
    onDismiss: () -> Unit,
    onBookNow: (com.example.data.entity.ServiceListing) -> Unit,
    onViewDetail: (com.example.data.entity.ServiceListing) -> Unit
) {
    var selectedCategoryOnMap by remember { mutableStateOf("Semua") }
    val filteredListings = remember(selectedCategoryOnMap, listings) {
        if (selectedCategoryOnMap == "Semua") {
            listings
        } else {
            listings.filter { it.category == selectedCategoryOnMap }
        }
    }
    
    val centerCoords = remember(initialLocation) { CoordinateMapper.getCoords(initialLocation) }
    var selectedMitraId by remember { mutableStateOf<Int?>(null) }
    val selectedMitra = remember(selectedMitraId, listings) {
        listings.find { it.id == selectedMitraId }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Text(
                            "Radar Mitra JASAin",
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onDismiss, modifier = Modifier.testTag("mitra_map_back")) {
                            Icon(Icons.Default.ArrowBack, "Kembali")
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                MitraMapWebView(
                    latitude = centerCoords.latitude,
                    longitude = centerCoords.longitude,
                    listings = filteredListings,
                    onMitraSelected = { id ->
                        selectedMitraId = id
                    },
                    modifier = Modifier.fillMaxSize()
                )

                val categoriesList = listOf("Semua", "Rumah Tangga", "Elektronik", "Edukasi", "Kecantikan & Kesehatan")
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .padding(12.dp)
                        .testTag("map_category_chips"),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(categoriesList) { categoryName ->
                        val isSelected = selectedCategoryOnMap == categoryName
                        val categoryColor = getCategoryColor(categoryName)
                        val chipBg = if (isSelected) categoryColor else MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)
                        val chipTextColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface

                        Surface(
                            onClick = {
                                selectedCategoryOnMap = categoryName
                                selectedMitraId = null
                            },
                            shape = RoundedCornerShape(20.dp),
                            color = chipBg,
                            shadowElevation = 4.dp,
                            modifier = Modifier.testTag("map_chip_$categoryName")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                CategoryIconMapper(
                                    category = categoryName,
                                    tint = chipTextColor,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = categoryName,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = chipTextColor
                                )
                            }
                        }
                    }
                }

                AnimatedVisibility(
                    visible = selectedMitra != null,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(16.dp)
                        .testTag("map_mitra_detail_card")
                ) {
                    if (selectedMitra != null) {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(
                                                color = getCategoryColor(selectedMitra.category).copy(alpha = 0.15f),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(
                                                    text = selectedMitra.category,
                                                    color = getCategoryColor(selectedMitra.category),
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = selectedMitra.title,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Black,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "Mitra: ${selectedMitra.partnerName}",
                                            fontSize = 12.sp,
                                            color = Color.Gray
                                        )
                                    }

                                    IconButton(
                                        onClick = { selectedMitraId = null },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Close, "Tutup", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                    }
                                }

                                Divider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Biaya Layanan", fontSize = 10.sp, color = Color.Gray)
                                        Text(
                                            text = "${formatRupiah(selectedMitra.price)} / ${selectedMitra.priceUnit}",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = com.example.ui.theme.JasaInAccent
                                        )
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(
                                            onClick = { onViewDetail(selectedMitra) },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                            modifier = Modifier.height(36.dp)
                                        ) {
                                            Text("Detail", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }

                                        Button(
                                            onClick = { onBookNow(selectedMitra) },
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                                            modifier = Modifier.height(36.dp)
                                        ) {
                                            Text("Booking", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
