package com.example.ui.screen

import coil.compose.AsyncImage
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.entity.Booking
import com.example.data.entity.ServiceListing
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import com.example.ui.components.*
import com.example.ui.theme.JasaInAccent
import com.example.ui.theme.JasaInPrimary
import com.example.ui.viewmodel.JasaInViewModel

@Composable
fun MitraHomeScreen(
    viewModel: JasaInViewModel,
    modifier: Modifier = Modifier
) {
    val profile by viewModel.userProfile.collectAsState()
    val incomingBookings by viewModel.partnerBookings.collectAsState()
    val listings by viewModel.allListings.collectAsState()

    val currentPartnerName = profile?.name ?: "Budi Santoso"
    val partnerListingsSize = listings.filter { it.partnerName == currentPartnerName }.size

    // Calculate total income from "Selesai" bookings
    val completedBookings = incomingBookings.filter { it.status == "Selesai" }
    val totalEarnings = completedBookings.sumOf { it.price }

    val activeCategory by viewModel.selectedCategory.collectAsState()
    var selectedStatusFilter by remember { mutableStateOf("Aktif") }

    // All active jobs for stats (Diajukan or Diterima)
    val activeJobs = incomingBookings.filter { it.status == "Diajukan" || it.status == "Diterima" }

    val filteredActiveJobs = incomingBookings.filter { job ->
        val statusMatches = when (selectedStatusFilter) {
            "Aktif" -> job.status == "Diajukan" || job.status == "Diterima"
            "Diajukan" -> job.status == "Diajukan"
            "Diterima" -> job.status == "Diterima"
            "Selesai" -> job.status == "Selesai"
            "Batal" -> job.status == "BATAL"
            else -> true // "Semua"
        }

        val categoryMatches = if (activeCategory == "Semua") {
            true
        } else {
            when (activeCategory) {
                "Rumah Tangga" -> job.serviceCategory == "Rumah Tangga" || job.serviceCategory == "Kebersihan" || job.serviceCategory == "Pertukangan" || job.serviceCategory == "Kebersihan & Laundry" || job.serviceCategory == "Pertukangan & Renovasi"
                "Elektronik" -> job.serviceCategory == "Elektronik" || job.serviceCategory == "Servis AC & Elektronik"
                "Edukasi" -> job.serviceCategory == "Edukasi" || job.serviceCategory == "Les Privat & Konsultasi"
                "Kecantikan & Kesehatan" -> job.serviceCategory == "Kecantikan & Kesehatan" || job.serviceCategory == "Kecantikan, Pijat & Spa" || job.serviceCategory == "Layanan Kesehatan"
                else -> job.serviceCategory == activeCategory
            }
        }

        statusMatches && categoryMatches
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        JasaInTopAppBar(
            title = "Dashboard Mitra JASAin",
            showModeTabs = true,
            viewModel = viewModel
        )

        val isOnline by viewModel.isOnline.collectAsState()
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.toggleOnlineStatus() },
            color = if (isOnline) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.95f)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isOnline) Color(0xFF4CAF50) else Color.White)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isOnline) "Koneksi Terhubung (Online)" else "🔴 Mode Offline: Menggunakan Cache Room DB",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isOnline) MaterialTheme.colorScheme.primary else Color.White
                    )
                }
                Text(
                    text = "Ganti Mode",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline,
                    color = if (isOnline) MaterialTheme.colorScheme.primary else Color.White
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Mitra greeting and Role Toggle
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .background(JasaInAccent.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Storefront, "Store", tint = JasaInAccent)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = currentPartnerName,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = profile?.partnerCategory ?: "Servis",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                StarRatingBar(rating = profile?.partnerRating ?: 4.8f)
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    UserRoleToggle(
                        currentRole = profile?.currentRole ?: "MITRA",
                        onToggle = { viewModel.toggleUserMode() }
                    )
                }
            }

            // Availability & Business Status Dashboard Card
            item {
                val isEnglish = LocalIsEnglishState.current
                val partnerIsAvailable by viewModel.partnerIsAvailable.collectAsState()
                
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("mitra_availability_dashboard_card"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (partnerIsAvailable) {
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        }
                    ),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(
                        width = 1.5.dp,
                        color = if (partnerIsAvailable) {
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                        } else {
                            MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                        }
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(
                                            if (partnerIsAvailable) Color(0xFF4CAF50).copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.15f),
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (partnerIsAvailable) Icons.Default.CheckCircle else Icons.Default.Info,
                                        contentDescription = "Availability Status Icon",
                                        tint = if (partnerIsAvailable) Color(0xFF4CAF50) else Color.Gray,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (isEnglish) "Availability Status" else "Status Ketersediaan",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = if (partnerIsAvailable) {
                                            if (isEnglish) "Active (Accepting Orders)" else "Aktif (Menerima Pesanan)"
                                        } else {
                                            if (isEnglish) "Busy / Idle (Paused)" else "Sibuk / Istirahat (Jeda)"
                                        },
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (partnerIsAvailable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                            
                            // Real Interactive Switch / Toggle for availability status
                            Switch(
                                checked = partnerIsAvailable,
                                onCheckedChange = { viewModel.togglePartnerAvailability() },
                                modifier = Modifier.testTag("mitra_availability_switch")
                            )
                        }
                        
                        // Summary info
                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (partnerIsAvailable) {
                                    if (isEnglish) "Customers can book your active services now." else "Pelanggan dapat memesan jasa aktif Anda sekarang."
                                } else {
                                    if (isEnglish) "Services are hidden / temporarily busy." else "Layanan disembunyikan / sibuk sementara."
                                },
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                                modifier = Modifier.weight(1f)
                            )
                            
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(30.dp))
                                    .background(
                                        if (partnerIsAvailable) Color(0xFF4CAF50).copy(alpha = 0.1f) else Color.Gray.copy(alpha = 0.1f)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (partnerIsAvailable) "ONLINE" else "PAUSED",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (partnerIsAvailable) Color(0xFF4CAF50) else Color.Gray
                                )
                            }
                        }
                    }
                }
            }

            // Order Status Tracker & Performance
            item {
                val isEnglish = LocalIsEnglishState.current
                val pendingJobs = incomingBookings.count { it.status == "Diajukan" }
                val acceptedJobs = incomingBookings.count { it.status == "Diterima" }
                val completedJobs = incomingBookings.count { it.status == "Selesai" }
                val canceledJobs = incomingBookings.count { it.status == "BATAL" }
                
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("mitra_order_analytics_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(bottom = 12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Assessment,
                                contentDescription = "Analytics Icon",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = if (isEnglish) "Order Status & Performance" else "Status & Kinerja Pesanan",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Pending
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f),
                                        RoundedCornerShape(12.dp)
                                    )
                                    .padding(vertical = 10.dp, horizontal = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = pendingJobs.toString(),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (isEnglish) "New / Request" else "Baru / Diajukan",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    textAlign = TextAlign.Center
                                )
                            }
                            
                            // Accepted / Ongoing
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f),
                                        RoundedCornerShape(12.dp)
                                    )
                                    .padding(vertical = 10.dp, horizontal = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = acceptedJobs.toString(),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (isEnglish) "In Progress" else "Diproses",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    textAlign = TextAlign.Center
                                )
                            }
                            
                            // Completed
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        Color(0xFF4CAF50).copy(alpha = 0.1f),
                                        RoundedCornerShape(12.dp)
                                    )
                                    .padding(vertical = 10.dp, horizontal = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = completedJobs.toString(),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF4CAF50)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (isEnglish) "Completed" else "Selesai",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF2E7D32),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }

            // Stats row cards
            item {
                val isEnglish = LocalIsEnglishState.current
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Earnings Card
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (isEnglish) "Total Earnings" else "Total Pendapatan",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = formatRupiah(totalEarnings),
                                fontSize = 14.sp, // Reduced to prevent overflow on tight screens
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    // Active Jobs Card
                    Card(
                        modifier = Modifier.weight(0.9f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (isEnglish) "Active Jobs" else "Pekerjaan Aktif",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isEnglish) {
                                    if (activeJobs.size == 1) "1 Order" else "${activeJobs.size} Orders"
                                } else {
                                    "${activeJobs.size} Pesanan"
                                },
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    // Listings Count Card
                    Card(
                        modifier = Modifier.weight(0.9f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (isEnglish) "Services Offered" else "Jumlah Layanan",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isEnglish) {
                                    if (partnerListingsSize == 1) "1 Service" else "$partnerListingsSize Services"
                                } else {
                                    "$partnerListingsSize Jasa"
                                },
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Dynamic Earnings Summary Widget
            item {
                PartnerEarningsSummaryWidget(
                    completedBookings = completedBookings,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            // Quick add button
            item {
                Button(
                    onClick = { viewModel.navigateTo("MITRA_ADD_LISTING") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("mitra_quick_add_button")
                ) {
                    Icon(Icons.Default.AddCircleOutline, "Tambah Jasa")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Tambah Layanan Jasa Baru", fontWeight = FontWeight.Bold)
                }
            }

            // Dynamic Category Grid Component
            item {
                ServiceCategoryGrid(
                    viewModel = viewModel,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            // List Title: Incoming Bookings / Manage Bookings (Kelola Pesanan)
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Kelola Pesanan (Manage Bookings)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        
                        // Small text badge showing count
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.padding(start = 8.dp)
                        ) {
                            Text(
                                text = "${filteredActiveJobs.size} Pesanan",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Horizontal filter row for status
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val statusOptions = listOf(
                            "Aktif" to "Berjalan",
                            "Diajukan" to "Baru",
                            "Diterima" to "Diproses",
                            "Selesai" to "Selesai",
                            "Batal" to "Dibatalkan",
                            "Semua" to "Semua"
                        )

                        statusOptions.forEach { (filterVal, displayVal) ->
                            val isSelected = selectedStatusFilter == filterVal
                            Surface(
                                modifier = Modifier
                                    .clickable { selectedStatusFilter = filterVal }
                                    .testTag("mitra_filter_status_$filterVal"),
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = if (isSelected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Text(
                                    text = displayVal,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }

            if (incomingBookings.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Task,
                            contentDescription = "No Jobs",
                            modifier = Modifier.size(56.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Belum Ada Pesanan Terdaftar",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Pesanan yang masuk dari pelanggan Indonesia Anda akan tampil di sini.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            } else if (filteredActiveJobs.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = "No Filtered Jobs",
                            modifier = Modifier.size(56.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Tidak Ada Pesanan Ditemukan",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Ganti status filter atau pastikan kategori jasa Anda sesuai.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            } else {
                items(filteredActiveJobs) { booking ->
                    BookingItemCard(
                        booking = booking,
                        viewModel = viewModel,
                        onCancelClick = {
                            viewModel.updateBookingStatusAction(booking.id, booking.status, "BATAL")
                        },
                        onFinishClick = {
                            // If role is Diajukan, the button says "Terima", so action is TERIMA
                            // If role is Diterima, the button says "Selesaikan", so action is SELESAI
                            val action = if (booking.status == "Diajukan") "TERIMA" else "SELESAI"
                            viewModel.updateBookingStatusAction(booking.id, booking.status, action)
                        },
                        onChatClick = {
                            viewModel.openChatWith(booking.customerName)
                        },
                        isMitraView = true
                    )
                }
            }
        }
    }
}

@Composable
fun MitraMyListingsScreen(
    viewModel: JasaInViewModel,
    modifier: Modifier = Modifier
) {
    val profile by viewModel.userProfile.collectAsState()
    val listings by viewModel.allListings.collectAsState()
    val activeCategory by viewModel.selectedCategory.collectAsState()

    val currentPartner = profile?.name ?: "Budi Santoso"
    val partnerListings = listings.filter { it.partnerName == currentPartner }

    val filteredPartnerListings = partnerListings.filter { listing ->
        if (activeCategory == "Semua") {
            true
        } else {
            when (activeCategory) {
                "Rumah Tangga" -> listing.category == "Rumah Tangga" || listing.category == "Kebersihan" || listing.category == "Pertukangan" || listing.category == "Kebersihan & Laundry" || listing.category == "Pertukangan & Renovasi"
                "Elektronik" -> listing.category == "Elektronik" || listing.category == "Servis AC & Elektronik"
                "Edukasi" -> listing.category == "Edukasi" || listing.category == "Les Privat & Konsultasi"
                "Kecantikan & Kesehatan" -> listing.category == "Kecantikan & Kesehatan" || listing.category == "Kecantikan, Pijat & Spa" || listing.category == "Layanan Kesehatan"
                else -> listing.category == activeCategory
            }
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.navigateTo("MITRA_ADD_LISTING") },
                modifier = Modifier.testTag("add_listing_fab"),
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, "Tambah Jasa", tint = Color.White)
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            JasaInTopAppBar(
                title = "Layanan Jasa Saya",
                showModeTabs = true,
                viewModel = viewModel
            )

            if (partnerListings.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Inventory,
                        contentDescription = "Empty",
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Belum Ada Jasa Ditawarkan",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Silakan buat penawaran jasa pertama Anda agar dilihat oleh jutaan pelanggan di Indonesia.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { viewModel.navigateTo("MITRA_ADD_LISTING") },
                        modifier = Modifier.testTag("create_first_listing_btn")
                    ) {
                        Text("Buat Layanan Jasa")
                    }
                }
            } else {
                // Render ServiceCategoryGrid dynamically
                ServiceCategoryGrid(
                    viewModel = viewModel,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )

                if (filteredPartnerListings.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = "Empty Filtered",
                            modifier = Modifier.size(56.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Tidak Ada Jasa untuk Kategori: $activeCategory",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Gunakan grid di atas untuk mengganti filter atau buat jasa baru di kategori ini.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(filteredPartnerListings) { listing ->
                            PartnerListingCard(
                                listing = listing,
                                onDeleteClick = { viewModel.deleteServiceListing(listing) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PartnerListingCard(
    listing: ServiceListing,
    onDeleteClick: () -> Unit
) {
    val catColor = getCategoryColor(listing.category)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("partner_listing_card_${listing.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(catColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    CategoryIconMapper(category = listing.category, tint = catColor, modifier = Modifier.size(22.dp))
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = listing.category,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = catColor
                    )
                    Text(
                        text = listing.title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.testTag("delete_listing_${listing.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Hapus",
                        tint = Color.Red
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = listing.description,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = MaterialTheme.colorScheme.outlineVariant, thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Lokasi: ${listing.location}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = "${formatRupiah(listing.price)} / ${listing.priceUnit}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
fun MitraAddListingScreen(
    viewModel: JasaInViewModel,
    modifier: Modifier = Modifier
) {
    var title by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Rumah Tangga") }
    var priceText by remember { mutableStateOf("") }
    var priceUnit by remember { mutableStateOf("jam") }
    var description by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("Banjarmasin") }
    var availability by remember { mutableStateOf("Pagi, Siang, Sore") }

    var showError by remember { mutableStateOf<String?>(null) }
    var showCategoryDropdown by remember { mutableStateOf(false) }
    var showUnitDropdown by remember { mutableStateOf(false) }

    val categories = listOf("Rumah Tangga", "Elektronik", "Edukasi", "Kecantikan & Kesehatan")
    val units = listOf("jam", "unit", "sesi", "kunjungan", "m2", "kegiatan")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        JasaInTopAppBar(
            title = "Tambah Jasa Layanan",
            onMenuClick = { viewModel.navigateTo("MITRA_HOME") },
            viewModel = viewModel
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Formulir Jasa Baru",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Title Field
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Nama Layanan Jasa (misal: Cuci AC Berklaas)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("add_listing_title"),
                singleLine = true
            )

            // Category Selection (Simulated dropdown for stability)
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = selectedCategory,
                    onValueChange = { },
                    label = { Text("Pilih Kategori") },
                    readOnly = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showCategoryDropdown = true }
                        .testTag("add_listing_category_selector"),
                    trailingIcon = { Icon(Icons.Default.ArrowDropDown, "Buka") }
                )
                DropdownMenu(
                    expanded = showCategoryDropdown,
                    onDismissRequest = { showCategoryDropdown = false },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                ) {
                    categories.forEach { category ->
                        DropdownMenuItem(
                            text = { Text(category) },
                            onClick = {
                                selectedCategory = category
                                showCategoryDropdown = false
                            }
                        )
                    }
                }
            }

            // Price Field
            OutlinedTextField(
                value = priceText,
                onValueChange = { priceText = it },
                label = { Text("Biaya Jasa (Rp)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("add_listing_price"),
                singleLine = true
            )

            // Price Unit Selection
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = priceUnit,
                    onValueChange = { },
                    label = { Text("Satuan Tarif") },
                    readOnly = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showUnitDropdown = true }
                        .testTag("add_listing_unit_selector"),
                    trailingIcon = { Icon(Icons.Default.ArrowDropDown, "Buka") }
                )
                DropdownMenu(
                    expanded = showUnitDropdown,
                    onDismissRequest = { showUnitDropdown = false },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                ) {
                    units.forEach { unit ->
                        DropdownMenuItem(
                            text = { Text("per $unit") },
                            onClick = {
                                priceUnit = unit
                                showUnitDropdown = false
                            }
                        )
                    }
                }
            }

            // Location Field
            OutlinedTextField(
                value = location,
                onValueChange = { location = it },
                label = { Text("Kota Layanan (misal: Banjarmasin, Banjarbaru)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("add_listing_location"),
                singleLine = true
            )

            // Availability Field
            OutlinedTextField(
                value = availability,
                onValueChange = { availability = it },
                label = { Text("Ketersediaan Waktu Kerja (misal: Pagi, Siang, Sore, Malam)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("add_listing_availability"),
                placeholder = { Text("Pagi, Siang, Sore") },
                singleLine = true
            )

            // Description Field
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Deskripsi Detail Layanan") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .testTag("add_listing_description"),
                placeholder = { Text("Tulis rincian apa saja yang dikerjakan, alat yang disediakan, ketentuan jaminan dsb.") }
            )

            showError?.let { err ->
                Text(text = err, color = Color.Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    val priceVal = priceText.toDoubleOrNull() ?: 0.0
                    if (title.isBlank() || priceText.isBlank() || description.isBlank() || location.isBlank()) {
                        showError = "Mohon melengkapi semua data formulir!"
                    } else if (priceVal <= 0.0) {
                        showError = "Biaya jasa harus lebih besar dari 0!"
                    } else {
                        viewModel.addServiceListing(
                            title = title,
                            category = selectedCategory,
                            price = priceVal,
                            priceUnit = priceUnit,
                            description = description,
                            location = location,
                            availability = availability
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("submit_listing_button")
            ) {
                Icon(Icons.Default.Save, "Save")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Simpan dan Tayangkan Jasa", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun MitraProfileScreen(
    viewModel: JasaInViewModel,
    modifier: Modifier = Modifier
) {
    val profile by viewModel.userProfile.collectAsState()

    var showProfilePhotoDialog by remember { mutableStateOf(false) }
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var tempName by remember { mutableStateOf(profile?.name ?: "") }
    var tempPhone by remember { mutableStateOf(profile?.phone ?: "") }
    var tempEmail by remember { mutableStateOf(profile?.email ?: "") }
    var tempAddress by remember { mutableStateOf(profile?.address ?: "") }
    var tempDesc by remember { mutableStateOf(profile?.partnerDescription ?: "") }

    var showWithdrawDialog by remember { mutableStateOf(false) }
    var withdrawAmountText by remember { mutableStateOf("100000") }
    var selectedWithdrawMethod by remember { mutableStateOf("GoPay") }
    var withdrawAccountNo by remember { mutableStateOf("081234567890") }
    var withdrawAccountName by remember { mutableStateOf(profile?.name ?: "Budi Santoso") }
    var withdrawSuccessMessage by remember { mutableStateOf<String?>(null) }
    var withdrawErrorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        JasaInTopAppBar(
            title = "Profil Mitra",
            showModeTabs = true,
            viewModel = viewModel
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Mitra Storefront Avatar representation
            Box(
                modifier = Modifier
                    .size(96.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(90.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                        .clickable { showProfilePhotoDialog = true }
                        .testTag("mitra_profile_avatar_box"),
                    contentAlignment = Alignment.Center
                ) {
                    val photoUri = profile?.profilePictureUri
                    if (!photoUri.isNullOrEmpty()) {
                        AsyncImage(
                            model = photoUri,
                            contentDescription = "Logo Profile Mitra",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Storefront,
                            contentDescription = "Logo Profile Mitra",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                }

                // Small edit badge
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                        .align(Alignment.BottomEnd)
                        .border(1.5.dp, Color.White, CircleShape)
                        .clickable { showProfilePhotoDialog = true },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit Foto",
                        tint = Color.White,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Partner details
            Text(
                text = "${profile?.name} (Mitra)",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Star, "Rating", tint = JasaInAccent, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${profile?.partnerRating} | ${profile?.partnerCategory}",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Wallet details for income withdrawals
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Dompet Mitra (Pendapatan)", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = formatRupiah(profile?.balance ?: 0.0),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }

                    Button(
                        onClick = { showWithdrawDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = JasaInPrimary),
                        modifier = Modifier.testTag("mitra_withdraw_button")
                    ) {
                        Text("Tarik Dana", fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Partner details card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Deskripsi Jasa Anda", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = profile?.partnerDescription ?: "Penyedia jasa berpengalaman.",
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Divider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 12.dp))

                    ProfileRow(icon = Icons.Default.Phone, label = "No. Telepon Mitra", value = profile?.phone ?: "")
                    Divider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 12.dp))
                    ProfileRow(icon = Icons.Default.LocationOn, label = "Alamat Operasional", value = profile?.address ?: "")
                    Divider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 12.dp))
                    ProfileRow(icon = Icons.Default.Schedule, label = "Jadwal & Ketersediaan Layanan", value = profile?.partnerAvailability ?: "Default (Senin - Sabtu: 08:00 - 18:00)")
                    Divider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 12.dp))

                    // Dark Mode Toggle Switch row for eye comfort
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.toggleDarkMode() },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            val darkState by viewModel.isDarkMode.collectAsState()
                            Icon(
                                imageVector = if (darkState) Icons.Default.DarkMode else Icons.Default.LightMode,
                                contentDescription = "Mode Gelap",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(text = "Kenyamanan Mata", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                                Text(text = "Mode Gelap / Malam", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                        val darkState by viewModel.isDarkMode.collectAsState()
                        Switch(
                            checked = darkState,
                            onCheckedChange = { viewModel.toggleDarkMode() },
                            modifier = Modifier.testTag("dark_mode_switch")
                        )
                    }

                    Divider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 12.dp))

                    // Language Toggle Switch row for bilingual switch
                    val isEnglish = LocalIsEnglishState.current
                    val onLangToggle = LocalLanguageToggle.current
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onLangToggle() },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = Icons.Default.Translate,
                                contentDescription = "Switch Language",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(text = if (isEnglish) "Application Language" else "Bahasa Aplikasi", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                                Text(text = if (isEnglish) "English (EN)" else "Bahasa Indonesia (ID)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                        TextButton(
                            onClick = onLangToggle,
                            modifier = Modifier.testTag("mitra_profile_lang_switcher")
                        ) {
                            Text(
                                text = if (isEnglish) "SWITCH TO ID" else "UBAH KE EN",
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    TextButton(
                        onClick = {
                            tempName = profile?.name ?: ""
                            tempPhone = profile?.phone ?: ""
                            tempEmail = profile?.email ?: ""
                            tempAddress = profile?.address ?: ""
                            tempDesc = profile?.partnerDescription ?: ""
                            showEditProfileDialog = true
                        },
                        modifier = Modifier
                            .align(Alignment.End)
                            .testTag("edit_mitra_profile_btn")
                    ) {
                        Icon(Icons.Default.Edit, "Edit")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Ubah Profil Jasa")
                    }
                }
            }

            // --- PORTFOLIO SHOWCASE BLOCK ---
            val portfolioItems = remember(profile?.partnerPortfolioJson) {
                profile?.partnerPortfolioJson?.split(";")?.filter { it.isNotBlank() } ?: emptyList()
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Showcase Portofolio Mitra",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    if (portfolioItems.isEmpty()) {
                        Text(
                            text = "Belum ada item portofolio yang ditambahkan. Tambahkan karya/layanan terbaik Anda untuk menarik pelanggan!",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    } else {
                        portfolioItems.forEach { item ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Verified,
                                        contentDescription = "Verified Work",
                                        tint = JasaInPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = item,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    var showAddPortfolioDialog by remember { mutableStateOf(false) }
                    var newPortfolioText by remember { mutableStateOf("") }

                    TextButton(
                        onClick = { showAddPortfolioDialog = true },
                        modifier = Modifier
                            .align(Alignment.End)
                            .testTag("add_portfolio_btn")
                    ) {
                        Icon(Icons.Default.Add, "Tambah")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Tambah Item Portofolio")
                    }

                    if (showAddPortfolioDialog) {
                        AlertDialog(
                            onDismissRequest = { showAddPortfolioDialog = false },
                            title = { Text("Tambah Item Portofolio Baru", fontWeight = FontWeight.Bold) },
                            text = {
                                OutlinedTextField(
                                    value = newPortfolioText,
                                    onValueChange = { newPortfolioText = it },
                                    placeholder = { Text("Contoh: Cuci AC Split 15 Unit di Kantor Menara") },
                                    modifier = Modifier.fillMaxWidth().testTag("new_portfolio_input")
                                )
                            },
                            confirmButton = {
                                Button(
                                    onClick = {
                                        if (newPortfolioText.isNotBlank()) {
                                            val currentStr = profile?.partnerPortfolioJson ?: ""
                                            val updatedStr = if (currentStr.isEmpty()) newPortfolioText else "$currentStr;$newPortfolioText"
                                            viewModel.updatePartnerProfileInfo(
                                                description = profile?.partnerDescription ?: "",
                                                availability = profile?.partnerAvailability ?: "Senin - Sabtu: 08:00 - 18:00",
                                                portfolioJson = updatedStr
                                            )
                                            newPortfolioText = ""
                                        }
                                        showAddPortfolioDialog = false
                                    },
                                    modifier = Modifier.testTag("save_portfolio_confirm")
                                ) {
                                    Text("Simpan")
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { showAddPortfolioDialog = false }) {
                                    Text("Batal")
                                }
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Switch to Customer Mode Toggle in Mitra Profile
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Beralih Mode Jasa",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    UserRoleToggle(
                        currentRole = "MITRA",
                        onToggle = { viewModel.toggleUserMode() },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedButton(
                onClick = { viewModel.logoutAction() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("logout_button"),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.ExitToApp, "Keluar")
                Spacer(modifier = Modifier.width(8.dp))
                Text("Keluar dari Akun", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }

    if (showEditProfileDialog) {
        var tempAvailability by remember { mutableStateOf(profile?.partnerAvailability ?: "Senin - Sabtu: 08:00 - 18:00") }
        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            title = { Text("Ubah Profil Mitra Jasa", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = tempName, onValueChange = { tempName = it }, label = { Text("Nama Mitra") })
                    OutlinedTextField(value = tempPhone, onValueChange = { tempPhone = it }, label = { Text("No. Telepon") })
                    OutlinedTextField(value = tempEmail, onValueChange = { tempEmail = it }, label = { Text("Email") })
                    OutlinedTextField(value = tempAddress, onValueChange = { tempAddress = it }, label = { Text("Alamat") })
                    OutlinedTextField(value = tempAvailability, onValueChange = { tempAvailability = it }, label = { Text("Jadwal Ketersediaan Layanan") })
                    OutlinedTextField(
                        value = tempDesc,
                        onValueChange = { tempDesc = it },
                        label = { Text("Deskripsi Pendek Keahlian/Layanan") },
                        modifier = Modifier.height(100.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (tempName.isNotBlank() && tempPhone.isNotBlank()) {
                            viewModel.updateProfileInfo(tempName, tempPhone, tempEmail, tempAddress, tempDesc)
                            viewModel.updatePartnerProfileInfo(
                                description = tempDesc,
                                availability = tempAvailability,
                                portfolioJson = profile?.partnerPortfolioJson ?: ""
                            )
                        }
                        showEditProfileDialog = false
                    },
                    modifier = Modifier.testTag("save_mitra_profile_confirm")
                ) {
                    Text("Simpan")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }

    if (showWithdrawDialog) {
        val methods = listOf("GoPay", "OVO", "DANA", "ShopeePay", "LinkAja", "Bank BCA", "Bank Mandiri", "Bank BRI", "Bank BNI")
        AlertDialog(
            onDismissRequest = { showWithdrawDialog = false },
            title = { Text("Tarik Saldo JASAinPay", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    Text("Tarik dana aman ke bank atau e-wallet ternama di Indonesia:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Pilih Metode Transfer:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        methods.forEach { method ->
                            val isSelected = selectedWithdrawMethod == method
                            Surface(
                                modifier = Modifier
                                    .clickable { selectedWithdrawMethod = method }
                                    .testTag("withdraw_chip_$method"),
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = if (!isSelected) BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant) else null
                            ) {
                                Text(
                                    text = method,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = withdrawAccountNo,
                        onValueChange = { withdrawAccountNo = it },
                        label = { Text(if (selectedWithdrawMethod.startsWith("Bank")) "Nomor Rekening Anda" else "Nomor HP Akun E-Wallet") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("withdraw_account_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = withdrawAccountName,
                        onValueChange = { withdrawAccountName = it },
                        label = { Text("Nama Lengkap Pemilik Rekening") },
                        modifier = Modifier.fillMaxWidth().testTag("withdraw_name_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = withdrawAmountText,
                        onValueChange = { withdrawAmountText = it },
                        label = { Text("Nominal Penarikan (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("withdraw_amount_input"),
                        singleLine = true
                    )

                    if (withdrawErrorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = withdrawErrorMessage ?: "",
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = withdrawAmountText.toDoubleOrNull() ?: 0.0
                        if (amount <= 0) {
                            withdrawErrorMessage = "Nominal penarikan harus lebih besar dari 0!"
                        } else if (withdrawAccountNo.isBlank() || withdrawAccountName.isBlank()) {
                            withdrawErrorMessage = "Formulir harus diisi dengan lengkap!"
                        } else {
                            val success = viewModel.withdrawBalance(amount)
                            if (success) {
                                withdrawErrorMessage = null
                                withdrawSuccessMessage = "Selamat! Penarikan dana sebesar ${formatRupiah(amount)} sukses ditransfer melalui $selectedWithdrawMethod ke rekening $withdrawAccountNo atas nama $withdrawAccountName. Silakan cek berkala!"
                                showWithdrawDialog = false
                            } else {
                                withdrawErrorMessage = "Saldo tidak cukup untuk penarikan sebesar ${formatRupiah(amount)}!"
                            }
                        }
                    },
                    modifier = Modifier.testTag("withdraw_confirm")
                ) {
                    Text("Kirim Permintaan")
                }
            },
            dismissButton = {
                TextButton(onClick = { showWithdrawDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }

    if (withdrawSuccessMessage != null) {
        AlertDialog(
            onDismissRequest = { withdrawSuccessMessage = null },
            title = { Text("Transfer Penarikan Berhasil!", fontWeight = FontWeight.Bold) },
            text = { Text(withdrawSuccessMessage ?: "") },
            confirmButton = {
                Button(
                    onClick = { withdrawSuccessMessage = null },
                    modifier = Modifier.testTag("withdraw_success_ok")
                ) {
                    Text("OK")
                }
            }
        )
    }

    if (showProfilePhotoDialog) {
        ProfilePhotoDialog(
            onDismiss = { showProfilePhotoDialog = false },
            viewModel = viewModel,
            currentPhotoUri = profile?.profilePictureUri
        )
    }
}

@Composable
fun ProfileRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = label,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun PartnerEarningsSummaryWidget(
    completedBookings: List<Booking>,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }
    val totalEarnings = completedBookings.sumOf { it.price }

    // Calculate category breakdowns
    val categoryEarnings = remember(completedBookings) {
        completedBookings.groupBy { it.serviceCategory }
            .mapValues { (_, bookings) -> bookings.sumOf { it.price } }
            .toList()
            .sortedByDescending { it.second }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("mitra_earnings_summary_widget"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp)
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(
                                MaterialTheme.colorScheme.primaryContainer,
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = "Earnings Icon",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Ringkasan Pendapatan",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Berdasarkan pesanan selesai",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                TextButton(
                    onClick = { isExpanded = !isExpanded },
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text(
                        text = if (isExpanded) "Sembunyikan" else "Rincian",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "Expand Arrow",
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Large highlighted total amount
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Total Pendapatan Bersih",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = formatRupiah(totalEarnings),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF4CAF50).copy(alpha = 0.12f),
                    modifier = Modifier.padding(bottom = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.TrendingUp,
                            contentDescription = "Trending Up",
                            tint = Color(0xFF4CAF50),
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "${completedBookings.size} Transaksi",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )
                    }
                }
            }

            // Category Contribution breakdown (always visible, very clean & visual)
            if (categoryEarnings.isNotEmpty()) {
                Spacer(modifier = Modifier.height(18.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                Spacer(modifier = Modifier.height(14.dp))
                
                Text(
                    text = "Kontribusi per Kategori Jasa:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    categoryEarnings.forEach { (category, amount) ->
                        val ratio = if (totalEarnings > 0) (amount / totalEarnings).toFloat() else 0f
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = category,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "${formatRupiah(amount)} (${(ratio * 100).toInt()}%)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { ratio },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = MaterialTheme.colorScheme.primary,
                                trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                            )
                        }
                    }
                }
            }

            // Expanded Detail View showing itemized list
            if (isExpanded) {
                Spacer(modifier = Modifier.height(18.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Rincian Riwayat Transaksi Selesai:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                if (completedBookings.isEmpty()) {
                    Text(
                        text = "Belum ada transaksi selesai yang terdata.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = androidx.compose.ui.text.TextStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        completedBookings.forEach { booking ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                                ),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = booking.serviceTitle,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = formatRupiah(booking.price),
                                            fontWeight = FontWeight.Black,
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Pelanggan: ${booking.customerName}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "${booking.bookingDate} - ${booking.bookingTime}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    // Display Rating and customer feedback review if available
                                    if (booking.rating != null && booking.rating > 0) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.15f))
                                        Spacer(modifier = Modifier.height(6.dp))
                                        
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            StarRatingBar(rating = booking.rating.toFloat())
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = booking.reviewText ?: "Sangat puas dengan layanannya!",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                style = androidx.compose.ui.text.TextStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic),
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
