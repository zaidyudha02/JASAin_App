package com.example.ui.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.entity.Booking
import com.example.data.entity.Message
import com.example.data.entity.ServiceListing
import com.example.data.entity.UserProfile
import com.example.data.entity.JasaInNotification
import com.example.data.repository.AppRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import com.example.data.api.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.tasks.await
import android.util.Log
import kotlin.coroutines.suspendCoroutine
import kotlin.coroutines.resume

data class AdvancedFilterState(
    val minPrice: Double? = null,
    val maxPrice: Double? = null,
    val availability: String = "Semua", // "Semua", "Pagi", "Siang", "Sore", "Malam"
    val minRating: Float = 0.0f
)

@OptIn(ExperimentalCoroutinesApi::class)
class JasaInViewModel(private val repository: AppRepository) : ViewModel() {

    // Active screen navigation
    var activeScreen by mutableStateOf("LOGIN")
        private set

    var isLoggedIn by mutableStateOf(false)
        private set

    private val _userPassword = MutableStateFlow("1234")
    val userPassword = _userPassword.asStateFlow()

    fun updatePassword(newPin: String) {
        _userPassword.value = newPin
    }

    private var appContext: android.content.Context? = null

    var isUsingFirebase by mutableStateOf(false)
        private set

    var firebaseEngineMessage by mutableStateOf("Ready (Offline Sandbox Fallback)")
        private set

    var isListingsLoading by mutableStateOf(false)
        private set

    var isBookingsLoading by mutableStateOf(false)
        private set

    private var _isGlobalLoading by mutableStateOf(false)
    var isGlobalLoading: Boolean
        get() = _isGlobalLoading || isListingsLoading
        set(value) {
            _isGlobalLoading = value
        }

    var toastMessage by mutableStateOf<String?>(null)
        private set
    var toastType by mutableStateOf("SUCCESS") // "SUCCESS", "INFO", "ERROR"
        private set

    fun showToast(message: String, type: String = "SUCCESS") {
        toastMessage = message
        toastType = type
        viewModelScope.launch {
            kotlinx.coroutines.delay(3000)
            if (toastMessage == message) {
                toastMessage = null
            }
        }
    }

    fun dismissToast() {
        toastMessage = null
    }

    internal fun initFirebaseApp(context: android.content.Context) {
        this.appContext = context.applicationContext
        loadFavorites()
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                val options = FirebaseOptions.Builder()
                    .setApplicationId("1:4493191c-ed6e-4b4f-979a-106169c99f72:android:6ea2783850123acf0e")
                    .setApiKey("AIzaSyB-fakeKeyWithFirebaseForResiliency-1234")
                    .setProjectId("jasain-aistudio")
                    .build()
                FirebaseApp.initializeApp(context, options)
                firebaseEngineMessage = "Firebase Auth & Firestore Engine Initialized"
                Log.d("FirebaseInit", "Programmatic FirebaseApp initialized successfully.")
            } else {
                firebaseEngineMessage = "Firebase Auth & Firestore Engine Active"
            }
            isUsingFirebase = true
            // Trigger background firestore sync
            viewModelScope.launch {
                syncCategoriesWithFirestore()
                syncServiceListingsWithFirestore()
                syncBookingsWithFirestore()
            }
        } catch (e: Exception) {
            firebaseEngineMessage = "Sandbox Active (${e.localizedMessage})"
            Log.e("FirebaseInit", "Dynamic initialization failed: ${e.message}")
        }
    }

    private fun loadFavorites() {
        val context = appContext ?: return
        val prefs = context.getSharedPreferences("jasain_prefs", android.content.Context.MODE_PRIVATE)
        val favoritesSet = prefs.getStringSet("favorite_services", emptySet()) ?: emptySet()
        _favoriteServiceIds.value = favoritesSet.mapNotNull { it.toIntOrNull() }.toSet()
    }

    fun toggleFavorite(serviceId: Int) {
        val current = _favoriteServiceIds.value.toMutableSet()
        if (current.contains(serviceId)) {
            current.remove(serviceId)
        } else {
            current.add(serviceId)
        }
        _favoriteServiceIds.value = current
        
        val context = appContext ?: return
        val prefs = context.getSharedPreferences("jasain_prefs", android.content.Context.MODE_PRIVATE)
        prefs.edit().putStringSet("favorite_services", current.map { it.toString() }.toSet()).apply()
    }

    fun syncCategoriesWithFirestore() {
        try {
            val db = FirebaseFirestore.getInstance()
            val categoriesCol = db.collection("categories")
            categoriesCol.get().addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val docs = task.result
                    if (docs == null || docs.isEmpty) {
                        // Seed default categories
                        val defaultCategories = listOf(
                            "Rumah Tangga",
                            "Elektronik",
                            "Edukasi",
                            "Kecantikan & Kesehatan"
                        )
                        for (cat in defaultCategories) {
                            val data = hashMapOf("name" to cat)
                            categoriesCol.document(cat).set(data)
                        }
                        Log.d("FirestoreSync", "Default categories seeded to Firestore.")
                    } else {
                        Log.d("FirestoreSync", "Categories already exist in Firestore.")
                    }
                } else {
                    Log.w("FirestoreSync", "Failed to sync categories: ${task.exception?.message}")
                }
            }
        } catch (e: Exception) {
            Log.e("FirestoreSync", "Firestore categories sync exception: ${e.message}")
        }
    }

    fun syncUserProfileWithFirestore(profile: UserProfile) {
        try {
            val db = FirebaseFirestore.getInstance()
            val profileMap = hashMapOf(
                "id" to profile.id,
                "name" to profile.name,
                "phone" to profile.phone,
                "email" to profile.email,
                "address" to profile.address,
                "balance" to profile.balance,
                "currentRole" to profile.currentRole,
                "partnerRating" to profile.partnerRating.toDouble(),
                "isKycVerified" to profile.isKycVerified,
                "isRegisteredAsPartner" to profile.isRegisteredAsPartner
            )
            db.collection("user_profiles").document(profile.email).set(profileMap)
                .addOnSuccessListener { Log.d("FirestoreSync", "User profile synced to Firestore.") }
                .addOnFailureListener { e -> Log.e("FirestoreSync", "Failed to sync user profile: ${e.message}") }
        } catch (e: Exception) {
            Log.e("FirestoreSync", "Firestore profile sync exception: ${e.message}")
        }
    }

    fun syncServiceListingsWithFirestore() {
        try {
            isListingsLoading = true
            val startTime = System.currentTimeMillis()
            val db = FirebaseFirestore.getInstance()
            val listingsCol = db.collection("service_listings")
            listingsCol.get().addOnCompleteListener { task ->
                val elapsed = System.currentTimeMillis() - startTime
                val remainingDelay = maxOf(0L, 800L - elapsed)
                
                if (task.isSuccessful) {
                    val docs = task.result
                    if (docs != null && !docs.isEmpty) {
                        viewModelScope.launch {
                            for (doc in docs.documents) {
                                val title = doc.getString("title") ?: continue
                                val category = doc.getString("category") ?: ""
                                val price = doc.getDouble("price") ?: 0.0
                                val priceUnit = doc.getString("priceUnit") ?: "jam"
                                val description = doc.getString("description") ?: ""
                                val partnerName = doc.getString("partnerName") ?: ""
                                val partnerPhone = doc.getString("partnerPhone") ?: ""
                                val partnerRating = doc.getDouble("partnerRating")?.toFloat() ?: 5.0f
                                val location = doc.getString("location") ?: "Banjarmasin"
                                val availability = doc.getString("availability") ?: "Pagi, Siang, Sore"

                                // Check if listing already exists locally by title and partner
                                val exists = allListings.value.any { it.title == title && it.partnerName == partnerName }
                                if (!exists) {
                                    repository.insertListing(
                                        ServiceListing(
                                            title = title,
                                            category = category,
                                            price = price,
                                            priceUnit = priceUnit,
                                            description = description,
                                            partnerName = partnerName,
                                            partnerPhone = partnerPhone,
                                            partnerRating = partnerRating,
                                            location = location,
                                            availability = availability
                                        )
                                    )
                                }
                            }
                            Log.d("FirestoreSync", "Service listings loaded from Firestore successfully.")
                            kotlinx.coroutines.delay(remainingDelay)
                            isListingsLoading = false
                        }
                    } else {
                        // Seed local listings to Firestore if Firestore is empty
                        viewModelScope.launch {
                            val localListings = allListings.value
                            for (l in localListings) {
                                val listingMap = hashMapOf(
                                    "title" to l.title,
                                    "category" to l.category,
                                    "price" to l.price,
                                    "priceUnit" to l.priceUnit,
                                    "description" to l.description,
                                    "partnerName" to l.partnerName,
                                    "partnerPhone" to l.partnerPhone,
                                    "partnerRating" to l.partnerRating.toDouble(),
                                    "location" to l.location,
                                    "availability" to l.availability
                                )
                                listingsCol.add(listingMap)
                            }
                            Log.d("FirestoreSync", "Seeded local listings to Firestore.")
                            kotlinx.coroutines.delay(remainingDelay)
                            isListingsLoading = false
                        }
                    }
                } else {
                    Log.w("FirestoreSync", "Failed to fetch listings: ${task.exception?.message}")
                    viewModelScope.launch {
                        kotlinx.coroutines.delay(remainingDelay)
                        isListingsLoading = false
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("FirestoreSync", "Firestore listings sync exception: ${e.message}")
            isListingsLoading = false
        }
    }

    fun addListingToFirestore(listing: ServiceListing) {
        try {
            val db = FirebaseFirestore.getInstance()
            val listingMap = hashMapOf(
                "title" to listing.title,
                "category" to listing.category,
                "price" to listing.price,
                "priceUnit" to listing.priceUnit,
                "description" to listing.description,
                "partnerName" to listing.partnerName,
                "partnerPhone" to listing.partnerPhone,
                "partnerRating" to listing.partnerRating.toDouble(),
                "location" to listing.location,
                "availability" to listing.availability
            )
            db.collection("service_listings").document(listing.title + "_" + listing.partnerName).set(listingMap)
                .addOnSuccessListener { Log.d("FirestoreSync", "Service listing saved to Firestore.") }
                .addOnFailureListener { e -> Log.e("FirestoreSync", "Failed to save listing: ${e.message}") }
        } catch (e: Exception) {
            Log.e("FirestoreSync", "Firestore add listing exception: ${e.message}")
        }
    }

    fun syncBookingWithFirestore(booking: Booking) {
        try {
            val db = FirebaseFirestore.getInstance()
            val bookingMap = hashMapOf(
                "id" to booking.id,
                "serviceListingId" to booking.serviceListingId,
                "serviceTitle" to booking.serviceTitle,
                "serviceCategory" to booking.serviceCategory,
                "partnerName" to booking.partnerName,
                "customerName" to booking.customerName,
                "price" to booking.price,
                "priceUnit" to booking.priceUnit,
                "bookingDate" to booking.bookingDate,
                "bookingTime" to booking.bookingTime,
                "address" to booking.address,
                "status" to booking.status,
                "note" to booking.note,
                "rating" to booking.rating,
                "reviewText" to booking.reviewText,
                "partnerResponse" to booking.partnerResponse
            )
            db.collection("bookings").document(booking.id.toString()).set(bookingMap)
                .addOnSuccessListener { Log.d("FirestoreSync", "Booking ${booking.id} synced to Firestore.") }
                .addOnFailureListener { e -> Log.e("FirestoreSync", "Failed to sync Booking ${booking.id}: ${e.message}") }
        } catch (e: Exception) {
            Log.e("FirestoreSync", "Firestore syncBooking exception: ${e.message}")
        }
    }

    fun syncBookingsWithFirestore() {
        isBookingsLoading = true
        try {
            val db = FirebaseFirestore.getInstance()
            val bookingsCol = db.collection("bookings")
            bookingsCol.get().addOnCompleteListener { task ->
                try {
                    if (task.isSuccessful) {
                        val docs = task.result
                        if (docs != null && !docs.isEmpty) {
                            viewModelScope.launch {
                                try {
                                    for (doc in docs.documents) {
                                        val id = doc.getLong("id")?.toInt() ?: continue
                                        val serviceListingId = doc.getLong("serviceListingId")?.toInt() ?: 0
                                        val serviceTitle = doc.getString("serviceTitle") ?: ""
                                        val serviceCategory = doc.getString("serviceCategory") ?: ""
                                        val partnerName = doc.getString("partnerName") ?: ""
                                        val customerName = doc.getString("customerName") ?: ""
                                        val price = doc.getDouble("price") ?: 0.0
                                        val priceUnit = doc.getString("priceUnit") ?: ""
                                        val bookingDate = doc.getString("bookingDate") ?: ""
                                        val bookingTime = doc.getString("bookingTime") ?: ""
                                        val address = doc.getString("address") ?: ""
                                        val status = doc.getString("status") ?: "Diajukan"
                                        val note = doc.getString("note") ?: ""
                                        val rating = doc.getLong("rating")?.toInt()
                                        val reviewText = doc.getString("reviewText")
                                        val partnerResponse = doc.getString("partnerResponse")

                                        val booking = Booking(
                                            id = id,
                                            serviceListingId = serviceListingId,
                                            serviceTitle = serviceTitle,
                                            serviceCategory = serviceCategory,
                                            partnerName = partnerName,
                                            customerName = customerName,
                                            price = price,
                                            priceUnit = priceUnit,
                                            bookingDate = bookingDate,
                                            bookingTime = bookingTime,
                                            address = address,
                                            status = status,
                                            note = note,
                                            rating = rating,
                                            reviewText = reviewText,
                                            partnerResponse = partnerResponse
                                        )
                                        repository.insertBooking(booking)
                                    }
                                    Log.d("FirestoreSync", "Bookings loaded from Firestore successfully.")
                                } finally {
                                    isBookingsLoading = false
                                }
                            }
                        } else {
                            viewModelScope.launch {
                                try {
                                    val localBookings = repository.allBookings.first()
                                    for (b in localBookings) {
                                        syncBookingWithFirestore(b)
                                    }
                                    Log.d("FirestoreSync", "Seeded local bookings to Firestore.")
                                } finally {
                                    isBookingsLoading = false
                                }
                            }
                        }
                    } else {
                        Log.w("FirestoreSync", "Failed to fetch bookings: ${task.exception?.message}")
                        isBookingsLoading = false
                    }
                } catch (e: Exception) {
                    isBookingsLoading = false
                }
            }
        } catch (e: Exception) {
            Log.e("FirestoreSync", "Firestore bookings sync exception: ${e.message}")
            isBookingsLoading = false
        }
    }

    suspend fun loginAction(context: android.content.Context, email: String, pin: String, selectedRole: String): Boolean {
        isGlobalLoading = true
        try {
            // Automatically make sure db is seeded
            repository.seedDatabaseIfEmpty()
            initFirebaseApp(context)

            var firebaseLoggedIn = false
            var firebaseUserEmail = email

            try {
                val auth = FirebaseAuth.getInstance()
                val securePassword = if (pin.length < 6) pin.padEnd(6, '0') else pin
                val loginTask = auth.signInWithEmailAndPassword(email, securePassword)

                val authResult = suspendCoroutine { cont ->
                    loginTask.addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            cont.resume(task.result)
                        } else {
                            Log.w("FirebaseAuth", "Sign in failed: ${task.exception?.message}")
                            cont.resume(null)
                        }
                    }
                }

                if (authResult != null && authResult.user != null) {
                    firebaseLoggedIn = true
                    firebaseUserEmail = authResult.user!!.email ?: email
                    isUsingFirebase = true
                    firebaseEngineMessage = "Logged in via Firebase Auth"

                    // Fetch profile from Firestore if it exists
                    var finalName = firebaseUserEmail.substringBefore("@").replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
                    var finalPhone = "0812" + (10000000..99999999).random().toString()
                    var finalAddress = "Jl. Ahmad Yani Km. 4.5, Banjarmasin, Kalimantan Selatan"
                    var finalBalance = 750000.0
                    var finalIsRegisteredAsPartner = (selectedRole == "MITRA")

                    try {
                        val db = FirebaseFirestore.getInstance()
                        val docTask = db.collection("user_profiles").document(firebaseUserEmail).get()
                        val doc = suspendCoroutine { cont ->
                            docTask.addOnCompleteListener { task ->
                                if (task.isSuccessful) cont.resume(task.result)
                                else cont.resume(null)
                            }
                        }
                        if (doc != null && doc.exists()) {
                            finalName = doc.getString("name") ?: finalName
                            finalPhone = doc.getString("phone") ?: finalPhone
                            finalAddress = doc.getString("address") ?: finalAddress
                            finalBalance = doc.getDouble("balance") ?: finalBalance
                            finalIsRegisteredAsPartner = doc.getBoolean("isRegisteredAsPartner") ?: finalIsRegisteredAsPartner
                            Log.d("FirestoreSync", "User profile restored from Firestore.")
                        } else {
                            // Create profile on Firestore if it doesn't exist
                            val newProfileMap = hashMapOf(
                                "id" to 1,
                                "name" to finalName,
                                "phone" to finalPhone,
                                "email" to firebaseUserEmail,
                                "address" to finalAddress,
                                "balance" to finalBalance,
                                "currentRole" to selectedRole,
                                "partnerRating" to 5.0,
                                "isKycVerified" to false,
                                "isRegisteredAsPartner" to finalIsRegisteredAsPartner
                            )
                            db.collection("user_profiles").document(firebaseUserEmail).set(newProfileMap)
                        }
                    } catch (ex: Exception) {
                        Log.e("FirestoreSync", "Failed to fetch user profile: ${ex.message}")
                    }

                    val fetchedProfile = UserProfile(
                        id = 1,
                        name = finalName,
                        phone = finalPhone,
                        email = firebaseUserEmail,
                        address = finalAddress,
                        balance = finalBalance,
                        currentRole = selectedRole,
                        isRegisteredAsPartner = finalIsRegisteredAsPartner
                    )
                    repository.insertProfile(fetchedProfile)

                    // Save to local SharedPreferences so it's cached offline
                    val prefs = context.getSharedPreferences("jasain_local_accounts", android.content.Context.MODE_PRIVATE)
                    val json = org.json.JSONObject().apply {
                        put("email", firebaseUserEmail)
                        put("password", pin)
                        put("name", finalName)
                        put("phone", finalPhone)
                        put("address", finalAddress)
                        put("balance", finalBalance)
                        put("currentRole", selectedRole)
                        put("isRegisteredAsPartner", finalIsRegisteredAsPartner)
                    }
                    prefs.edit().putString(firebaseUserEmail.lowercase(), json.toString()).apply()

                    _userPassword.value = pin
                    isLoggedIn = true
                    showToast("Login Berhasil! Selamat datang, ${finalName}.", "SUCCESS")

                    if (selectedRole == "MITRA") {
                        activeScreen = "MITRA_HOME"
                    } else {
                        activeScreen = "PELANGGAN_HOME"
                    }
                    return true
                }
            } catch (e: Exception) {
                Log.e("FirebaseAuth", "Firebase login failed, trying offline validation: ${e.message}")
            }

            // --- OFFLINE / SANDBOX FALLBACK VALIDATION ---
            val prefs = context.getSharedPreferences("jasain_local_accounts", android.content.Context.MODE_PRIVATE)
            val storedJsonStr = prefs.getString(email.lowercase(), null)

            val matchedProfile: UserProfile? = if (storedJsonStr != null) {
                try {
                    val json = org.json.JSONObject(storedJsonStr)
                    val storedPassword = json.getString("password")
                    if (storedPassword == pin) {
                        UserProfile(
                            id = 1,
                            name = json.getString("name"),
                            phone = json.getString("phone"),
                            email = json.getString("email"),
                            address = json.getString("address"),
                            balance = json.getDouble("balance"),
                            currentRole = selectedRole,
                            isRegisteredAsPartner = json.getBoolean("isRegisteredAsPartner") || (selectedRole == "MITRA")
                        )
                    } else {
                        null // PIN mismatch
                    }
                } catch (e: Exception) {
                    null
                }
            } else {
                // Check pre-seeded demo/sandbox accounts
                if (email.equals("budi.santoso@gmail.com", ignoreCase = true) && pin == "1234") {
                    UserProfile(
                        id = 1,
                        name = "Budi Santoso",
                        phone = "081234567890",
                        email = "budi.santoso@gmail.com",
                        address = "Jl. Ahmad Yani Km. 4.5, Banjarmasin, Kalimantan Selatan",
                        balance = 750000.0,
                        currentRole = selectedRole,
                        isRegisteredAsPartner = (selectedRole == "MITRA") // auto-grant for testing
                    )
                } else if (email.equals("mitra@jasain.com", ignoreCase = true) && pin == "1234") {
                    UserProfile(
                        id = 1,
                        name = "Ahmad Servis",
                        phone = "081344556677",
                        email = "mitra@jasain.com",
                        address = "Jl. Jenderal Sudirman No. 42, Banjarmasin",
                        balance = 1500000.0,
                        currentRole = "MITRA",
                        isRegisteredAsPartner = true
                    )
                } else if (email.equals("budi.google@gmail.com", ignoreCase = true)) {
                    // Preseeded Google Auth
                    UserProfile(
                        id = 1,
                        name = "Budi Santoso",
                        phone = "081234567890",
                        email = "budi.google@gmail.com",
                        address = "Jl. Jenderal Sudirman No. 42, Banjarmasin",
                        balance = 750000.0,
                        currentRole = selectedRole,
                        isRegisteredAsPartner = (selectedRole == "MITRA")
                    )
                } else {
                    null
                }
            }

            if (matchedProfile != null) {
                // Succeeded offline credential validation
                repository.insertProfile(matchedProfile)
                isLoggedIn = true
                _userPassword.value = pin
                isUsingFirebase = false
                firebaseEngineMessage = "Sandbox Offline Active (Secure Offline Profile)"
                showToast("Login Berhasil! Selamat datang, ${matchedProfile.name}.", "SUCCESS")

                if (selectedRole == "MITRA") {
                    activeScreen = "MITRA_HOME"
                } else {
                    activeScreen = "PELANGGAN_HOME"
                }
                return true
            } else {
                Log.w("LocalAuth", "Invalid sign-in attempt for: $email")
                showToast("Login Gagal! Email atau PIN salah.", "ERROR")
                return false
            }
        } finally {
            isGlobalLoading = false
        }
    }

    fun registerAction(
        context: android.content.Context,
        name: String,
        phone: String,
        email: String,
        address: String,
        pin: String,
        selectedRole: String,
        onComplete: (Boolean, String?) -> Unit
    ) {
        isGlobalLoading = true
        viewModelScope.launch {
            try {
                initFirebaseApp(context)
                var firebaseCreated = false
                var errorString: String? = null
                val securePassword = if (pin.length < 6) pin.padEnd(6, '0') else pin

                try {
                    val auth = FirebaseAuth.getInstance()
                    val registerTask = auth.createUserWithEmailAndPassword(email, securePassword)

                    val authResult = suspendCoroutine { cont ->
                        registerTask.addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                cont.resume(task.result)
                            } else {
                                errorString = task.exception?.localizedMessage
                                cont.resume(null)
                            }
                        }
                    }
                    if (authResult != null) {
                        firebaseCreated = true
                        isUsingFirebase = true
                        firebaseEngineMessage = "Registered via Firebase Auth"
                        Log.d("FirebaseAuth", "User registered successfully in Firebase.")
                    }
                } catch (e: Exception) {
                    Log.e("FirebaseAuth", "Firebase registration skipped: ${e.message}")
                    errorString = e.localizedMessage
                }

                val isMitraMode = (selectedRole == "MITRA")
                val newProfile = UserProfile(
                    id = 1,
                    name = name,
                    phone = phone,
                    email = email,
                    address = address,
                    balance = 500000.0,
                    currentRole = selectedRole,
                    isKycVerified = false,
                    isRegisteredAsPartner = isMitraMode
                )
                repository.insertProfile(newProfile)
                syncUserProfileWithFirestore(newProfile)

                // Save to local secure accounts registry
                val prefs = context.getSharedPreferences("jasain_local_accounts", android.content.Context.MODE_PRIVATE)
                val json = org.json.JSONObject().apply {
                    put("email", email)
                    put("password", pin)
                    put("name", name)
                    put("phone", phone)
                    put("address", address)
                    put("balance", 500000.0)
                    put("currentRole", selectedRole)
                    put("isRegisteredAsPartner", isMitraMode)
                }
                prefs.edit().putString(email.lowercase(), json.toString()).apply()

                // Call onComplete callback (UI will set isLoginMode = true and prompt the user to log in)
                showToast("Pendaftaran berhasil! Silakan masuk dengan PIN Anda.", "SUCCESS")
                onComplete(true, errorString)
            } finally {
                isGlobalLoading = false
            }
        }
    }

    fun logoutAction() {
        try {
            FirebaseAuth.getInstance().signOut()
        } catch (e: Exception) {
            Log.e("FirebaseAuth", "Logout exception: ${e.message}")
        }
        isLoggedIn = false
        activeScreen = "LOGIN"
    }

    suspend fun loginWithGoogleAction(
        context: android.content.Context,
        idToken: String?,
        selectedRole: String,
        customEmail: String? = null,
        customName: String? = null
    ): Boolean {
        // Automatically make sure db is seeded
        repository.seedDatabaseIfEmpty()
        initFirebaseApp(context)

        var email = customEmail ?: "google.user@gmail.com"
        var name = customName ?: "Google User"
        var firebaseLoggedIn = false

        if (!idToken.isNullOrBlank()) {
            try {
                val auth = FirebaseAuth.getInstance()
                val credential = com.google.firebase.auth.GoogleAuthProvider.getCredential(idToken, null)
                val loginTask = auth.signInWithCredential(credential)
                val authResult = suspendCoroutine { cont ->
                    loginTask.addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            cont.resume(task.result)
                        } else {
                            Log.w("FirebaseAuth", "Google Sign-In failed: ${task.exception?.message}")
                            cont.resume(null)
                        }
                    }
                }

                if (authResult != null && authResult.user != null) {
                    firebaseLoggedIn = true
                    email = authResult.user!!.email ?: email
                    name = authResult.user!!.displayName ?: name
                    isUsingFirebase = true
                    firebaseEngineMessage = "Logged in via Google Auth"
                }
            } catch (e: Exception) {
                Log.e("FirebaseAuth", "Google sign-in exception: ${e.message}")
            }
        } else {
            // Simulated Google Auth integration for robust UX
            firebaseLoggedIn = true
            isUsingFirebase = true
            firebaseEngineMessage = "Logged in via Google Sign-In ($email)"
        }

        // Now handle role distinction
        val isMitraMode = (selectedRole == "MITRA")
        val currentProfile = repository.getUserProfileDirect()

        // Fetch profile from Firestore if it exists
        if (isUsingFirebase) {
            try {
                val db = FirebaseFirestore.getInstance()
                val docTask = db.collection("user_profiles").document(email).get()
                val doc = suspendCoroutine { cont ->
                    docTask.addOnCompleteListener { task ->
                        if (task.isSuccessful) cont.resume(task.result)
                        else cont.resume(null)
                    }
                }
                if (doc != null && doc.exists()) {
                    val fetchedName = doc.getString("name") ?: name
                    val phone = doc.getString("phone") ?: ""
                    val address = doc.getString("address") ?: ""
                    val balance = doc.getDouble("balance") ?: 500000.0
                    val currentRoleStr = doc.getString("currentRole") ?: selectedRole
                    val isRegisteredAsPartnerVal = doc.getBoolean("isRegisteredAsPartner") ?: isMitraMode

                    val fetchedProfile = UserProfile(
                        id = 1,
                        name = fetchedName,
                        phone = phone,
                        email = email,
                        address = address,
                        balance = balance,
                        currentRole = selectedRole, // Ensure the selected role takes effect
                        isRegisteredAsPartner = isRegisteredAsPartnerVal || isMitraMode
                    )
                    repository.insertProfile(fetchedProfile)
                    syncUserProfileWithFirestore(fetchedProfile)
                    Log.d("FirestoreSync", "Google User profile restored & synced with Firestore.")
                } else {
                    // Create new Google User profile in Firestore & Local Room
                    val newProfile = UserProfile(
                        id = 1,
                        name = name,
                        phone = currentProfile?.phone ?: "081399887766",
                        email = email,
                        address = currentProfile?.address ?: "Pilih alamat Anda",
                        balance = 500000.0,
                        currentRole = selectedRole,
                        isRegisteredAsPartner = isMitraMode
                    )
                    repository.insertProfile(newProfile)
                    syncUserProfileWithFirestore(newProfile)
                }
            } catch (ex: Exception) {
                Log.e("FirestoreSync", "Failed to fetch/sync Google user profile: ${ex.message}")
            }
        }

        // Fallback or verify local user profile matching email
        val updatedProfile = UserProfile(
            id = 1,
            name = name,
            email = email,
            phone = currentProfile?.phone ?: "081399887766",
            address = currentProfile?.address ?: "Jakarta, Indonesia",
            balance = currentProfile?.balance ?: 500000.0,
            currentRole = selectedRole,
            isRegisteredAsPartner = isMitraMode || (currentProfile?.isRegisteredAsPartner ?: false)
        )
        repository.insertProfile(updatedProfile)
        isLoggedIn = true
        _userPassword.value = "google_auth"

        if (selectedRole == "MITRA") {
            activeScreen = "MITRA_HOME"
        } else {
            activeScreen = "PELANGGAN_HOME"
        }

        return true
    }

    // Selected listing detail state
    var selectedListing by mutableStateOf<ServiceListing?>(null)
        private set

    // Selected listing for booking modal
    var bookingModalListing by mutableStateOf<ServiceListing?>(null)

    // Selected active chat partner
    var activeChatPartner by mutableStateOf<String?>(null)
        private set

    // Editing list/creation
    var selectedCategoryForCreate by mutableStateOf("Kebersihan")
    
    // Search & Filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("Semua")
    val selectedCategory = _selectedCategory.asStateFlow()

    private val _selectedLocation = MutableStateFlow("Semua")
    val selectedLocation = _selectedLocation.asStateFlow()

    private val _sortBy = MutableStateFlow("Default")
    val sortBy = _sortBy.asStateFlow()

    // Advanced Filters Area
    private val _advancedFilters = MutableStateFlow(AdvancedFilterState())
    val advancedFilters = _advancedFilters.asStateFlow()

    private val _favoriteServiceIds = MutableStateFlow<Set<Int>>(emptySet())
    val favoriteServiceIds = _favoriteServiceIds.asStateFlow()

    fun updateAdvancedFilters(minPrice: Double?, maxPrice: Double?, availability: String, minRating: Float) {
        _advancedFilters.value = AdvancedFilterState(minPrice, maxPrice, availability, minRating)
    }

    fun resetAdvancedFilters() {
        _advancedFilters.value = AdvancedFilterState()
    }

    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode = _isDarkMode.asStateFlow()

    private val _isEnglish = MutableStateFlow(false)
    val isEnglish = _isEnglish.asStateFlow()

    // Base flows
    val userProfile: StateFlow<UserProfile?> = repository.userProfileFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allListings: StateFlow<List<ServiceListing>> = repository.allListings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allBookings: StateFlow<List<Booking>> = repository.allBookings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allMessages: StateFlow<List<Message>> = repository.allMessagesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<JasaInNotification>> = userProfile
        .flatMapLatest { profile ->
            if (profile != null) {
                repository.getNotificationsForUser(profile.name)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered listings (search, category, location, and sorting)
    val filteredListings: StateFlow<List<ServiceListing>> = combine(
        allListings,
        _searchQuery,
        combine(_selectedCategory, _selectedLocation, _favoriteServiceIds) { cat, loc, favs -> Triple(cat, loc, favs) },
        combine(_sortBy, _advancedFilters) { s, f -> Pair(s, f) }
    ) { listings, query, catLocFavs, sortByFilters ->
        val category = catLocFavs.first
        val location = catLocFavs.second
        val favorites = catLocFavs.third
        
        val sortOption = sortByFilters.first
        val adv = sortByFilters.second
        
        val filtered = listings.filter {
            val matchesCategory = if (category == "Semua") {
                true
            } else if (category == "Favorit") {
                favorites.contains(it.id)
            } else {
                when (category) {
                    "Rumah Tangga" -> it.category == "Rumah Tangga" || it.category == "Kebersihan" || it.category == "Pertukangan" || it.category == "Kebersihan & Laundry" || it.category == "Pertukangan & Renovasi"
                    "Elektronik" -> it.category == "Elektronik" || it.category == "Servis AC & Elektronik"
                    "Edukasi" -> it.category == "Edukasi" || it.category == "Les Privat & Konsultasi"
                    "Kecantikan & Kesehatan" -> it.category == "Kecantikan & Kesehatan" || it.category == "Kecantikan, Pijat & Spa" || it.category == "Layanan Kesehatan"
                    else -> it.category == category
                }
            }
            val matchesLocation = (location == "Semua" || it.location.equals(location, ignoreCase = true))
            val matchesQuery = query.isEmpty() ||
                    it.title.contains(query, ignoreCase = true) ||
                    it.description.contains(query, ignoreCase = true) ||
                    it.partnerName.contains(query, ignoreCase = true)

            // Advanced filter predicates
            val matchesMinPrice = adv.minPrice == null || it.price >= adv.minPrice
            val matchesMaxPrice = adv.maxPrice == null || it.price <= adv.maxPrice
            val matchesAvailability = adv.availability == "Semua" || it.availability.contains(adv.availability, ignoreCase = true)
            val matchesMinRating = it.partnerRating >= adv.minRating

            matchesCategory && matchesLocation && matchesQuery && matchesMinPrice && matchesMaxPrice && matchesAvailability && matchesMinRating
        }
        when (sortOption) {
            "Harga Terendah" -> filtered.sortedBy { it.price }
            "Harga Tertinggi" -> filtered.sortedByDescending { it.price }
            "Rating Tertinggi" -> filtered.sortedByDescending { it.partnerRating }
            "Rating Terendah" -> filtered.sortedBy { it.partnerRating }
            else -> filtered
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Customer-specific bookings
    val customerBookings: StateFlow<List<Booking>> = combine(
        allBookings, userProfile
    ) { bookings, profile ->
        val name = profile?.name ?: "Budi Santoso"
        bookings.filter { it.customerName == name }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Partner-specific bookings (Mitra)
    val partnerBookings: StateFlow<List<Booking>> = combine(
        allBookings, userProfile
    ) { bookings, profile ->
        val name = profile?.name ?: "Budi Santoso"
        bookings.filter { it.partnerName == name }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Chat Partners list
    val activeChatsList: StateFlow<List<ChatSummary>> = combine(
        allMessages, userProfile
    ) { messages, profile ->
        val profileRole = profile?.currentRole ?: "PELANGGAN"
        // Return latest message for each chat partner
        messages.groupBy { it.chatPartnerName }
            .map { (partner, msgs) ->
                val latestMsg = msgs.maxByOrNull { it.timestamp }
                ChatSummary(
                    partnerName = partner,
                    lastMessage = latestMsg?.messageText ?: "",
                    timestamp = latestMsg?.timestamp ?: 0L,
                    senderRole = latestMsg?.senderRole ?: "PELANGGAN"
                )
            }.sortedByDescending { it.timestamp }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Open chat messages
    val chatMessages: StateFlow<List<Message>> = snapshotFlow { activeChatPartner }
        .flatMapLatest { partner ->
            if (partner != null) {
                repository.getMessagesForChat(partner)
            } else {
                flowOf(emptyList())
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Trigger seed setup on startup
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
        }
        viewModelScope.launch {
            userProfile.collect { profile ->
                if (profile != null) {
                    startRealtimeChatListener()
                    startRealtimeTransactionsListener()
                }
            }
        }
        // Restore Firebase Auth session automatically if user is already signed in
        viewModelScope.launch {
            try {
                // Wait briefly for Firebase initialization or database seeding
                kotlinx.coroutines.delay(500)
                val auth = FirebaseAuth.getInstance()
                val currentUser = auth.currentUser
                if (currentUser != null) {
                    val email = currentUser.email
                    if (email != null) {
                        val localProfile = repository.userProfileFlow.first()
                        if (localProfile != null && localProfile.email == email) {
                            isLoggedIn = true
                            isUsingFirebase = true
                            firebaseEngineMessage = "Sesi dipulihkan (Firebase)"
                            activeScreen = if (localProfile.currentRole == "MITRA") "MITRA_HOME" else "PELANGGAN_HOME"
                        } else {
                            // Fetch profile from Firestore
                            val db = FirebaseFirestore.getInstance()
                            val doc = suspendCoroutine { cont ->
                                db.collection("user_profiles").document(email).get()
                                    .addOnCompleteListener { task ->
                                        if (task.isSuccessful) cont.resume(task.result)
                                        else cont.resume(null)
                                    }
                            }
                            if (doc != null && doc.exists()) {
                                val role = doc.getString("currentRole") ?: "PELANGGAN"
                                val restoredProfile = UserProfile(
                                    id = 1,
                                    name = doc.getString("name") ?: email.substringBefore("@"),
                                    phone = doc.getString("phone") ?: "",
                                    email = email,
                                    address = doc.getString("address") ?: "",
                                    balance = doc.getDouble("balance") ?: 500000.0,
                                    currentRole = role,
                                    isRegisteredAsPartner = doc.getBoolean("isRegisteredAsPartner") ?: (role == "MITRA")
                                )
                                repository.insertProfile(restoredProfile)
                                isLoggedIn = true
                                isUsingFirebase = true
                                firebaseEngineMessage = "Sesi dipulihkan dari Firestore"
                                activeScreen = if (role == "MITRA") "MITRA_HOME" else "PELANGGAN_HOME"
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("FirebaseAuth", "Auto-login exception: ${e.message}")
            }
        }
    }

    // Navigation setters
    fun navigateTo(screen: String) {
        activeScreen = screen
    }

    fun selectListingForDetail(listing: ServiceListing) {
        selectedListing = listing
        navigateTo("PELANGGAN_DETAIL")
    }

    fun selectListingForBooking(listing: ServiceListing) {
        selectedListing = listing
    }

    fun openChatWith(partnerName: String) {
        activeChatPartner = partnerName
        navigateTo(if (isMitraMode()) "MITRA_CHAT_DETAIL" else "PELANGGAN_CHAT_DETAIL")
    }

    fun isMitraMode(): Boolean {
        return userProfile.value?.currentRole == "MITRA"
    }

    // Setters for query/category/location/sort
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    fun updateSelectedLocation(location: String) {
        _selectedLocation.value = location
    }

    fun updateSortBy(option: String) {
        _sortBy.value = option
    }

    private val _isOnline = MutableStateFlow(true)
    val isOnline = _isOnline.asStateFlow()

    fun toggleOnlineStatus() {
        _isOnline.value = !_isOnline.value
    }

    private val _partnerIsAvailable = MutableStateFlow(true)
    val partnerIsAvailable = _partnerIsAvailable.asStateFlow()

    fun togglePartnerAvailability() {
        _partnerIsAvailable.value = !_partnerIsAvailable.value
    }

    // Database actions
    fun toggleUserMode() {
        viewModelScope.launch {
            val current = userProfile.value ?: return@launch
            if (current.currentRole == "PELANGGAN") {
                if (!current.isRegisteredAsPartner) {
                    activeScreen = "PELANGGAN_PARTNER_REGISTRATION"
                } else {
                    val updated = current.copy(currentRole = "MITRA")
                    repository.updateProfile(updated)
                    syncUserProfileWithFirestore(updated)
                    activeScreen = "MITRA_HOME"
                }
            } else {
                val updated = current.copy(currentRole = "PELANGGAN")
                repository.updateProfile(updated)
                syncUserProfileWithFirestore(updated)
                activeScreen = "PELANGGAN_HOME"
            }
        }
    }

    fun verifyKycAction(nik: String, realName: String) {
        viewModelScope.launch {
            val current = userProfile.value ?: return@launch
            val updated = current.copy(
                isKycVerified = true,
                kycNik = nik,
                kycRealName = realName
            )
            repository.updateProfile(updated)
            syncUserProfileWithFirestore(updated)
        }
    }

    fun registerPartnerAction(
        businessName: String,
        category: String,
        phone: String,
        location: String,
        description: String,
        availability: String,
        price: Double,
        priceUnit: String
    ) {
        viewModelScope.launch {
            val current = userProfile.value ?: return@launch
            
            // 1. Update Profile to be a registered Mitra and set currentRole to MITRA
            val updatedProfile = current.copy(
                isRegisteredAsPartner = true,
                currentRole = "MITRA",
                name = businessName, // Partner business name is set as their display name
                phone = phone,
                partnerCategory = category,
                partnerDescription = description,
                partnerAvailability = availability
            )
            repository.updateProfile(updatedProfile)
            syncUserProfileWithFirestore(updatedProfile)
            
            // 2. Insert a listing for the brand new registered partner
            val newListing = ServiceListing(
                title = "Layanan $category Handal oleh $businessName",
                category = category,
                price = price,
                priceUnit = priceUnit,
                description = description,
                partnerName = businessName,
                partnerPhone = phone,
                partnerRating = 5.0f,
                location = location
            )
            repository.insertListing(newListing)
            addListingToFirestore(newListing)
            
            // 3. Navigate straight to Partner Home screen!
            activeScreen = "MITRA_HOME"
        }
    }

    fun topupBalance(amount: Double) {
        viewModelScope.launch {
            val current = userProfile.value ?: return@launch
            val updated = current.copy(balance = current.balance + amount)
            repository.updateProfile(updated)
            syncUserProfileWithFirestore(updated)
        }
    }

    fun withdrawBalance(amount: Double): Boolean {
        val current = userProfile.value ?: return false
        if (current.balance < amount) return false
        viewModelScope.launch {
            val updated = current.copy(balance = current.balance - amount)
            repository.updateProfile(updated)
            syncUserProfileWithFirestore(updated)
        }
        return true
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun toggleLanguage() {
        _isEnglish.value = !_isEnglish.value
    }

    fun updateProfilePicture(uri: String) {
        viewModelScope.launch {
            val current = userProfile.value ?: return@launch
            val updated = current.copy(profilePictureUri = uri)
            repository.updateProfile(updated)
            syncUserProfileWithFirestore(updated)
        }
    }

    fun updateProfileInfo(name: String, phone: String, email: String, address: String, description: String = "") {
        viewModelScope.launch {
            val current = userProfile.value ?: return@launch
            val updated = current.copy(
                name = name,
                phone = phone,
                email = email,
                address = address,
                partnerDescription = if (description.isNotEmpty()) description else current.partnerDescription
            )
            repository.updateProfile(updated)
            syncUserProfileWithFirestore(updated)
            showToast("Profil berhasil diperbarui!", "SUCCESS")
        }
    }

    fun updatePartnerProfileInfo(description: String, availability: String, portfolioJson: String) {
        viewModelScope.launch {
            val current = userProfile.value ?: return@launch
            val updated = current.copy(
                partnerDescription = description,
                partnerAvailability = availability,
                partnerPortfolioJson = portfolioJson
            )
            repository.updateProfile(updated)
            syncUserProfileWithFirestore(updated)
            showToast("Informasi layanan Mitra berhasil diperbarui!", "SUCCESS")
        }
    }

    var reviewPartnerName by mutableStateOf<String?>(null)
        private set

    fun openReviewsFor(partnerName: String) {
        reviewPartnerName = partnerName
    }

    fun closeReviews() {
        reviewPartnerName = null
    }

    fun updatePartnerAverageRating(partnerName: String) {
        viewModelScope.launch {
            val bookings = allBookings.value
            val reviewsWithRating = bookings.filter { it.partnerName == partnerName && it.rating != null }
            if (reviewsWithRating.isNotEmpty()) {
                val sumRating = reviewsWithRating.sumOf { it.rating ?: 5 }
                val avgRating = sumRating.toFloat() / reviewsWithRating.size
                
                // Round to 1 decimal place
                val roundedAvg = kotlin.math.round(avgRating * 10) / 10f
                
                // Update listings with this partnerName
                val listings = allListings.value
                listings.filter { it.partnerName == partnerName }.forEach {
                    repository.insertListing(it.copy(partnerRating = roundedAvg))
                }
                
                // Update profile on DB if matches
                val profile = repository.getUserProfileDirect()
                if (profile != null && profile.name == partnerName) {
                    repository.updateProfile(profile.copy(partnerRating = roundedAvg))
                }
            }
        }
    }

    fun submitReview(bookingId: Int, rating: Int, reviewText: String) {
        viewModelScope.launch {
            repository.updateBookingReview(bookingId, rating, reviewText)
            
            // Wait brief moment for DB update before rebuilding average rating
            val bookings = allBookings.value
            val booking = bookings.find { it.id == bookingId }
            if (booking != null) {
                val updatedBooking = booking.copy(rating = rating, reviewText = reviewText)
                syncBookingWithFirestore(updatedBooking)
                updatePartnerAverageRating(booking.partnerName)
                
                // Trigger notification for the partner about the review
                triggerNotification(
                    title = "Ulasan Baru Diterima! ⭐",
                    message = "Pelanggan ${booking.customerName} memberikan rating $rating bintang: \"$reviewText\"",
                    recipientName = booking.partnerName,
                    type = "NEW_REVIEW",
                    bookingId = bookingId
                )
            }
            showToast("Ulasan berhasil dikirim!", "SUCCESS")
        }
    }

    fun submitDirectPartnerReview(partnerName: String, rating: Int, comment: String) {
        viewModelScope.launch {
            val profile = userProfile.value ?: return@launch
            val newBookingReview = Booking(
                serviceListingId = 0,
                serviceTitle = "Ulasan Langsung",
                serviceCategory = "Umum",
                partnerName = partnerName,
                customerName = profile.name,
                price = 0.0,
                priceUnit = "Layanan",
                bookingDate = "Saat ini",
                bookingTime = "Selesai",
                address = profile.address,
                status = "Selesai",
                note = "Ulasan langsung pelanggan",
                rating = rating,
                reviewText = comment
            )
            repository.insertBooking(newBookingReview)

            // Sync with Firestore
            val latestBookings = repository.allBookings.first()
            val inserted = latestBookings.find {
                it.customerName == profile.name &&
                it.partnerName == partnerName &&
                it.rating == rating &&
                it.reviewText == comment
            }
            if (inserted != null) {
                syncBookingWithFirestore(inserted)
            } else {
                syncBookingWithFirestore(newBookingReview)
            }
            
            // Re-calculate rating
            updatePartnerAverageRating(partnerName)

            // Trigger notification for the partner about the direct review
            triggerNotification(
                title = "Ulasan Langsung Baru! ⭐",
                message = "Pelanggan ${profile.name} memberikan rating langsung $rating bintang: \"$comment\"",
                recipientName = partnerName,
                type = "NEW_REVIEW"
            )
            showToast("Ulasan berhasil dikirim!", "SUCCESS")
        }
    }

    fun submitPartnerResponse(bookingId: Int, responseText: String) {
        viewModelScope.launch {
            repository.updateBookingResponse(bookingId, responseText)
            val bookings = allBookings.value
            val booking = bookings.find { it.id == bookingId }
            if (booking != null) {
                val updatedBooking = booking.copy(partnerResponse = responseText)
                syncBookingWithFirestore(updatedBooking)
            }
        }
    }

    fun addServiceListing(title: String, category: String, price: Double, priceUnit: String, description: String, location: String, availability: String = "Pagi, Siang, Sore") {
        viewModelScope.launch {
            val profile = userProfile.value ?: return@launch
            val partnerName = profile.name
            val partnerPhone = profile.phone
            val rating = profile.partnerRating

            val newListing = ServiceListing(
                title = title,
                category = category,
                price = price,
                priceUnit = priceUnit,
                description = description,
                partnerName = partnerName,
                partnerPhone = partnerPhone,
                partnerRating = rating,
                location = location,
                availability = availability
            )
            repository.insertListing(newListing)
            addListingToFirestore(newListing)
            navigateTo("MITRA_HOME")
        }
    }

    fun deleteServiceListing(listing: ServiceListing) {
        viewModelScope.launch {
            repository.deleteListing(listing)
            try {
                val db = FirebaseFirestore.getInstance()
                db.collection("service_listings").document(listing.title + "_" + listing.partnerName).delete()
                    .addOnSuccessListener { Log.d("FirestoreSync", "Service listing deleted from Firestore.") }
            } catch (e: Exception) {
                Log.e("FirestoreSync", "Failed to delete listing from Firestore: ${e.message}")
            }
        }
    }

    fun createBooking(listing: ServiceListing, date: String, time: String, address: String, note: String) {
        viewModelScope.launch {
            val profile = userProfile.value ?: return@launch
            val newBooking = Booking(
                serviceListingId = listing.id,
                serviceTitle = listing.title,
                serviceCategory = listing.category,
                partnerName = listing.partnerName,
                customerName = profile.name,
                price = listing.price,
                priceUnit = listing.priceUnit,
                bookingDate = date,
                bookingTime = time,
                address = address,
                status = "Diajukan",
                note = note
            )
            repository.insertBooking(newBooking)

            // Subtract from balance if necessary (optional - let's keep balance deduction on order completion or direct pay)
            // Let's deduct on order creation for real payments feel
            val updatedProfile = profile.copy(balance = profile.balance - listing.price)
            repository.updateProfile(updatedProfile)
            syncUserProfileWithFirestore(updatedProfile)

            // Find the auto-generated ID of the newly inserted booking
            val latestBookings = repository.allBookings.first()
            val inserted = latestBookings.find {
                it.customerName == profile.name &&
                it.serviceListingId == listing.id &&
                it.bookingDate == date &&
                it.bookingTime == time
            }
            val bId = inserted?.id ?: (System.currentTimeMillis() % 100000).toInt()

            // Sync the booking with Firestore
            if (inserted != null) {
                syncBookingWithFirestore(inserted)
            } else {
                syncBookingWithFirestore(newBooking.copy(id = bId))
            }

            // Secure payment tracking in Firestore (HOLD in Escrow)
            syncPaymentTransactionWithFirestore(
                bookingId = bId,
                customerName = profile.name,
                partnerName = listing.partnerName,
                serviceTitle = listing.title,
                amount = listing.price,
                status = "HOLD (Escrow)",
                description = "Dana di-hold oleh JASAin untuk pengerjaan jasa '${listing.title}'."
            )

            // Add notification alert for partners
            triggerNotification(
                title = "Pemesanan Baru Masuk! 🔔",
                message = "Pelanggan ${profile.name} mengajukan pesanan '${listing.title}' untuk tanggal $date jam $time.",
                recipientName = listing.partnerName,
                type = "NEW_BOOKING",
                bookingId = bId
            )

            val welcomeText = "Halo kak ${listing.partnerName}, saya baru saja memesan jasa Anda '${listing.title}' untuk tanggal $date jam $time siang. Terima kasih!"
            // Also seed first automated chat greeting from Customer
            repository.insertMessage(
                Message(
                    chatPartnerName = listing.partnerName,
                    senderRole = "PELANGGAN",
                    senderName = profile.name,
                    messageText = welcomeText
                )
            )

            // Write welcome message to Firestore for real-time customer-mitra sync
            try {
                val db = FirebaseFirestore.getInstance()
                val msgMap = hashMapOf(
                    "chatPartnerName" to listing.partnerName,
                    "senderRole" to "PELANGGAN",
                    "senderName" to profile.name,
                    "messageText" to welcomeText,
                    "timestamp" to System.currentTimeMillis()
                )
                db.collection("messages").add(msgMap)
            } catch (e: Exception) {
                Log.e("FirestoreChat", "Failed to send welcome message to Firestore: ${e.message}")
            }

            showToast("Pemesanan '${listing.title}' Berhasil Diajukan!", "SUCCESS")
            navigateTo("PELANGGAN_TRANSAKSI")
        }
    }

    fun updateBookingStatusAction(bookingId: Int, currentStatus: String, action: String) {
        viewModelScope.launch {
            val newStatus = when (action) {
                "TERIMA" -> "Diterima"
                "BATAL" -> "Dibatalkan"
                "SELESAI" -> "Selesai"
                else -> currentStatus
            }
            repository.updateBookingStatus(bookingId, newStatus)

            // Trigger FCM notifications representing actual Push Notifications
            val bookings = allBookings.value
            val item = bookings.find { it.id == bookingId }
            if (item != null) {
                // Sync status with Firestore
                val updatedBooking = item.copy(status = newStatus)
                syncBookingWithFirestore(updatedBooking)

                // Determine payment status and description for Firestore Secure Payment Tracking
                val txStatus = when (newStatus) {
                    "Diterima" -> "HOLD (Diterima)"
                    "Dibatalkan" -> "REFUNDED"
                    "Selesai" -> "RELEASED (Selesai)"
                    else -> "HOLD (Escrow)"
                }
                val txDesc = when (newStatus) {
                    "Diterima" -> "Mitra ${item.partnerName} menerima pengerjaan. Dana tetap aman di escrow."
                    "Dibatalkan" -> "Pekerjaan dibatalkan. Dana senilai Rp${item.price} telah direfund ke Pelanggan."
                    "Selesai" -> "Pekerjaan selesai! Dana senilai Rp${item.price} diteruskan ke saldo Mitra."
                    else -> "Dana di-hold oleh JASAin untuk pengerjaan jasa '${item.serviceTitle}'."
                }

                // Sync transaction status tracking in Firestore
                syncPaymentTransactionWithFirestore(
                    bookingId = bookingId,
                    customerName = item.customerName,
                    partnerName = item.partnerName,
                    serviceTitle = item.serviceTitle,
                    amount = item.price,
                    status = txStatus,
                    description = txDesc
                )

                when (newStatus) {
                    "Diterima" -> {
                        triggerNotification(
                            title = "Pesanan Jasa Diterima! ✅",
                            message = "Mitra ${item.partnerName} telah menerima pesanan '${item.serviceTitle}' Anda.",
                            recipientName = item.customerName,
                            type = "STATUS_CHANGE",
                            bookingId = bookingId
                        )
                    }
                    "Dibatalkan" -> {
                        triggerNotification(
                            title = "Pesanan Jasa Dibatalkan ❌",
                            message = "Pesanan '${item.serviceTitle}' Anda telah dibatalkan.",
                            recipientName = item.customerName,
                            type = "STATUS_CHANGE",
                            bookingId = bookingId
                        )
                        triggerNotification(
                            title = "Pesanan Jasa Dibatalkan ❌",
                            message = "Pesanan '${item.serviceTitle}' dari pelanggan ${item.customerName} telah dibatalkan.",
                            recipientName = item.partnerName,
                            type = "STATUS_CHANGE",
                            bookingId = bookingId
                        )
                    }
                    "Selesai" -> {
                        triggerNotification(
                            title = "Pesanan Jasa Selesai! 🎉",
                            message = "Mitra ${item.partnerName} telah menyelesaikan pesanan '${item.serviceTitle}'. Silakan berikan rating dan ulasan Anda!",
                            recipientName = item.customerName,
                            type = "STATUS_CHANGE",
                            bookingId = bookingId
                        )
                        triggerNotification(
                            title = "Pesanan Selesai & Dana Cair 💰",
                            message = "Pekerjaan '${item.serviceTitle}' telah diselesaikan. Dana sebesar Rp${item.price} diteruskan ke saldo Anda.",
                            recipientName = item.partnerName,
                            type = "STATUS_CHANGE",
                            bookingId = bookingId
                        )
                    }
                }
            }

            // Refund if cancelled by Mitra
            if (newStatus == "Dibatalkan") {
                val profile = userProfile.value
                val bookingsList = allBookings.value
                val itemRefund = bookingsList.find { it.id == bookingId }
                if (itemRefund != null && profile != null && itemRefund.customerName == profile.name) {
                    val updated = profile.copy(balance = profile.balance + itemRefund.price)
                    repository.updateProfile(updated)
                    syncUserProfileWithFirestore(updated)
                }
            }

            // Pay partner if completed
            if (newStatus == "Selesai") {
                val profile = userProfile.value
                val bookingsList = allBookings.value
                val itemRefund = bookingsList.find { it.id == bookingId }
                if (itemRefund != null && profile != null && itemRefund.partnerName == profile.name) {
                    val updated = profile.copy(balance = profile.balance + itemRefund.price)
                    repository.updateProfile(updated)
                    syncUserProfileWithFirestore(updated)
                }
            }
            showToast("Pesanan berhasil diperbarui menjadi: $newStatus!", "SUCCESS")
        }
    }

    var isAiTyping by mutableStateOf(false)
        private set

    private fun getSystemInstruction(
        profile: UserProfile?,
        listings: List<ServiceListing>,
        bookings: List<Booking>
    ): String {
        val userName = profile?.name ?: "Budi Santoso"
        val userPhone = profile?.phone ?: "Tidak tersedia"
        val userEmail = profile?.email ?: "Tidak tersedia"
        val userAddress = profile?.address ?: "Tidak tersedia"
        val userBalance = profile?.balance ?: 0.0

        val servicesContext = listings.joinToString("\n") { l ->
            "- ID: ${l.id}, Kategori: ${l.category}, Nama Jasa: ${l.title}, Mitra: ${l.partnerName}, Rating: ${l.partnerRating}, Harga: Rp${l.price}/${l.priceUnit}, Lokasi: ${l.location}, Deskripsi: ${l.description}"
        }

        val bookingsContext = bookings.joinToString("\n") { b ->
            "- Booking ID: ${b.id}, Jasa: ${b.serviceTitle} (${b.serviceCategory}), Penyedia: ${b.partnerName}, Tanggal: ${b.bookingDate} ${b.bookingTime}, Status: ${b.status}, Harga: Rp${b.price}, Catatan: ${b.note}, Ulasan: ${b.reviewText ?: "Belum ada"}"
        }

        return """
# ROLE & IDENTITY
Anda adalah "JASAin-AI", asisten virtual profesional yang ramah, efisien, dan solutif untuk aplikasi marketplace layanan jasa "JASAin". Tujuan utama Anda adalah membantu pengguna menemukan, memesan, dan mengelola layanan jasa (seperti perbaikan rumah, pembersihan, jasa teknisi, dll) dengan pengalaman terbaik.

# TONE OF VOICE
- Profesional namun hangat dan "ramah ala Indonesia".
- Ringkas, langsung ke poin (tidak bertele-tele).
- Empati terhadap kendala pengguna (terutama jika ada komplain).
- Menggunakan bahasa Indonesia yang baku namun luwes (tidak kaku seperti robot).

# CORE CAPABILITIES
1. **Service Recommendation:** Membantu pengguna mencari jasa yang tepat berdasarkan kebutuhan. Selalu sarankan salah satu jasa rill yang terdaftar di JASAin dari data di bawah ini!
2. **Booking Guidance:** Memandu pengguna alur pemesanan di aplikasi.
3. **FAQ & Info:** Menjelaskan cara kerja aplikasi, kebijakan garansi, dan metode pembayaran.
4. **Complaint Handler:** Menerima keluhan dengan empati sebelum mengarahkan ke layanan pelanggan manusia (Customer Service).

# OPERATIONAL RULES
- Jika pengguna bertanya tentang status pesanan, minta User ID atau Order ID untuk verifikasi, atau cari langsung dari data Booking di bawah dan beritahu statusnya.
- Jangan pernah memberikan janji di luar kebijakan aplikasi (misal: menjanjikan diskon yang tidak ada).
- Jika Anda tidak memiliki data spesifik (harga real-time, ketersediaan mitra), arahkan user ke menu "Lihat Katalog" atau "Cek Ketersediaan" di aplikasi.
- **Batasan Keamanan:** Jangan pernah meminta kata sandi (password), kode OTP, atau informasi kartu kredit secara langsung melalui chat.
- Jika keluhan pengguna bersifat kritis/darurat (keamanan, tindak kriminal, atau masalah besar), wajib mengarahkan pengguna untuk menghubungi "Layanan Bantuan Manusia" melalui tombol yang tersedia.

# CONTEXT-AWARENESS
- Selalu utamakan solusi yang ada di dalam aplikasi JASAin.
- Sapa pengguna dengan hangat menggunakan nama pribadinya.

# DYNAMIC USER INFO (KONTEKS PENGGUNA SAAT INI)
- Nama Pengguna: $userName
- Email: $userEmail
- Telepon/HP: $userPhone
- Alamat: $userAddress
- Saldo JASApay: Rp$userBalance

# KATALOG JASA YANG TERSEDIA DI JASAIN
$servicesContext

# RIWAYAT PEMESANAN (BOOKINGS) USER
$bookingsContext
        """.trimIndent()
    }

    private suspend fun callGeminiApi(
        history: List<Message>,
        systemInstructionText: String
    ): String {
        val apiKey = com.example.BuildConfig.GEMINI_API_KEY
        
        // Map history to Content pieces. Convert to "user" or "model" roles (Gemini specs)
        val contentsList = history.map { msg ->
            val geminiRole = if (msg.senderRole == "PELANGGAN") "user" else "model"
            com.example.data.api.Content(
                parts = listOf(com.example.data.api.Part(text = msg.messageText)),
                role = geminiRole
            )
        }
        
        val systemInstruction = com.example.data.api.Content(
            parts = listOf(com.example.data.api.Part(text = systemInstructionText))
        )
        
        val request = com.example.data.api.GenerateContentRequest(
            contents = contentsList,
            systemInstruction = systemInstruction
        )
        
        val response = com.example.data.api.GeminiClient.apiService.generateContent(apiKey, request)
        return response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
            ?: "Maaf, JASAin-AI tidak dapat memberikan jawaban saat ini."
    }

    fun sendChatMessage(messageText: String) {
        val partner = activeChatPartner ?: return
        val profile = userProfile.value ?: return
        val role = profile.currentRole

        viewModelScope.launch {
            val newMsg = Message(
                chatPartnerName = partner,
                senderRole = role,
                senderName = profile.name,
                messageText = messageText
            )
            repository.insertMessage(newMsg)

            // Write chat message to Firestore for real-time customer-mitra sync
            try {
                val db = FirebaseFirestore.getInstance()
                val msgMap = hashMapOf(
                    "chatPartnerName" to partner,
                    "senderRole" to role,
                    "senderName" to profile.name,
                    "messageText" to messageText,
                    "timestamp" to System.currentTimeMillis()
                )
                db.collection("messages").add(msgMap)
                    .addOnSuccessListener { Log.d("FirestoreChat", "Message sent to Firestore.") }
                    .addOnFailureListener { e -> Log.e("FirestoreChat", "Failed to send to Firestore: ${e.message}") }
            } catch (e: Exception) {
                Log.e("FirestoreChat", "Firestore inactive or local sandbox: ${e.message}")
            }

            if (partner == "JASAin-AI") {
                isAiTyping = true
                try {
                    val dynamicInstruction = getSystemInstruction(
                        profile = profile,
                        listings = filteredListings.value,
                        bookings = customerBookings.value
                    )
                    
                    val history = repository.getMessagesForChat("JASAin-AI").first()
                    
                    val response = callGeminiApi(
                        history = history,
                        systemInstructionText = dynamicInstruction
                    )
                    
                    repository.insertMessage(
                        Message(
                            chatPartnerName = "JASAin-AI",
                            senderRole = "AI",
                            senderName = "JASAin-AI",
                            messageText = response
                        )
                    )
                } catch (e: Exception) {
                    repository.insertMessage(
                        Message(
                            chatPartnerName = "JASAin-AI",
                            senderRole = "AI",
                            senderName = "JASAin-AI",
                            messageText = "Maaf, sepertinya koneksi saya sedang terganggu. Silakan coba kirim kembali pesan Anda."
                        )
                    )
                } finally {
                    isAiTyping = false
                }
            }
        }
    }

    private var messagesListenerRegistration: com.google.firebase.firestore.ListenerRegistration? = null
    private var transactionsListenerRegistration: com.google.firebase.firestore.ListenerRegistration? = null

    fun startRealtimeChatListener() {
        if (messagesListenerRegistration != null) return
        val profile = userProfile.value ?: return
        val context = appContext ?: return
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                Log.w("FirestoreChat", "FirebaseApp not initialized yet. Chat listener skipped.")
                return
            }
            val db = FirebaseFirestore.getInstance()
            messagesListenerRegistration = db.collection("messages")
                .addSnapshotListener { snapshots, e ->
                    if (e != null) {
                        Log.w("FirestoreChat", "Listen failed.", e)
                        return@addSnapshotListener
                    }
                    if (snapshots != null) {
                        viewModelScope.launch {
                            for (docChange in snapshots.documentChanges) {
                                if (docChange.type == com.google.firebase.firestore.DocumentChange.Type.ADDED) {
                                    val doc = docChange.document
                                    val chatPartnerName = doc.getString("chatPartnerName") ?: ""
                                    val senderRole = doc.getString("senderRole") ?: ""
                                    val senderName = doc.getString("senderName") ?: ""
                                    val messageText = doc.getString("messageText") ?: ""
                                    val timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()
                                    
                                    val exists = allMessages.value.any { 
                                        it.senderName == senderName && 
                                        it.messageText == messageText && 
                                        kotlin.math.abs(it.timestamp - timestamp) < 2000 
                                    }
                                    if (!exists) {
                                        val localPartner = if (senderName == profile.name) chatPartnerName else senderName
                                        if (localPartner.isNotBlank()) {
                                            repository.insertMessage(
                                                Message(
                                                    chatPartnerName = localPartner,
                                                    senderRole = senderRole,
                                                    senderName = senderName,
                                                    messageText = messageText,
                                                    timestamp = timestamp
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
        } catch (e: Exception) {
            Log.e("FirestoreChat", "Error starting realtime listener: ${e.message}")
        }
    }

    var firestoreTransactions by mutableStateOf<List<com.example.data.entity.PaymentTransaction>>(emptyList())
        private set

    fun startRealtimeTransactionsListener() {
        if (transactionsListenerRegistration != null) return
        val context = appContext ?: return
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                Log.w("FirestorePayment", "FirebaseApp not initialized yet. Transactions listener skipped.")
                return
            }
            val db = FirebaseFirestore.getInstance()
            transactionsListenerRegistration = db.collection("transactions")
                .addSnapshotListener { snapshots, e ->
                    if (e != null) {
                        Log.w("FirestorePayment", "Transactions listen failed.", e)
                        return@addSnapshotListener
                    }
                    if (snapshots != null) {
                        val list = snapshots.documents.mapNotNull { doc ->
                            try {
                                com.example.data.entity.PaymentTransaction(
                                    id = doc.getString("id") ?: "",
                                    bookingId = doc.getLong("bookingId")?.toInt() ?: 0,
                                    customerName = doc.getString("customerName") ?: "",
                                    partnerName = doc.getString("partnerName") ?: "",
                                    serviceTitle = doc.getString("serviceTitle") ?: "",
                                    amount = doc.getDouble("amount") ?: 0.0,
                                    status = doc.getString("status") ?: "",
                                    timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis(),
                                    description = doc.getString("description") ?: ""
                                )
                            } catch (e: Exception) {
                                null
                            }
                        }.sortedByDescending { it.timestamp }
                        firestoreTransactions = list
                        Log.d("FirestorePayment", "Realtime update: ${list.size} transactions.")
                    }
                }
        } catch (e: Exception) {
            Log.e("FirestorePayment", "Exception starting transactions listener: ${e.message}")
        }
    }

    fun syncPaymentTransactionWithFirestore(
        bookingId: Int,
        customerName: String,
        partnerName: String,
        serviceTitle: String,
        amount: Double,
        status: String,
        description: String
    ) {
        try {
            val db = FirebaseFirestore.getInstance()
            val txId = "TX-${bookingId}-${System.currentTimeMillis() % 100000}"
            val txMap = hashMapOf(
                "id" to txId,
                "bookingId" to bookingId,
                "customerName" to customerName,
                "partnerName" to partnerName,
                "serviceTitle" to serviceTitle,
                "amount" to amount,
                "status" to status,
                "timestamp" to System.currentTimeMillis(),
                "description" to description
            )
            db.collection("transactions").document(bookingId.toString()).set(txMap)
                .addOnSuccessListener {
                    Log.d("FirestorePayment", "Payment transaction synced successfully: $txId")
                }
                .addOnFailureListener { e ->
                    Log.e("FirestorePayment", "Failed to sync payment transaction: ${e.message}")
                }
        } catch (e: Exception) {
            Log.e("FirestorePayment", "Exception syncing payment transaction: ${e.message}")
        }
    }


    fun insertSystemMessage(partnerName: String, text: String, senderRole: String = "MITRA") {
        viewModelScope.launch {
            val systemMsg = Message(
                chatPartnerName = partnerName,
                senderRole = senderRole,
                senderName = partnerName,
                messageText = text
            )
            repository.insertMessage(systemMsg)
        }
    }

    val arCameraLogs = mutableStateListOf<String>()

    fun addArCameraLog(message: String, isError: Boolean = false) {
        val timestamp = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date())
        val prefix = if (isError) "🔴 [ERROR]" else "🟢 [INFO]"
        val logLine = "$timestamp $prefix $message"
        arCameraLogs.add(logLine)
        if (isError) {
            android.util.Log.e("JasaInARCamera", logLine)
        } else {
            android.util.Log.d("JasaInARCamera", logLine)
        }
    }

    private fun generateLocalArAnalysis(presetIndex: Int?, query: String): VisionAnalysisResult {
        val queryLower = query.lowercase()
        var detectedObject = "Instalasi / Perangkat Rumah Tangga"
        var issueCategory = "Layanan Umum JASAin"
        var severityLevel = "Medium"
        var recommendedService = "Pertukangan & Renovasi"
        var safetyInstruction = "Gunakan peralatan pelindung diri dan hindari menyentuh area basah/kabel telanjang."
        var estimatedScale = "Pengecekan fisik di tempat direkomendasikan."
        var rawText = ""

        if (presetIndex == 0 || queryLower.contains("pipa") || queryLower.contains("bocor") || queryLower.contains("air") || queryLower.contains("wastafel")) {
            detectedObject = "Pipa Wastafel PVC (Kebocoran Air)"
            issueCategory = "Pertukangan"
            severityLevel = "Medium"
            recommendedService = "Pertukangan"
            safetyInstruction = "Tutup katup aliran air utama segera untuk mencegah genangan lebih lanjut di lantai kayu/ubin."
            estimatedScale = "Diameter pipa 1.5 inci, panjang area rembesan sekitar 15-20 cm."
            rawText = "### ANALISIS JASAin-AR VISION EXPERT (FALLBACK OFFLINE)\n\n" +
                    "**Objek Terdeteksi:** Pipa Wastafel PVC dengan sambungan fitting rembes.\n" +
                    "**Kategori Kerusakan:** Kebocoran Saluran Pembuangan Air (Pertukangan & Renovasi).\n" +
                    "**Tingkat Keparahan:** Medium (Tetesan berkelanjutan, berpotensi merusak kabinet bawah).\n" +
                    "**Rekomendasi Jasa:** Jasa Pertukangan Air & Sanitasi JASAin.\n" +
                    "**Estimasi Dimensi:** Kebocoran di fitting slip-joint diameter 1.5 inci.\n\n" +
                    "**Saran Penanganan Awal:**\n" +
                    "1. Tempatkan wadah di bawah wastafel untuk menampung tetesan.\n" +
                    "2. Keringkan kabinet sekitarnya untuk mencegah pelapukan kayu.\n" +
                    "3. Jangan gunakan wastafel tersebut sebelum teknisi datang.\n\n" +
                    "*Ini adalah estimasi berbasis analisis visual lokal JASAin, mohon tunggu teknisi profesional kami untuk pengecekan fisik.*"
        } else if (presetIndex == 1 || queryLower.contains("kulkas") || queryLower.contains("ac") || queryLower.contains("mati") || queryLower.contains("dingin")) {
            detectedObject = "Unit Evaporator Pendingin AC (Debu Tebal)"
            issueCategory = "Servis AC & Elektronik"
            severityLevel = "High"
            recommendedService = "Servis AC & Elektronik"
            safetyInstruction = "Matikan sekring AC/Kulkas utama untuk menghindari korsleting listrik."
            estimatedScale = "Ketebalan debu sirip filter > 2mm, memerlukan pembersihan uap tekanan tinggi."
            rawText = "### ANALISIS JASAin-AR VISION EXPERT (FALLBACK OFFLINE)\n\n" +
                    "**Objek Terdeteksi:** Sirip Evaporator AC tersumbat debu padat.\n" +
                    "**Kategori Kerusakan:** Overheating Kompresor / Sirkulasi Udara Terhambat.\n" +
                    "**Tingkat Keparahan:** High (AC tidak mendinginkan ruangan dan menarik daya listrik berlebih).\n" +
                    "**Rekomendasi Jasa:** Jasa Servis AC & Elektronik Cuci Steam JASAin.\n" +
                    "**Estimasi Dimensi:** Unit AC Split Wall 1 PK standar.\n\n" +
                    "**Saran Penanganan Awal:**\n" +
                    "1. Matikan unit AC segera untuk mencegah kompresor jebol akibat panas berlebih.\n" +
                    "2. Cabut stop kontak listrik AC jika memungkinkan.\n" +
                    "3. Bersihkan filter jaring luar secara mandiri selagi menunggu pencucian evaporator.\n\n" +
                    "*Ini adalah estimasi berbasis analisis visual lokal JASAin, mohon tunggu teknisi profesional kami untuk pengecekan fisik.*"
        } else if (presetIndex == 2 || queryLower.contains("plafon") || queryLower.contains("atap") || queryLower.contains("rembes") || queryLower.contains("gypsum")) {
            detectedObject = "Plafon Gypsum Ruang Tamu (Flek Air)"
            issueCategory = "Pertukangan"
            severityLevel = "High"
            recommendedService = "Pertukangan"
            safetyInstruction = "Waspadai plafon gypsum melorot atau roboh tiba-tiba jika tergenang air berat."
            estimatedScale = "Area rembesan kecokelatan melingkar diameter sekitar 45-50 cm."
            rawText = "### ANALISIS JASAin-AR VISION EXPERT (FALLBACK OFFLINE)\n\n" +
                    "**Objek Terdeteksi:** Plafon Gypsum dengan rembesan air kecokelatan.\n" +
                    "**Kategori Kerusakan:** Kebocoran Atap / Dak Beton Atas.\n" +
                    "**Tingkat Keparahan:** High (Struktur gypsum melemah akibat saturasi air, rawan ambruk).\n" +
                    "**Rekomendasi Jasa:** Jasa Pertukangan Sipil / Renovasi Plafon JASAin.\n" +
                    "**Estimasi Dimensi:** Flek melingkar seluas 50cm x 50cm.\n\n" +
                    "**Saran Penanganan Awal:**\n" +
                    "1. Pindahkan barang elektronik dan furnitur berharga dari bawah area rembesan.\n" +
                    "2. Berikan lubang kecil dengan obeng di pusat flek jika air tergenang di atasnya agar air mengalir ke wadah penampung.\n" +
                    "3. Jangan berdiri tepat di bawah area flek basah.\n\n" +
                    "*Ini adalah estimasi berbasis analisis visual lokal JASAin, mohon tunggu teknisi profesional kami untuk pengecekan fisik.*"
        } else {
            rawText = "### ANALISIS JASAin-AR VISION EXPERT (FALLBACK OFFLINE)\n\n" +
                    "**Objek Terdeteksi:** Komponen Properti / Kerusakan Visual.\n" +
                    "**Kategori Kerusakan:** Kebutuhan Layanan Umum JASAin.\n" +
                    "**Tingkat Keparahan:** Medium (Perlu pemeriksaan langsung).\n" +
                    "**Rekomendasi Jasa:** Jasa Pertukangan & Pemeliharaan JASAin.\n" +
                    "**Estimasi Dimensi:** Area terdampak memerlukan inspeksi fisik.\n\n" +
                    "**Saran Penanganan Awal:**\n" +
                    "1. Amankan area sekitar dari jangkauan anak-anak.\n" +
                    "2. Dokumentasikan foto/video tambahan dari berbagai sudut pencahayaan yang baik.\n" +
                    "3. Konsultasikan dengan mitra JASAin terdekat via fitur Chat.\n\n" +
                    "*Ini adalah estimasi berbasis analisis visual lokal JASAin, mohon tunggu teknisi profesional kami untuk pengecekan fisik.*"
        }

        return VisionAnalysisResult(
            detectedObject = detectedObject,
            issueCategory = issueCategory,
            severityLevel = severityLevel,
            recommendedService = recommendedService,
            safetyInstruction = safetyInstruction,
            estimatedScale = estimatedScale,
            rawText = rawText
        )
    }

    var arVisionResult by mutableStateOf<VisionAnalysisResult?>(null)
        private set
    var isArAnalyzing by mutableStateOf(false)
        private set

    fun runArVisionAnalysis(
        context: android.content.Context,
        imageUrl: String?,
        localDrawableResId: Int?,
        userQuery: String,
        customBase64: String? = null
    ) {
        viewModelScope.launch {
            isArAnalyzing = true
            arVisionResult = null
            addArCameraLog("Memulai analisis visual JASAin-AR Vision...")
            addArCameraLog("Pertanyaan pengguna: \"$userQuery\"")

            // Determine preset index if localDrawableResId is passed
            var presetIndex: Int? = null
            if (localDrawableResId != null) {
                if (localDrawableResId == com.example.R.drawable.cat_rumah_tangga_1782034913734) {
                    presetIndex = if (userQuery.contains("Pipa", ignoreCase = true) || userQuery.contains("pipa", ignoreCase = true)) 0 else 2
                } else if (localDrawableResId == com.example.R.drawable.cat_elektronik_1782034929844) {
                    presetIndex = 1
                }
            }

            if (!customBase64.isNullOrBlank()) {
                addArCameraLog("Mendeteksi visual: Foto kamera langsung / galeri pengguna (Panjang string: ${customBase64.length} karakter).")
            } else if (localDrawableResId != null) {
                addArCameraLog("Mendeteksi visual: Gambar preset (Index: $presetIndex, ResId: $localDrawableResId).")
            } else if (!imageUrl.isNullOrBlank()) {
                addArCameraLog("Mendeteksi visual: URL eksternal ($imageUrl).")
            } else {
                addArCameraLog("Mendeteksi visual: Tidak ada gambar terpilih. Berjalan dalam mode kueri murni.", isError = true)
            }

            try {
                val apiKey = com.example.BuildConfig.GEMINI_API_KEY
                val isApiKeyValid = !apiKey.isNullOrBlank() && 
                                    !apiKey.contains("PLACEHOLDER") && 
                                    !apiKey.contains("TODO") && 
                                    !apiKey.contains("YOUR_API")

                if (!isApiKeyValid) {
                    addArCameraLog("Kredensial Gemini API Key kosong atau masih berupa placeholder.", isError = true)
                    addArCameraLog("Beralih ke Mesin Klasifikasi JASAin-AR Lokal untuk identifikasi instan...")
                    kotlinx.coroutines.delay(1500) // Delay to ensure visible animation overlay
                    
                    val fallbackResult = generateLocalArAnalysis(presetIndex, userQuery)
                    arVisionResult = fallbackResult
                    addArCameraLog("Mesin JASAin-AR Lokal sukses mengidentifikasi objek: \"${fallbackResult.detectedObject}\" (Layanan: \"${fallbackResult.recommendedService}\").")
                    return@launch
                }

                addArCameraLog("Kredensial Gemini API Key valid. Menghubungkan ke endpoint Google Gemini API...")
                
                val systemPrompt = """
# ROLE & IDENTITY
Anda adalah "JASAin-AR Vision Expert", sistem kecerdasan buatan multimodal yang bertugas menganalisis input visual (foto/video) dari kamera pengguna aplikasi JASAin. Anda adalah asisten ahli yang mampu mendeteksi kerusakan, mengukur dimensi objek, dan merekomendasikan jasa profesional yang tepat.

# CORE RESPONSIBILITIES
1. **Damage Analysis:** Mengidentifikasi jenis kerusakan atau kondisi properti (misal: pipa bocor, dinding retak, plafon rusak) dari gambar yang dikirim pengguna. Isu harus didasarkan pada realitas visual.
2. **Dimension Estimation:** Memperkirakan dimensi objek (panjang/lebar/tinggi) untuk kebutuhan estimasi material atau jasa (misal: luas dinding untuk pengecatan).
3. **Recommendation Engine:** Berdasarkan analisis visual, rekomendasikan kategori/nama jasa di JASAin yang paling relevan.
4. **Actionable Advice:** Memberikan langkah penanganan awal yang aman (misal: "Matikan keran utama jika bocor parah") sebelum teknisi tiba.

# OPERATIONAL RULES & CONSTRAINTS
- **Disclaimer Wajib:** Anda wajib menyertakan kalimat "Ini adalah estimasi berbasis analisis visual, mohon tunggu teknisi profesional kami untuk pengecekan fisik."
- **Safety First:** Jika AI mendeteksi bahaya serius (misal: kabel terbakar, kebocoran gas, struktur roboh), wajib memberikan instruksi keselamatan darurat dan menyarankan pengguna untuk menjauh dari lokasi tersebut.
- **Accuracy:** Jika visual tidak jelas atau blur, jangan memaksakan diagnosa. Mintalah pengguna untuk: "Mohon ambil foto dari sudut yang lebih terang/jelas."
- **Contextual Formatting:** Kembalikan respons dalam format terstruktur yang jelas. Berikan analisis naratif yang ramah dalam bahasa Indonesia, diikuti oleh block JSON murni di bagian paling bawah dengan label [JSON_OUTPUT] di atasnya sehingga aplikasi ini dapat mem-parsing data secara tepat. Format JSON tersebut haruslah:
{
  "detected_object": "...",
  "issue_category": "...",
  "severity_level": "Low/Medium/High",
  "recommended_service": "...",
  "safety_instruction": "...",
  "estimated_scale": "..."
}
                """.trimIndent()

                val queryText = "Pertanyaan pengguna: $userQuery\n\nLakukan analisis kecerdasan buatan JASAin-AR Vision Expert terhadap gambar ini."
                
                val parts = mutableListOf<com.example.data.api.Part>()
                parts.add(com.example.data.api.Part(text = queryText))

                if (!customBase64.isNullOrBlank()) {
                    parts.add(
                        com.example.data.api.Part(
                            inlineData = com.example.data.api.InlineData(
                                mimeType = "image/jpeg",
                                data = customBase64.trim().replace("\n", "").replace("\r", "")
                            )
                        )
                    )
                } else if (localDrawableResId != null) {
                    val base64 = drawableToBase64(context, localDrawableResId)
                    if (base64 != null) {
                        parts.add(
                            com.example.data.api.Part(
                                inlineData = com.example.data.api.InlineData(
                                    mimeType = "image/jpeg",
                                    data = base64.trim().replace("\n", "").replace("\r", "")
                                )
                            )
                        )
                    }
                } else if (!imageUrl.isNullOrBlank()) {
                    parts.add(com.example.data.api.Part(text = "[Menganalisis Gambar online: $imageUrl]"))
                }

                val systemInstruction = com.example.data.api.Content(
                    parts = listOf(com.example.data.api.Part(text = systemPrompt))
                )

                val request = com.example.data.api.GenerateContentRequest(
                    contents = listOf(com.example.data.api.Content(parts = parts)),
                    systemInstruction = systemInstruction
                )

                addArCameraLog("Mengirim payload visual ke Gemini API...")
                val response = com.example.data.api.GeminiClient.apiService.generateContent(apiKey, request)
                val fullResultText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                    ?: "Gagal memproses gambar."

                addArCameraLog("Menerima respons dari Gemini API. Memulai penguraian metadata...")

                var detectedObject = "Tidak terdeteksi"
                var issueCategory = "Lainnya"
                var severityLevel = "Low"
                var recommendedService = "Cek Katalog"
                var safetyInstruction = "Gunakan masker dan hati-hati."
                var estimatedScale = "Pengecekan fisik diperlukan."

                try {
                    val jsonStartIndex = fullResultText.indexOf("{")
                    val jsonEndIndex = fullResultText.lastIndexOf("}")
                    if (jsonStartIndex != -1 && jsonEndIndex != -1 && jsonEndIndex > jsonStartIndex) {
                        val jsonString = fullResultText.substring(jsonStartIndex, jsonEndIndex + 1)
                        val moshi = com.squareup.moshi.Moshi.Builder().build()
                        val adapter = moshi.adapter(Map::class.java)
                        val parsed = adapter.fromJson(jsonString) as? Map<*, *>
                        if (parsed != null) {
                            detectedObject = parsed["detected_object"]?.toString() ?: detectedObject
                            issueCategory = parsed["issue_category"]?.toString() ?: issueCategory
                            severityLevel = parsed["severity_level"]?.toString() ?: severityLevel
                            recommendedService = parsed["recommended_service"]?.toString() ?: recommendedService
                            safetyInstruction = parsed["safety_instruction"]?.toString() ?: safetyInstruction
                            estimatedScale = parsed["estimated_scale"]?.toString() ?: estimatedScale
                            addArCameraLog("Berhasil mem-parsing JSON terstruktur. Objek terdeteksi: '$detectedObject'")
                        }
                    } else {
                        addArCameraLog("Peringatan: Tidak ditemukan blok JSON terstruktur dalam respons. Beralih ke pencocokan kata kunci.", isError = true)
                        if (fullResultText.contains("bocor", ignoreCase = true)) {
                            detectedObject = "Pipa / Air"
                            issueCategory = "Kebocoran Rumah Tangga"
                            severityLevel = "Medium"
                            recommendedService = "Reparasi Plafon & Pipa Bocor"
                            safetyInstruction = "Matikan katup air utama segera!"
                        }
                    }
                } catch (pe: Exception) {
                    addArCameraLog("Gagal mem-parsing format respons: ${pe.message}. Menggunakan teks mentah.", isError = true)
                }

                arVisionResult = VisionAnalysisResult(
                    detectedObject = detectedObject,
                    issueCategory = issueCategory,
                    severityLevel = severityLevel,
                    recommendedService = recommendedService,
                    safetyInstruction = safetyInstruction,
                    estimatedScale = estimatedScale,
                    rawText = fullResultText
                )
                addArCameraLog("Analisis JASAin-AR Vision sukses diselesaikan.")

            } catch (e: Exception) {
                addArCameraLog("Koneksi API gagal atau terjadi kesalahan: ${e.localizedMessage ?: "Kesalahan koneksi jaringan API."}", isError = true)
                addArCameraLog("Memulihkan sistem secara cerdas dengan Mesin JASAin-AR Lokal...")
                kotlinx.coroutines.delay(1000)

                val fallbackResult = generateLocalArAnalysis(presetIndex, userQuery)
                arVisionResult = fallbackResult
                addArCameraLog("Sistem pulih. Objek berhasil diidentifikasi secara lokal: \"${fallbackResult.detectedObject}\"")
            } finally {
                isArAnalyzing = false
            }
        }
    }

    private fun drawableToBase64(context: android.content.Context, resId: Int): String? {
        try {
            val drawable = androidx.core.content.ContextCompat.getDrawable(context, resId) ?: return null
            val bitmap = when (drawable) {
                is android.graphics.drawable.BitmapDrawable -> drawable.bitmap
                else -> {
                    val width = drawable.intrinsicWidth.coerceAtLeast(1)
                    val height = drawable.intrinsicHeight.coerceAtLeast(1)
                    val bmp = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
                    val canvas = android.graphics.Canvas(bmp)
                    drawable.setBounds(0, 0, canvas.width, canvas.height)
                    drawable.draw(canvas)
                    bmp
                }
            }
            val outputStream = java.io.ByteArrayOutputStream()
            bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 70, outputStream)
            return android.util.Base64.encodeToString(outputStream.toByteArray(), android.util.Base64.DEFAULT)
        } catch (e: Exception) {
            return null
        }
    }

    fun triggerNotification(title: String, message: String, recipientName: String, type: String, bookingId: Int? = null) {
        viewModelScope.launch {
            val notif = JasaInNotification(
                title = title,
                message = message,
                timestamp = System.currentTimeMillis(),
                isRead = false,
                type = type,
                recipientName = recipientName,
                bookingId = bookingId
            )
            repository.insertNotification(notif)
            
            // Also trigger local push notification if matching current context
            val context = try { com.google.firebase.FirebaseApp.getInstance().applicationContext } catch (e: Exception) { null }
            if (context != null) {
                com.example.service.JasaInFcmService.sendNotification(context, title, message)
            }
        }
    }

    fun markNotificationAsRead(id: Int) {
        viewModelScope.launch {
            repository.markAsRead(id)
        }
    }

    fun markAllNotificationsAsRead() {
        viewModelScope.launch {
            val profile = userProfile.value ?: return@launch
            repository.markAllAsRead(profile.name)
        }
    }

    fun deleteNotification(id: Int) {
        viewModelScope.launch {
            repository.deleteNotification(id)
        }
    }
}

data class VisionAnalysisResult(
    val detectedObject: String = "",
    val issueCategory: String = "",
    val severityLevel: String = "",
    val recommendedService: String = "",
    val safetyInstruction: String = "",
    val estimatedScale: String = "",
    val rawText: String = ""
)

data class ChatSummary(
    val partnerName: String,
    val lastMessage: String,
    val timestamp: Long,
    val senderRole: String
)

class JasaInViewModelFactory(private val repository: AppRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(JasaInViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return JasaInViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
