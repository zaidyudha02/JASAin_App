package com.example.ui.screen

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import coil.compose.AsyncImage
import androidx.compose.animation.*
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.Booking
import com.example.data.entity.Message
import com.example.data.entity.ServiceListing
import com.example.ui.components.*
import com.example.ui.viewmodel.JasaInViewModel
import com.example.ui.theme.JasaInAccent
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.animation.core.*
import kotlinx.coroutines.launch

// Expanded categories for all Indonesian services
val ExpandedCategories = listOf(
    "Semua",
    "Rumah Tangga",
    "Elektronik",
    "Edukasi",
    "Kecantikan & Kesehatan"
)

val ExpandedLocations = listOf(
    "Semua",
    "Banjarmasin",
    "Banjarbaru",
    "Martapura",
    "Pelaihari",
    "Kandangan",
    "Barabai",
    "Amuntai",
    "Tanjung",
    "Batulicin",
    "Kotabaru",
    "Marabahan",
    "Paringin",
    "Rantau",
    "Luar Kalsel (Masa Tunggu)"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PelangganHomeScreen(viewModel: JasaInViewModel) {
    val listings by viewModel.filteredListings.collectAsState()
    val favoriteServiceIds by viewModel.favoriteServiceIds.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val activeCategory by viewModel.selectedCategory.collectAsState()
    val activeLocation by viewModel.selectedLocation.collectAsState()
    val sortByOption by viewModel.sortBy.collectAsState()
    val profile by viewModel.userProfile.collectAsState()
    val isOnline by viewModel.isOnline.collectAsState()
    val isEnglish = LocalIsEnglishState.current

    var showLocationSheet by remember { mutableStateOf(false) }
    var showSortSheet by remember { mutableStateOf(false) }
    var showFilterDialog by remember { mutableStateOf(false) }
    val advancedFilters by viewModel.advancedFilters.collectAsState()

    var draftMinPriceText by remember(advancedFilters) {
        mutableStateOf(advancedFilters.minPrice?.toInt()?.toString() ?: "")
    }
    var draftMaxPriceText by remember(advancedFilters) {
        mutableStateOf(advancedFilters.maxPrice?.toInt()?.toString() ?: "")
    }
    var draftAvailability by remember(advancedFilters) {
        mutableStateOf(advancedFilters.availability)
    }
    var draftMinRating by remember(advancedFilters) {
        mutableStateOf(advancedFilters.minRating)
    }
    var draftLocation by remember(activeLocation) {
        mutableStateOf(activeLocation)
    }

    var activeListingForModal by remember { mutableStateOf<ServiceListing?>(null) }
    val bookings by viewModel.customerBookings.collectAsState()
    val allBookings by viewModel.allBookings.collectAsState()
    var showTopUpDialog by remember { mutableStateOf(false) }
    var showWithdrawDialog by remember { mutableStateOf(false) }
    var showMitraMapExplorer by remember { mutableStateOf(false) }

    if (showMitraMapExplorer) {
        MitraMapExplorerDialog(
            listings = listings,
            initialLocation = activeLocation,
            onDismiss = { showMitraMapExplorer = false },
            onBookNow = { listing ->
                showMitraMapExplorer = false
                viewModel.bookingModalListing = listing
            },
            onViewDetail = { listing ->
                showMitraMapExplorer = false
                activeListingForModal = listing
            }
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
        // App Header & Wallet Balance Card
        Surface(
            color = MaterialTheme.colorScheme.primary,
            shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.2f))
                                .clickable { viewModel.navigateTo("PELANGGAN_PROFILE") }
                                .testTag("home_profile_avatar_box"),
                            contentAlignment = Alignment.Center
                        ) {
                            val photoUri = profile?.profilePictureUri
                            if (!photoUri.isNullOrEmpty()) {
                                AsyncImage(
                                    model = photoUri,
                                    contentDescription = "Foto Profil",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Icon(
                                    Icons.Default.Person,
                                    contentDescription = "Profil",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Column {
                            Text(
                                text = if (isEnglish) "Welcome," else "Selamat Datang,",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.7f)
                            )
                            Text(
                                text = profile?.name ?: (if (isEnglish) "JASAin Customer" else "Pelanggan JASAin"),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                    }

                    // Tanya JASAin-AI Asisten Virtual as dynamic circular button
                    val assistantTransition = rememberInfiniteTransition(label = "ai_pulse")
                    val pulseScale by assistantTransition.animateFloat(
                        initialValue = 1.0f,
                        targetValue = 1.12f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1400, easing = FastOutSlowInEasing),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "scale"
                    )
                    val pulseAlpha by assistantTransition.animateFloat(
                        initialValue = 0.25f,
                        targetValue = 0.65f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1400, easing = FastOutSlowInEasing),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "alpha"
                    )

                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clickable {
                                viewModel.openChatWith("JASAin-AI")
                            }
                            .testTag("home_jasain_ai_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        // Pulsing outer glowing ring
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .graphicsLayer {
                                    scaleX = pulseScale
                                    scaleY = pulseScale
                                    alpha = pulseAlpha
                                }
                                .background(Color.White.copy(alpha = 0.3f), CircleShape)
                        )
                        // Inner button
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .background(
                                    brush = Brush.linearGradient(
                                        colors = listOf(
                                            JasaInAccent,
                                            MaterialTheme.colorScheme.secondary
                                        )
                                    ),
                                    shape = CircleShape
                                )
                                .border(1.5.dp, Color.White, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SmartToy,
                                contentDescription = "Tanya JASAin-AI",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Modern Search Input & Sort Filter prominent below the greeting
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val searchHint = if (isEnglish) "Search services, partners, or categories..." else "Cari layanan, mitra, atau kategori..."
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.updateSearchQuery(it) },
                        placeholder = { Text(searchHint, fontSize = 13.sp, color = Color.White.copy(alpha = 0.7f)) },
                        leadingIcon = { Icon(Icons.Default.Search, if (isEnglish) "Search" else "Cari", tint = Color.White.copy(alpha = 0.9f)) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                    Icon(Icons.Default.Clear, if (isEnglish) "Clear" else "Hapus", tint = Color.White)
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color.White,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.4f),
                            focusedContainerColor = Color.White.copy(alpha = 0.15f),
                            unfocusedContainerColor = Color.White.copy(alpha = 0.1f),
                            cursorColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("home_search_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    // Sort Filter Button matching the design (now opens comprehensive advanced filter)
                    IconButton(
                        onClick = { showFilterDialog = true },
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color.White.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                            .testTag("home_sort_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Pencarian Lanjutan & Urutan",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Wallet Balance Info
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White.copy(alpha = 0.12f))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = "Saldo",
                            tint = JasaInAccent,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            val isEnglish = LocalIsEnglishState.current
                            Text(
                                text = if (isEnglish) "JASApay Balance" else "Saldo JASApay",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.75f)
                            )
                            Text(
                                text = formatRupiah(profile?.balance ?: 500000.0),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { showTopUpDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = JasaInAccent),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("home_topup_button")
                        ) {
                            Text("Top up", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                        }

                        Button(
                            onClick = { showWithdrawDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f)),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("home_withdraw_button")
                        ) {
                            val isEnglish = LocalIsEnglishState.current
                            Text(if (isEnglish) "Withdraw" else "Tarik Saldo", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }

        // Caching awareness notice
        if (!isOnline) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.9f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudOff,
                        contentDescription = "Offline Mode",
                        tint = MaterialTheme.colorScheme.onErrorContainer
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Koneksi terputus. Menampilkan data cache lokal (Sistem Caching Aktif).",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }
        }





        // Quick location filter view
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showLocationSheet = true }
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = "Kota Lokasi",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "Lokasi: $activeLocation",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Default.ArrowDropDown,
                contentDescription = "Pilih Lokasi",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "Urutan: $sortByOption",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Comfortable horizontal scrollable category chips for extremely simple exploration
        val categoriesList = listOf("Semua", "Favorit", "Rumah Tangga", "Elektronik", "Edukasi", "Kecantikan & Kesehatan")
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .testTag("horizontal_category_chips_row"),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(end = 16.dp)
        ) {
            items(categoriesList) { categoryName ->
                val isSelected = activeCategory == categoryName
                val categoryColor = getCategoryColor(categoryName)
                
                val chipBg = if (isSelected) categoryColor.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                val chipBorderColor = if (isSelected) categoryColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.12f)
                val chipTextColor = if (isSelected) categoryColor else MaterialTheme.colorScheme.onSurface
                
                val displayName = when (categoryName) {
                    "Semua" -> if (isEnglish) "All Services" else "Semua Jasa"
                    "Favorit" -> if (isEnglish) "Favorites" else "Favorit"
                    "Rumah Tangga" -> if (isEnglish) "Home Care" else "Rumah Tangga"
                    "Elektronik" -> if (isEnglish) "Electronics" else "Elektronik"
                    "Edukasi" -> if (isEnglish) "Education" else "Edukasi"
                    "Kecantikan & Kesehatan" -> if (isEnglish) "Beauty & Wellness" else "Spa & Kesehatan"
                    else -> categoryName
                }
                
                Surface(
                    onClick = {
                        viewModel.updateSelectedCategory(categoryName)
                    },
                    modifier = Modifier.testTag("quick_category_chip_$categoryName"),
                    shape = RoundedCornerShape(20.dp),
                    color = chipBg,
                    border = BorderStroke(1.2.dp, chipBorderColor),
                    shadowElevation = if (isSelected) 2.dp else 0.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CategoryIconMapper(
                            category = categoryName,
                            tint = if (isSelected) categoryColor else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = displayName,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Bold,
                            color = chipTextColor
                        )
                    }
                }
            }
        }

        // Service listings
        val isListingsLoading = viewModel.isListingsLoading
        if (isListingsLoading) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 165.dp),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp, start = 16.dp, end = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(6) {
                    ServiceListingSkeletonCard()
                }
            }
        } else if (listings.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.SearchOff,
                        contentDescription = "Habis",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Layanan jasa belum tersedia atau tidak cocok.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 165.dp),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp, start = 16.dp, end = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(listings) { listing ->
                    val listingReviews = allBookings.filter { it.partnerName == listing.partnerName && it.rating != null }
                    val isFavorite = favoriteServiceIds.contains(listing.id)
                    ServiceCard(
                        listing = listing,
                        onClick = { activeListingForModal = listing },
                        onBookNow = {
                            viewModel.bookingModalListing = listing
                        },
                        onRatingClick = {
                            viewModel.openReviewsFor(listing.partnerName)
                        },
                        reviews = listingReviews,
                        isFavorite = isFavorite,
                        onFavoriteToggle = {
                            viewModel.toggleFavorite(listing.id)
                        }
                    )
                }
            }
        }
    }

    // Beautiful Radar Mitra Map Floating Action Button
    ExtendedFloatingActionButton(
        onClick = { showMitraMapExplorer = true },
        icon = { Icon(Icons.Default.Map, contentDescription = "Peta Mitra", tint = Color.White) },
        text = { Text("Radar Mitra", fontWeight = FontWeight.Bold, color = Color.White) },
        containerColor = MaterialTheme.colorScheme.primary,
        modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(bottom = 80.dp, end = 16.dp)
            .testTag("home_map_radar_fab")
    )
}

    // Modal Location Sheet (Dialog style for multi-platform stability)
    if (showLocationSheet) {
        AlertDialog(
            onDismissRequest = { showLocationSheet = false },
            title = { Text("Pilih Wilayah Jasa", fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(modifier = Modifier.height(280.dp)) {
                    items(ExpandedLocations) { loc ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.updateSelectedLocation(loc)
                                    showLocationSheet = false
                                }
                                .padding(vertical = 12.dp, horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = activeLocation == loc,
                                onClick = {
                                    viewModel.updateSelectedLocation(loc)
                                    showLocationSheet = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(loc, fontSize = 14.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLocationSheet = false }) {
                    Text("Tutup")
                }
            }
        )
    }

    // Modal Sort Options
    if (showSortSheet) {
        val sortOptions = listOf("Default", "Harga Terendah", "Harga Tertinggi", "Rating Tertinggi", "Rating Terendah")
        AlertDialog(
            onDismissRequest = { showSortSheet = false },
            title = { Text("Urutkan Berdasarkan", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    sortOptions.forEach { opt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.updateSortBy(opt)
                                    showSortSheet = false
                                }
                                .padding(vertical = 12.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = sortByOption == opt,
                                onClick = {
                                    viewModel.updateSortBy(opt)
                                    showSortSheet = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(opt, fontSize = 14.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSortSheet = false }) {
                    Text("Batal")
                }
            }
        )
    }

    if (showFilterDialog) {
        val sortOptions = listOf("Default", "Harga Terendah", "Harga Tertinggi", "Rating Tertinggi", "Rating Terendah")
        val locations = listOf(
            "Semua", "Banjarmasin", "Banjarbaru", "Martapura", "Pelaihari", "Kandangan", "Amuntai", "Barabai", "Tanjung", "Kotabaru"
        )
        val availabilities = listOf("Semua", "Pagi", "Siang", "Sore", "Malam")
        val ratingThresholds = listOf(0.0f, 4.0f, 4.5f, 4.8f)

        var locationDropdownExpanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showFilterDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = "Filter",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Pencarian Lanjutan & Filter",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // 1. Urutkan Berdasarkan
                    Column {
                        Text(
                            text = "Urutkan Jasa",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            sortOptions.forEach { opt ->
                                CustomFilterChip(
                                    selected = sortByOption == opt,
                                    onClick = { viewModel.updateSortBy(opt) },
                                    label = opt,
                                    modifier = Modifier.testTag("filter_sort_$opt")
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                    // 2. Lokasi Mitra
                    Column {
                        Text(
                            text = "Lokasi / Wilayah",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedCard(
                                onClick = { locationDropdownExpanded = !locationDropdownExpanded },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("filter_location_selector")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = draftLocation,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = "Expand"
                                    )
                                }
                            }
                            DropdownMenu(
                                expanded = locationDropdownExpanded,
                                onDismissRequest = { locationDropdownExpanded = false },
                                modifier = Modifier.fillMaxWidth(0.9f)
                            ) {
                                locations.forEach { loc ->
                                    DropdownMenuItem(
                                        text = { Text(loc, fontSize = 13.sp) },
                                        onClick = {
                                            draftLocation = loc
                                            locationDropdownExpanded = false
                                        },
                                        modifier = Modifier.testTag("filter_location_item_$loc")
                                    )
                                }
                            }
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                    // 3. Rentang Harga
                    Column {
                        Text(
                            text = "Rentang Tarif Biaya (Rp)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = draftMinPriceText,
                                onValueChange = { draftMinPriceText = it },
                                label = { Text("Minimum", fontSize = 11.sp) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("filter_price_min"),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                textStyle = LocalTextStyle.current.copy(fontSize = 12.sp)
                            )
                            Text("s/d", fontSize = 12.sp, color = Color.Gray)
                            OutlinedTextField(
                                value = draftMaxPriceText,
                                onValueChange = { draftMaxPriceText = it },
                                label = { Text("Maksimum", fontSize = 11.sp) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("filter_price_max"),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                textStyle = LocalTextStyle.current.copy(fontSize = 12.sp)
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                    // 4. Ketersediaan Waktu
                    Column {
                        Text(
                            text = "Ketersediaan Waktu Mitra",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            availabilities.forEach { wave ->
                                CustomFilterChip(
                                    selected = draftAvailability == wave,
                                    onClick = { draftAvailability = wave },
                                    label = wave,
                                    modifier = Modifier.testTag("filter_avail_$wave")
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                    // 5. Rating Minimum
                    Column {
                        Text(
                            text = "Rating Minimum Mitra",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ratingThresholds.forEach { rating ->
                                val labelText = if (rating == 0.0f) "Semua" else "★ ${rating.toInt()}+"
                                CustomFilterChip(
                                    selected = draftMinRating == rating,
                                    onClick = { draftMinRating = rating },
                                    label = labelText,
                                    modifier = Modifier.testTag("filter_rating_${rating.toString().replace('.', '_')}")
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateSelectedLocation(draftLocation)
                        val minP = draftMinPriceText.toDoubleOrNull()
                        val maxP = draftMaxPriceText.toDoubleOrNull()
                        viewModel.updateAdvancedFilters(minP, maxP, draftAvailability, draftMinRating)
                        showFilterDialog = false
                    },
                    modifier = Modifier.testTag("filter_apply_button")
                ) {
                    Text("Terapkan")
                }
            },
            dismissButton = {
                Row {
                    TextButton(
                        onClick = {
                            draftMinPriceText = ""
                            draftMaxPriceText = ""
                            draftAvailability = "Semua"
                            draftMinRating = 0.0f
                            draftLocation = "Semua"
                            viewModel.updateSelectedLocation("Semua")
                            viewModel.resetAdvancedFilters()
                            viewModel.updateSortBy("Default")
                            showFilterDialog = false
                        },
                        modifier = Modifier.testTag("filter_reset_button")
                    ) {
                        Text("Reset", color = Color.Red)
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    TextButton(
                        onClick = { showFilterDialog = false }
                    ) {
                        Text("Batal")
                    }
                }
            }
        )
    }

    // Modal Service Provider Detail Dialog with test tags
    if (activeListingForModal != null) {
        ServiceProviderDetailDialog(
            listing = activeListingForModal!!,
            onDismiss = { activeListingForModal = null },
            onBookNow = {
                val listing = activeListingForModal!!
                activeListingForModal = null
                viewModel.bookingModalListing = listing
            },
            viewModel = viewModel
        )
    }

    if (showTopUpDialog) {
        IsiSaldoDialog(
            onDismiss = { showTopUpDialog = false },
            viewModel = viewModel
        )
    }

    if (showWithdrawDialog) {
        TarikSaldoDialog(
            onDismiss = { showWithdrawDialog = false },
            viewModel = viewModel
        )
    }
}

@Composable
fun ServiceListingCard(
    listing: ServiceListing,
    onClick: () -> Unit,
    onBookNow: () -> Unit,
    onRatingClick: (() -> Unit)? = null,
    reviews: List<Booking> = emptyList()
) {
    val categoryColor = getCategoryColor(listing.category)
    val imgRes = getCategoryDrawableId(listing.category)
    val isEnglish = LocalIsEnglishState.current

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("listing_card_${listing.id}")
    ) {
        Column {
            // Category Illustration Image top banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
            ) {
                Image(
                    painter = painterResource(id = imgRes),
                    contentDescription = listing.category,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                // Dark gradient overlay at the bottom for readability
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.4f)),
                                startY = 150f
                            )
                        )
                )

                // Category badge over image
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(categoryColor)
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    val catTitle = when (listing.category) {
                        "Rumah Tangga" -> if (isEnglish) "Home Services" else "Rumah Tangga"
                        "Elektronik" -> if (isEnglish) "Electronics" else "Elektronik"
                        "Edukasi" -> if (isEnglish) "Education" else "Edukasi"
                        "Kecantikan & Kesehatan" -> if (isEnglish) "Beauty & Wellness" else "Kecantikan/Kesehatan"
                        else -> listing.category
                    }
                    Text(
                        text = catTitle,
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Column(modifier = Modifier.padding(12.dp)) {
                // Partner Name & Rating Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = listing.partnerName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = if (onRatingClick != null) {
                            Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .clickable { onRatingClick() }
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        } else {
                            Modifier
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Rating",
                            tint = JasaInAccent,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = listing.partnerRating.toString(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Title
                Text(
                    text = listing.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(2.dp))

                // Location & Availability Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = if (isEnglish) "Location" else "Lokasi",
                            tint = Color.Gray,
                            modifier = Modifier.size(11.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = listing.location,
                            fontSize = 10.sp,
                            color = Color.Gray,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = if (isEnglish) "Availability" else "Ketersediaan",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(11.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = listing.availability,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Short Description of the Service
                Text(
                    text = listing.description,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 15.sp,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Pricing Info Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = if (isEnglish) "Starts from" else "Mulai dari",
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = formatRupiah(listing.price),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    val unitDisplay = when (listing.priceUnit) {
                        "jam" -> if (isEnglish) "hour" else "jam"
                        "pengerjaan" -> if (isEnglish) "job" else "pengerjaan"
                        "m2" -> "m²"
                        "hari" -> if (isEnglish) "day" else "hari"
                        "sesi" -> if (isEnglish) "session" else "sesi"
                        "kunjungan" -> if (isEnglish) "visit" else "kunjungan"
                        else -> listing.priceUnit
                    }
                    Text(
                        text = "/ $unitDisplay",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (reviews.isNotEmpty()) {
                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 8.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.15f)
                    )
                    Text(
                        text = if (isEnglish) "Reviews (${reviews.size})" else "Ulasan (${reviews.size})",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    val latestReview = reviews.last()
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .padding(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = latestReview.customerName,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                repeat(latestReview.rating ?: 5) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        tint = JasaInAccent,
                                        modifier = Modifier.size(10.dp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = latestReview.reviewText ?: "",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            lineHeight = 13.sp
                        )
                    }
                } else {
                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 8.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.15f)
                    )
                    Text(
                        text = if (isEnglish) "No reviews yet" else "Belum ada ulasan",
                        fontSize = 10.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
 
                // Book Now Button directly inside Card!
                Button(
                    onClick = onBookNow,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(34.dp)
                        .testTag("card_book_button_${listing.id}")
                ) {
                    Text(
                        text = if (isEnglish) "Book Now" else "Pesan Sekarang",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun ServiceListingSkeletonCard() {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val alpha by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shimmerAlpha"
    )

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer(alpha = alpha)
    ) {
        Column {
            // Category Illustration Image placeholder (top banner)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .background(Color.LightGray.copy(alpha = 0.5f))
            )

            Column(modifier = Modifier.padding(12.dp)) {
                // Partner Name & Rating Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Partner Name placeholder
                    Box(
                        modifier = Modifier
                            .width(80.dp)
                            .height(12.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.LightGray.copy(alpha = 0.6f))
                    )
                    // Rating placeholder
                    Box(
                        modifier = Modifier
                            .width(40.dp)
                            .height(12.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.LightGray.copy(alpha = 0.6f))
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Title placeholder
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.8f)
                        .height(16.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.LightGray.copy(alpha = 0.6f))
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Location & Availability Row placeholder
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(60.dp)
                            .height(10.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.LightGray.copy(alpha = 0.5f))
                    )
                    Box(
                        modifier = Modifier
                            .width(50.dp)
                            .height(10.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.LightGray.copy(alpha = 0.5f))
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Short Description placeholder (line 1)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.LightGray.copy(alpha = 0.5f))
                )
                Spacer(modifier = Modifier.height(4.dp))
                // Short Description placeholder (line 2)
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.6f)
                        .height(10.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.LightGray.copy(alpha = 0.5f))
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Pricing Info Row placeholder
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .width(50.dp)
                                .height(8.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(Color.LightGray.copy(alpha = 0.5f))
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .width(70.dp)
                                .height(16.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.LightGray.copy(alpha = 0.6f))
                        )
                    }
                    Box(
                        modifier = Modifier
                            .width(30.dp)
                            .height(10.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.LightGray.copy(alpha = 0.5f))
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Book Now Button placeholder
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.LightGray.copy(alpha = 0.6f))
                )
            }
        }
    }
}

@Composable
fun BookingItemSkeletonCard() {
    val transition = rememberInfiniteTransition(label = "shimmer_booking")
    val alpha by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shimmerAlphaBooking"
    )

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer(alpha = alpha),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category placeholder
                Box(
                    modifier = Modifier
                        .width(70.dp)
                        .height(12.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.LightGray.copy(alpha = 0.6f))
                )
                // Status label placeholder
                Box(
                    modifier = Modifier
                        .width(60.dp)
                        .height(18.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.LightGray.copy(alpha = 0.5f))
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Service Title placeholder
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.7f)
                    .height(16.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.LightGray.copy(alpha = 0.6f))
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Partner name / detail placeholder
            Box(
                modifier = Modifier
                    .width(120.dp)
                    .height(12.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.LightGray.copy(alpha = 0.5f))
            )

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    // Date & Time label placeholder
                    Box(
                        modifier = Modifier
                            .width(100.dp)
                            .height(10.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color.LightGray.copy(alpha = 0.5f))
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    // Address placeholder
                    Box(
                        modifier = Modifier
                            .width(140.dp)
                            .height(10.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color.LightGray.copy(alpha = 0.5f))
                    )
                }

                // Price placeholder
                Box(
                    modifier = Modifier
                        .width(80.dp)
                        .height(16.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.LightGray.copy(alpha = 0.6f))
                )
            }
        }
    }
}

@Composable
fun PelangganDetailScreen(viewModel: JasaInViewModel) {
    val listing = viewModel.selectedListing ?: return
    val isOnline by viewModel.isOnline.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val allBookings by viewModel.allBookings.collectAsState()
    val partnerReviews = allBookings.filter { it.partnerName == listing.partnerName && it.rating != null }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        JasaInTopAppBar(
            title = "Rincian Layanan",
            onBackClick = { viewModel.navigateTo("PELANGGAN_HOME") },
            viewModel = viewModel
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Service Card Layout
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = listing.category,
                        color = getCategoryColor(listing.category),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = listing.title,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StarRatingBar(
                            rating = listing.partnerRating,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
                                .clickable {
                                    viewModel.openReviewsFor(listing.partnerName)
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("•", color = Color.Gray)
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(Icons.Default.LocationOn, "Lokasi", tint = Color.Gray, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(listing.location, fontSize = 13.sp, color = Color.Gray)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = formatRupiah(listing.price) + " / " + listing.priceUnit,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Service Description Section
            Text(
                text = "Tentang Layanan Jasa",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = listing.description,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(16.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Partner Profile Section
            Text(
                text = "Profil Penyedia Jasa (Mitra)",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(listing.partnerName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Hubungi: " + listing.partnerPhone, fontSize = 12.sp, color = Color.Gray)
                        }

                        // Verified KYC badge
                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Verified, "Terverifikasi", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("KYC Terverifikasi", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Jam Kerja & Kehadiran: Senin - Sabtu (Terjadwal)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Map Lokasi Jasa
            Text(
                text = "Lokasi Pelayanan Terdekat",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(8.dp))

            ServiceDetailMiniMap(
                locationName = listing.location,
                partnerName = listing.partnerName
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Reviews & Star Rating System Section
            Text(
                text = "Ulasan & Rating Pelanggan",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Sub-card to write a direct review
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("direct_review_input_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Berikan Ulasan Jasa Anda",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Berikan penilaian setelah mencoba layanan Mitra ini",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    var selectedStars by remember { mutableStateOf(5) }
                    var reviewComment by remember { mutableStateOf("") }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Rating: ", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.width(8.dp))
                        StarRatingInput(
                            rating = selectedStars,
                            onRatingSelected = { selectedStars = it },
                            starSize = 28.dp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = reviewComment,
                        onValueChange = { reviewComment = it },
                        placeholder = { Text("Tulis komentar Anda di sini...", fontSize = 13.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("direct_review_comment_input"),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (reviewComment.isNotBlank()) {
                                viewModel.submitDirectPartnerReview(
                                    partnerName = listing.partnerName,
                                    rating = selectedStars,
                                    comment = reviewComment
                                )
                                reviewComment = ""
                            } else {
                                viewModel.showToast("Komentar ulasan tidak boleh kosong!", "ERROR")
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("submit_direct_review_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Kirim Ulasan", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // List of other reviews for this partner
            if (partnerReviews.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Belum ada ulasan untuk Mitra ini.\nJadilah yang pertama memberikan ulasan!",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    partnerReviews.forEach { review ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("partner_review_card_${review.id}")
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        // Colorful avatar badge
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .background(
                                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                                    CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = (review.customerName.firstOrNull() ?: 'U').uppercase(),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = review.customerName,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                    
                                    // Row of stars
                                    Row {
                                        repeat(5) { starIndex ->
                                            Icon(
                                                imageVector = if (starIndex < (review.rating ?: 5)) Icons.Default.Star else Icons.Default.StarOutline,
                                                contentDescription = null,
                                                tint = JasaInAccent,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = review.reviewText ?: "-",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Action Toolbar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .padding(16.dp)
                    .navigationBarsPadding(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { viewModel.openChatWith(listing.partnerName) },
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("detail_chat_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Chat, "Chat")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Chat Mitra", fontWeight = FontWeight.SemiBold)
                }

                Button(
                    onClick = { viewModel.bookingModalListing = listing },
                    modifier = Modifier
                        .weight(1.5f)
                        .height(50.dp)
                        .testTag("detail_book_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Pesan Layanan", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun PelangganBookingFormScreen(viewModel: JasaInViewModel) {
    val listing = viewModel.selectedListing ?: return
    val userProfile by viewModel.userProfile.collectAsState()

    var date by remember { mutableStateOf("22-06-2026") }
    var time by remember { mutableStateOf("10:00") }
    var address by remember { mutableStateOf(userProfile?.address ?: "") }
    var note by remember { mutableStateOf("") }

    var showMapSelector by remember { mutableStateOf(false) }

    var errorMsg by remember { mutableStateOf<String?>(null) }
    val coroutineScope = rememberCoroutineScope()

    val balance = userProfile?.balance ?: 500000.0
    val hasEnoughFunds = balance >= listing.price

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        JasaInTopAppBar(
            title = "Formulir Pemesanan",
            onBackClick = { viewModel.navigateTo("PELANGGAN_DETAIL") }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Selected service recap Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(listing.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(listing.partnerName, fontSize = 12.sp, color = Color.Gray)
                    }
                    Text(
                        formatRupiah(listing.price),
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 15.sp
                    )
                }
            }

            // Input Fields
            Text("Lengkapi Data Kunjungan", fontWeight = FontWeight.Bold, fontSize = 14.sp)

            OutlinedTextField(
                value = date,
                onValueChange = { date = it },
                label = { Text("Tanggal Pelaksanaan (misal: 25-06-2026)") },
                leadingIcon = { Icon(Icons.Default.CalendarToday, "Tanggal") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("book_date_input")
            )

            OutlinedTextField(
                value = time,
                onValueChange = { time = it },
                label = { Text("Jam Kedatangan (misal: 14:00)") },
                leadingIcon = { Icon(Icons.Default.AccessTime, "Jam") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("book_time_input")
            )

            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Alamat Lengkap Lokasi Layanan") },
                leadingIcon = { Icon(Icons.Default.PinDrop, "Alamat") },
                trailingIcon = {
                    IconButton(onClick = { showMapSelector = true }) {
                        Icon(
                            imageVector = Icons.Default.Map,
                            contentDescription = "Pilih dari Peta",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("book_address_input")
            )

            // Button trigger for full map interactive locator
            TextButton(
                onClick = { showMapSelector = true },
                modifier = Modifier.align(Alignment.End),
                contentPadding = PaddingValues(0.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.LocationSearching,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Buka Peta Pintar JASAin (Pilih Lebih Presisi)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("Catatan Tambahan untuk Mitra") },
                leadingIcon = { Icon(Icons.Default.NoteAdd, "Catatan") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("book_note_input"),
                placeholder = { Text("misal: Rumah pagar cat hijau, AC bocor di bagian kipas outdoor.") }
            )

            // Wallet Check & Warning
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (hasEnoughFunds) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Saldo JASApay Anda:", fontSize = 12.sp)
                        Text(formatRupiah(balance), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Biaya Layanan Jasa:", fontSize = 12.sp)
                        Text(formatRupiah(listing.price), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = Color.LightGray.copy(alpha = 0.3f))
                    Spacer(modifier = Modifier.height(12.dp))

                    if (!hasEnoughFunds) {
                        Text(
                            text = "❌ Saldo kurang! Mohon top up saldo Anda terlebih dahulu.",
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    } else {
                        Text(
                            text = "✅ Saldo Anda mencukupi (Metode Pembayaran JASApay Otomatis).",
                            color = Color(0xFF006A60),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            if (errorMsg != null) {
                Text(
                    text = errorMsg!!,
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = {
                    if (address.isBlank() || date.isBlank() || time.isBlank()) {
                        errorMsg = "Semua kolom bertanda wajib diisi!"
                    } else if (balance < listing.price) {
                        errorMsg = "Gagal memesan: Saldo JASApay Anda tidak mencukupi!"
                    } else {
                        viewModel.createBooking(listing, date, time, address, note)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .height(50.dp)
                    .testTag("book_submit_button"),
                enabled = hasEnoughFunds,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Kirim Permintaan Booking", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }

    if (showMapSelector) {
        MapSelectionDialog(
            initialLocation = if (address.isNotBlank()) address else listing.location,
            onDismiss = { showMapSelector = false },
            onConfirm = { selectedAddress ->
                address = selectedAddress
            }
        )
    }
}

@Composable
fun PelangganTransaksiScreen(viewModel: JasaInViewModel) {
    val bookings by viewModel.customerBookings.collectAsState()
    var selectedTab by remember { mutableStateOf("SEMUA") }

    val filtered = bookings.filter {
        when (selectedTab) {
            "MENUNGGU" -> it.status == "Diajukan"
            "PROSES" -> it.status == "Diterima"
            "RIWAYAT" -> it.status == "Selesai" || it.status == "Dibatalkan"
            else -> true
        }
    }

    var selectedBookingForReview by remember { mutableStateOf<Booking?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        JasaInTopAppBar(
            title = "Pesanan Saya",
            showModeTabs = true,
            viewModel = viewModel
        )

        // Compact Horizontal Carousel Overview of Bookings (Moved from Dashboard)
        MyBookingsDashboardSection(
            bookings = bookings,
            onWriteReview = { selectedBookingForReview = it },
            viewModel = viewModel,
            showSeeAll = false
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Subtab tabs
        TabRow(
            selectedTabIndex = when (selectedTab) {
                "MENUNGGU" -> 1
                "PROSES" -> 2
                "RIWAYAT" -> 3
                "ESCROW" -> 4
                else -> 0
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Tab(selected = selectedTab == "SEMUA", onClick = { selectedTab = "SEMUA" }) {
                Text("Semua", modifier = Modifier.padding(10.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Tab(selected = selectedTab == "MENUNGGU", onClick = { selectedTab = "MENUNGGU" }) {
                Text("Diajukan", modifier = Modifier.padding(10.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Tab(selected = selectedTab == "PROSES", onClick = { selectedTab = "PROSES" }) {
                Text("Diterima", modifier = Modifier.padding(10.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Tab(selected = selectedTab == "RIWAYAT", onClick = { selectedTab = "RIWAYAT" }) {
                Text("Selesai", modifier = Modifier.padding(10.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Tab(selected = selectedTab == "ESCROW", onClick = { selectedTab = "ESCROW" }) {
                Text("Escrow Live", modifier = Modifier.padding(10.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (selectedTab == "ESCROW") {
            val transactions = viewModel.firestoreTransactions
            if (transactions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Lock,
                            contentDescription = "Escrow",
                            modifier = Modifier.size(48.dp),
                            tint = Color.LightGray
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Belum ada transaksi di-hold.", color = Color.Gray, fontSize = 14.sp)
                        Text("Pesan jasa untuk mencoba simulasi Escrow Firestore.", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(transactions) { tx ->
                        val (bgColor, textColor, label) = when {
                            tx.status.contains("RELEASED") -> Triple(Color(0xFFE8F5E9), Color(0xFF2E7D32), "SUKSES CAIR")
                            tx.status.contains("REFUNDED") -> Triple(Color(0xFFFFEBEE), Color(0xFFC62828), "REFUNDED")
                            tx.status.contains("Diterima") -> Triple(Color(0xFFE3F2FD), Color(0xFF1565C0), "PROSES")
                            else -> Triple(Color(0xFFFFF3E0), Color(0xFFEF6C00), "ESCROW HOLD")
                        }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("escrow_tx_card_${tx.bookingId}"),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = tx.id,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )

                                    Surface(
                                        color = bgColor,
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(
                                            text = label,
                                            color = textColor,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Black,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = tx.serviceTitle,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(modifier = Modifier.fillMaxWidth()) {
                                    Text("Pelanggan: ", fontSize = 12.sp, color = Color.Gray)
                                    Text(tx.customerName, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text("Mitra: ", fontSize = 12.sp, color = Color.Gray)
                                    Text(tx.partnerName, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }

                                Divider(modifier = Modifier.padding(vertical = 12.dp), color = Color.LightGray.copy(alpha = 0.5f))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = if (tx.status.contains("RELEASED")) Icons.Default.CheckCircle else Icons.Default.Info,
                                                contentDescription = null,
                                                tint = textColor,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = tx.description,
                                                fontSize = 12.sp,
                                                color = Color.DarkGray,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        val timeStr = java.text.SimpleDateFormat("dd MMM yyyy HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(tx.timestamp))
                                        Text(
                                            text = "Diperbarui: $timeStr WIB",
                                            fontSize = 10.sp,
                                            color = Color.Gray
                                        )
                                    }

                                    Text(
                                        text = formatRupiah(tx.amount),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            val isBookingsLoading = viewModel.isBookingsLoading
            if (isBookingsLoading) {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(4) {
                        BookingItemSkeletonCard()
                    }
                }
            } else if (filtered.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Tidak ada data pesanan.", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(filtered) { item ->
                        BookingItemCard(
                            booking = item,
                            onUpdateAction = { action ->
                                viewModel.updateBookingStatusAction(item.id, item.status, action)
                            },
                            onWriteReview = {
                                selectedBookingForReview = item
                            }
                        )
                    }
                }
            }
        }
    }

    // Write Review Dialog
    if (selectedBookingForReview != null) {
        val b = selectedBookingForReview!!
        var starCount by remember { mutableStateOf(5) }
        var reviewText by remember { mutableStateOf("") }
        
        AlertDialog(
            onDismissRequest = { selectedBookingForReview = null },
            title = { Text("Tulis Ulasan Mitra") },
            text = {
                Column {
                    Text("Berikan bintang untuk " + b.partnerName, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    StarRatingInput(
                        rating = starCount,
                        onRatingSelected = { starCount = it },
                        starSize = 36.dp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = reviewText,
                        onValueChange = { reviewText = it },
                        label = { Text("Isi Masukan / Komentar") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.submitReview(b.id, starCount, reviewText)
                        selectedBookingForReview = null
                    }
                ) {
                    Text("Kirim Ulasan")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedBookingForReview = null }) {
                    Text("Batal")
                }
            }
        )
    }
}

@Composable
fun BookingItemCard(
    booking: Booking,
    onUpdateAction: (String) -> Unit = {},
    onWriteReview: () -> Unit = {},
    viewModel: JasaInViewModel? = null,
    onCancelClick: (() -> Unit)? = null,
    onFinishClick: (() -> Unit)? = null,
    onChatClick: (() -> Unit)? = null,
    isMitraView: Boolean = false
) {
    val isEnglish = LocalIsEnglishState.current
    val statusLabel = when (booking.status) {
        "Diajukan" -> if (isEnglish) "Pending" else "Diajukan"
        "Diterima" -> if (isEnglish) "Confirmed" else "Diterima"
        "Selesai" -> if (isEnglish) "Completed" else "Selesai"
        "Dibatalkan" -> if (isEnglish) "Cancelled" else "Dibatalkan"
        "Ditolak" -> if (isEnglish) "Rejected" else "Ditolak"
        else -> booking.status
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    booking.serviceCategory,
                    fontSize = 11.sp,
                    color = getCategoryColor(booking.serviceCategory),
                    fontWeight = FontWeight.Bold
                )

                // Status Badge
                Surface(
                    color = when (booking.status) {
                        "Diajukan" -> Color(0xFFFFF3E0)
                        "Diterima" -> Color(0xFFE8F5E9)
                        "Selesai" -> Color(0xFFE0F2F1)
                        else -> Color(0xFFFFEBEE)
                    },
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        statusLabel,
                        color = when (booking.status) {
                            "Diajukan" -> Color(0xFFEF6C00)
                            "Diterima" -> Color(0xFF2E7D32)
                            "Selesai" -> Color(0xFF00695C)
                            else -> Color(0xFFC62828)
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(booking.serviceTitle, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            if (isMitraView) {
                Text("Pelanggan: " + booking.customerName, fontSize = 12.sp, color = Color.Gray)
            } else {
                Text("Mitra: " + booking.partnerName, fontSize = 12.sp, color = Color.Gray)
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = Color.LightGray.copy(alpha = 0.3f))
            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Jadwal", fontSize = 11.sp, color = Color.Gray)
                    Text(booking.bookingDate + " • " + booking.bookingTime, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Total Biaya", fontSize = 11.sp, color = Color.Gray)
                    Text(formatRupiah(booking.price), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }

            // Note display
            if (booking.note.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                _NoteCardRow(note = booking.note)
            }

            // Response display
            booking.partnerResponse?.let { resp ->
                if (resp.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    _PartnerResponseRow(partner = booking.partnerName, response = resp)
                }
            }

            // Real-Time OSM Booking Tracking Map for Customer
            if (!isMitraView && booking.status == "Diterima") {
                Spacer(modifier = Modifier.height(12.dp))
                TrackingArrivalMap(booking = booking)
            }

            // Interactive Actions
            if (isMitraView) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Chat button
                    onChatClick?.let { chat ->
                        OutlinedButton(
                            onClick = chat,
                            modifier = Modifier.weight(1f).height(40.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Chat", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    when (booking.status) {
                        "Diajukan" -> {
                            // Decline Button
                            onCancelClick?.let { cancel ->
                                OutlinedButton(
                                    onClick = cancel,
                                    modifier = Modifier.weight(1f).height(40.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                                ) {
                                    Text("Tolak", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            // Accept Button
                            onFinishClick?.let { finish ->
                                Button(
                                    onClick = finish,
                                    modifier = Modifier.weight(1.2f).height(40.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Terima", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        "Diterima" -> {
                            // Done Button
                            onFinishClick?.let { finish ->
                                Button(
                                    onClick = finish,
                                    modifier = Modifier.weight(2f).height(40.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Selesaikan", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        "Selesai" -> {
                            // Selesai is static on Mitra view but can display ulasan if any
                            if (booking.rating != null && booking.rating != 0) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(top = 8.dp)
                                ) {
                                    Icon(Icons.Default.Star, "Bintang", tint = JasaInAccent, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Rating Pelanggan: ${booking.rating} / 5", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    booking.reviewText?.let { rev ->
                                        if (rev.isNotEmpty()) {
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("(${rev})", fontSize = 11.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                            } else {
                                Box(
                                    modifier = Modifier.weight(2f),
                                    contentAlignment = Alignment.CenterEnd
                                ) {
                                    Text("Belum ada ulasan", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
            } else {
                when (booking.status) {
                    "Diterima" -> {
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { onUpdateAction("SELESAI") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Konfirmasi Layanan Selesai", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    "Selesai" -> {
                        if (booking.rating == null || booking.rating == 0) {
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedButton(
                                onClick = onWriteReview,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(40.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Beri Bintang & Ulasan", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Star, "Bintang", tint = JasaInAccent, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Rating Anda: ${booking.rating} / 5", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                booking.reviewText?.let { rev ->
                                    if (rev.isNotEmpty()) {
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("(${rev})", fontSize = 11.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                        }
                    }
                    "Diajukan" -> {
                        Spacer(modifier = Modifier.height(12.dp))
                        TextButton(
                            onClick = { onUpdateAction("BATAL") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Batalkan Booking", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun _NoteCardRow(note: String) {
    Surface(
        color = Color(0xFFF5F5F5),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(Icons.Default.Info, "Catatan", tint = Color.Gray, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Catatan: $note", fontSize = 11.sp, color = Color.DarkGray)
        }
    }
}

@Composable
fun _PartnerResponseRow(partner: String, response: String) {
    Surface(
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(Icons.Default.Reply, "Respon", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Komentar $partner: \"$response\"", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun PelangganChatListScreen(viewModel: JasaInViewModel) {
    val chats by viewModel.activeChatsList.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        JasaInTopAppBar(
            title = "Kotak Masuk Chat",
            showModeTabs = true,
            viewModel = viewModel
        )

        if (chats.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Chat,
                        contentDescription = "Pesan Kosong",
                        tint = Color.LightGray,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Belum ada obrolan aktif.", color = Color.Gray)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1.5f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(chats) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.openChatWith(item.partnerName) }
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = item.partnerName.take(1).uppercase(),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.partnerName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (item.senderRole == "PELANGGAN") "Anda: ${item.lastMessage}" else item.lastMessage,
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Icon(Icons.Default.ChevronRight, "Lanjut", tint = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PelangganChatDetailScreen(viewModel: JasaInViewModel) {
    val partner = viewModel.activeChatPartner ?: "Mitra JASAin"
    val messages by viewModel.chatMessages.collectAsState()
    var inputMessage by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        JasaInTopAppBar(
            title = partner,
            onBackClick = {
                viewModel.navigateTo(if (viewModel.isMitraMode()) "PELANGGAN_CHAT_LIST" else "PELANGGAN_CHAT_LIST")
            },
            actions = {
                if (partner == "JASAin-AI") {
                    var showHumanSupportDialog by remember { mutableStateOf(false) }

                    IconButton(
                        onClick = { showHumanSupportDialog = true },
                        modifier = Modifier.testTag("ai_support_human_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SupportAgent,
                            contentDescription = "Hubungi Bantuan Manusia",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    if (showHumanSupportDialog) {
                        AlertDialog(
                            onDismissRequest = { showHumanSupportDialog = false },
                            title = { Text("Hubungi CS Manusia") },
                            text = { Text("Apakah Anda ingin dialihkan ke layanan pelanggan (Customer Service) manusia untuk mendapatkan bantuan darurat?") },
                            confirmButton = {
                                Button(
                                    onClick = {
                                        showHumanSupportDialog = false
                                        // Simulate adding human CS
                                        viewModel.insertSystemMessage(
                                            partnerName = "Aditya (CS JASAin)",
                                            text = "Halo Bapak Budi! Saya Aditya dari tim CS JASAin. Saya melihat Anda memerlukan bantuan khusus atau darurat. Ada masalah apa yang bisa saya bantu atau tindak lanjuti saat ini?"
                                        )
                                        viewModel.openChatWith("Aditya (CS JASAin)")
                                    }
                                ) {
                                    Text("Ya, Alihkan")
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { showHumanSupportDialog = false }) {
                                    Text("Batal")
                                }
                            }
                        )
                    }
                }
            }
        )

        // Chat Bubble list
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { msg ->
                val isMyMessage = if (viewModel.isMitraMode()) {
                    msg.senderRole == "MITRA"
                } else {
                    msg.senderRole == "PELANGGAN"
                }

                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = if (isMyMessage) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Column(
                        horizontalAlignment = if (isMyMessage) Alignment.End else Alignment.Start
                    ) {
                        Surface(
                            color = if (isMyMessage) MaterialTheme.colorScheme.primary else Color(0xFFECEFF1),
                            shape = RoundedCornerShape(
                                topStart = 12.dp,
                                topEnd = 12.dp,
                                bottomStart = if (isMyMessage) 12.dp else 0.dp,
                                bottomEnd = if (isMyMessage) 0.dp else 12.dp
                            )
                        ) {
                            Text(
                                text = msg.messageText,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                color = if (isMyMessage) Color.White else Color.Black,
                                fontSize = 13.sp
                            )
                        }
                        Text(
                            text = if (isMyMessage) "Saya" else msg.senderName,
                            fontSize = 9.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(top = 2.dp, start = 4.dp, end = 4.dp)
                        )
                    }
                }
            }

            if (partner == "JASAin-AI" && viewModel.isAiTyping) {
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Column(
                            horizontalAlignment = Alignment.Start
                        ) {
                            Surface(
                                color = Color(0xFFECEFF1),
                                shape = RoundedCornerShape(
                                    topStart = 12.dp,
                                    topEnd = 12.dp,
                                    bottomStart = 0.dp,
                                    bottomEnd = 12.dp
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.SmartToy,
                                        contentDescription = "AI Typing",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "JASAin-AI sedang mengetik...",
                                        fontSize = 13.sp,
                                        color = Color.Black
                                    )
                                }
                            }
                            Text(
                                text = "JASAin-AI",
                                fontSize = 9.sp,
                                color = Color.Gray,
                                modifier = Modifier.padding(top = 2.dp, start = 4.dp, end = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // Input bottom bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .padding(12.dp)
                    .navigationBarsPadding(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputMessage,
                    onValueChange = { inputMessage = it },
                    placeholder = { Text("Tulis pesan atau pertanyaan...", fontSize = 13.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_text")
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = {
                        if (inputMessage.isNotBlank()) {
                            viewModel.sendChatMessage(inputMessage)
                            inputMessage = ""
                        }
                    },
                    modifier = Modifier
                        .size(52.dp)
                        .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp))
                        .testTag("chat_send_button")
                ) {
                    Icon(Icons.Default.Send, "Kirim", tint = Color.White)
                }
            }
        }
    }
}

@Composable
fun PelangganProfileScreen(viewModel: JasaInViewModel) {
    val profile by viewModel.userProfile.collectAsState()
    val isOnline by viewModel.isOnline.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var showTopUpDialog by remember { mutableStateOf(false) }
    var showWithdrawDialog by remember { mutableStateOf(false) }
    var showProfilePhotoDialog by remember { mutableStateOf(false) }
    var showChangePasswordDialog by remember { mutableStateOf(false) }
    var showEditProfileDialog by remember { mutableStateOf(false) }

    var tempName by remember(profile) { mutableStateOf(profile?.name ?: "") }
    var tempPhone by remember(profile) { mutableStateOf(profile?.phone ?: "") }
    var tempEmail by remember(profile) { mutableStateOf(profile?.email ?: "") }
    var tempAddress by remember(profile) { mutableStateOf(profile?.address ?: "") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        JasaInTopAppBar(
            title = "Profil Pengguna",
            showModeTabs = true,
            viewModel = viewModel
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Card Details
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(62.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer)
                                    .clickable { showProfilePhotoDialog = true }
                                    .testTag("profile_photo_avatar_box"),
                                contentAlignment = Alignment.Center
                            ) {
                                val photoUri = profile?.profilePictureUri
                                if (!photoUri.isNullOrEmpty()) {
                                    AsyncImage(
                                        model = photoUri,
                                        contentDescription = "Foto Profil",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Icon(
                                        Icons.Default.Person,
                                        "Profil",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                            
                            // Small edit badge
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                                    .align(Alignment.BottomEnd)
                                    .border(1.dp, Color.White, CircleShape)
                                    .clickable { showProfilePhotoDialog = true },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit Foto",
                                    tint = Color.White,
                                    modifier = Modifier.size(11.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column {
                            Text(profile?.name ?: "Budi Santoso", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(profile?.email ?: "budi.santoso@gmail.com", fontSize = 13.sp, color = Color.Gray)
                        }
                    }

                    IconButton(
                        onClick = { showEditProfileDialog = true },
                        modifier = Modifier.testTag("edit_customer_profile_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Ubah Profil",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            // Financial JASApay Section
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Dompet JASApay", fontSize = 12.sp, color = Color.Gray)
                            Text(formatRupiah(profile?.balance ?: 500000.0), fontSize = 18.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = { showTopUpDialog = true },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .height(36.dp)
                                    .testTag("profile_topup_button")
                            ) {
                                Icon(Icons.Default.Add, "Isi", modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Top Up", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            FilledTonalButton(
                                onClick = { showWithdrawDialog = true },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .height(36.dp)
                                    .testTag("profile_withdraw_button")
                            ) {
                                Icon(Icons.Default.AccountBalance, "Tarik", modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Tarik", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Contact Info
            Text("Data Domisili & Kontak", fontWeight = FontWeight.Bold, fontSize = 14.sp)

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Phone, "HP", tint = Color.Gray, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(profile?.phone ?: "081234567890", fontSize = 13.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Home, "Alamat", tint = Color.Gray, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(profile?.address ?: "Jl. Jenderal Sudirman No. 12, Senayan, Jakarta Selatan", fontSize = 13.sp)
                    }
                }
            }

            // KYC Status Card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (profile?.isKycVerified == true) Color(0xFFE8F5E9) else Color(0xFFFFF3E0)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (profile?.isKycVerified == true) Icons.Default.VerifiedUser else Icons.Default.GppMaybe,
                        contentDescription = "Status Verifikasi",
                        tint = if (profile?.isKycVerified == true) Color(0xFF2E7D32) else Color(0xFFEF6C00)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (profile?.isKycVerified == true) "KYC Terverifikasi" else "Lengkapi Verifikasi KYC Anda",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (profile?.isKycVerified == true) Color(0xFF1B5E20) else Color(0xFFE65100)
                        )
                        Text(
                            text = if (profile?.isKycVerified == true) "Identitas NIK ${profile?.kycNik ?: ""} cocok. Anda berhak mendapatkan garansi JASAin." else "Input NIK KTP Anda untuk jaminan keamanan transaksi.",
                            fontSize = 11.sp,
                            color = if (profile?.isKycVerified == true) Color(0xFF2E7D32) else Color(0xFFEF6C00)
                        )
                    }
                }
            }

            // Theme Setting
            Text("Pengaturan Tampilan", fontWeight = FontWeight.Bold, fontSize = 14.sp)

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.toggleDarkMode() }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        val darkState by viewModel.isDarkMode.collectAsState()
                        Icon(
                            imageVector = if (darkState) Icons.Default.DarkMode else Icons.Default.LightMode,
                            contentDescription = "Mode Gelap",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(text = "Kenyamanan Mata", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                            Text(text = "Mode Gelap / Malam", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                    val darkState by viewModel.isDarkMode.collectAsState()
                    Switch(
                        checked = darkState,
                        onCheckedChange = { viewModel.toggleDarkMode() },
                        modifier = Modifier.testTag("customer_dark_mode_switch")
                    )
                }
            }

            // Language Setting
            val isEnglish = LocalIsEnglishState.current
            val onLangToggle = LocalLanguageToggle.current
            Text(if (isEnglish) "Language Setting" else "Pengaturan Bahasa", fontWeight = FontWeight.Bold, fontSize = 14.sp)

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onLangToggle() }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            imageVector = Icons.Default.Translate,
                            contentDescription = "Switch Language",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(text = if (isEnglish) "Application Language" else "Bahasa Aplikasi", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                            Text(text = if (isEnglish) "English (EN)" else "Bahasa Indonesia (ID)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                    TextButton(
                        onClick = onLangToggle,
                        modifier = Modifier.testTag("profile_lang_switcher")
                    ) {
                        Text(
                            text = if (isEnglish) "SWITCH TO ID" else "UBAH KE EN",
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            // Account Security / Password Setting
            Text("Pengaturan Keamanan", fontWeight = FontWeight.Bold, fontSize = 14.sp)

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showChangePasswordDialog = true }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Ganti Password",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Keamanan Akun", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                        Text(text = "Ganti PIN / Password", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    }
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Selanjutnya",
                        tint = Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Switch to Partner Mode Toggle
            val isPartner = profile?.isRegisteredAsPartner ?: false
            if (isPartner) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Beralih Mode Jasa",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                        UserRoleToggle(
                            currentRole = "PELANGGAN",
                            onToggle = { viewModel.toggleUserMode() },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            } else {
                Button(
                    onClick = { viewModel.toggleUserMode() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("profile_toggle_user_mode"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Storefront, "Mitra")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Daftar Mitra JASAin (Dapatkan Penghasilan)",
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Log Out Button
            OutlinedButton(
                onClick = { viewModel.logoutAction() },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("profile_logout_button")
            ) {
                Text("Keluar dari Aplikasi", color = MaterialTheme.colorScheme.error)
            }
        }
    }

    if (showTopUpDialog) {
        IsiSaldoDialog(
            onDismiss = { showTopUpDialog = false },
            viewModel = viewModel
        )
    }

    if (showWithdrawDialog) {
        TarikSaldoDialog(
            onDismiss = { showWithdrawDialog = false },
            viewModel = viewModel
        )
    }

    if (showProfilePhotoDialog) {
        ProfilePhotoDialog(
            onDismiss = { showProfilePhotoDialog = false },
            viewModel = viewModel,
            currentPhotoUri = profile?.profilePictureUri
        )
    }

    if (showChangePasswordDialog) {
        ChangePasswordDialog(
            onDismiss = { showChangePasswordDialog = false },
            viewModel = viewModel
        )
    }

    if (showEditProfileDialog) {
        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            title = { Text("Ubah Profil Pelanggan", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = tempName,
                        onValueChange = { tempName = it },
                        label = { Text("Nama Lengkap") },
                        modifier = Modifier.fillMaxWidth().testTag("edit_name_input")
                    )
                    OutlinedTextField(
                        value = tempPhone,
                        onValueChange = { tempPhone = it },
                        label = { Text("No. Telepon") },
                        modifier = Modifier.fillMaxWidth().testTag("edit_phone_input")
                    )
                    OutlinedTextField(
                        value = tempEmail,
                        onValueChange = { tempEmail = it },
                        label = { Text("Email") },
                        modifier = Modifier.fillMaxWidth().testTag("edit_email_input"),
                        enabled = false
                    )
                    OutlinedTextField(
                        value = tempAddress,
                        onValueChange = { tempAddress = it },
                        label = { Text("Alamat Tinggal") },
                        modifier = Modifier.fillMaxWidth().testTag("edit_address_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (tempName.isNotBlank() && tempPhone.isNotBlank()) {
                            viewModel.updateProfileInfo(tempName, tempPhone, tempEmail, tempAddress)
                        }
                        showEditProfileDialog = false
                    },
                    modifier = Modifier.testTag("save_profile_confirm")
                ) {
                    Text("Simpan")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }
}

@Composable
fun PelangganPartnerRegistrationScreen(viewModel: JasaInViewModel) {
    val profile by viewModel.userProfile.collectAsState()

    var businessName by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Kebersihan & Laundry") }
    var phone by remember { mutableStateOf(profile?.phone ?: "") }
    var location by remember { mutableStateOf("Banjarmasin") }
    var customLocationDetail by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("75000") }
    var priceUnit by remember { mutableStateOf("jam") }

    var showCatDropdown by remember { mutableStateOf(false) }
    var showLocDropdown by remember { mutableStateOf(false) }
    var showUnitDropdown by remember { mutableStateOf(false) }

    var errorMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        JasaInTopAppBar(
            title = "Form Pendaftaran Mitra",
            onBackClick = { viewModel.navigateTo("PELANGGAN_PROFILE") }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Information Callout Header
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(14.dp)) {
                    Icon(Icons.Default.Info, "Informasi", tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Dengan mendaftar sebagai mitra, Anda dapat menawarkan jasa Anda kepada jutaan pelanggan JASAin di seluruh wilayah Indonesia.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Form inputs
            Text("Siapkan Informasi Jasa Anda", fontWeight = FontWeight.Bold, fontSize = 14.sp)

            OutlinedTextField(
                value = businessName,
                onValueChange = { businessName = it; errorMsg = null },
                label = { Text("Nama Usaha / Nama Kompetensi") },
                placeholder = { Text("misal: Mandiri AC Service, Guru Privat Indah") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("regpartner_business_name"),
                singleLine = true
            )

            // Category DROPDOWN
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = selectedCategory,
                    onValueChange = { },
                    label = { Text("Kategori Layanan Utama") },
                    readOnly = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showCatDropdown = true }
                        .testTag("regpartner_category"),
                    trailingIcon = { Icon(Icons.Default.ArrowDropDown, "Pilih") }
                )
                DropdownMenu(
                    expanded = showCatDropdown,
                    onDismissRequest = { showCatDropdown = false },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Filter "Semua"
                    ExpandedCategories.filter { it != "Semua" }.forEach { category ->
                        DropdownMenuItem(
                            text = { Text(category) },
                            onClick = {
                                selectedCategory = category
                                showCatDropdown = false
                            }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it; errorMsg = null },
                label = { Text("No. HP / WhatsApp Bisnis") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("regpartner_phone"),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
            )

            // Location Selector DROPDOWN
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = location,
                    onValueChange = { },
                    label = { Text("Wilayah Operasional Utama") },
                    readOnly = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showLocDropdown = true }
                        .testTag("regpartner_location"),
                    trailingIcon = { Icon(Icons.Default.ArrowDropDown, "Pilih") }
                )
                DropdownMenu(
                    expanded = showLocDropdown,
                    onDismissRequest = { showLocDropdown = false }
                ) {
                    ExpandedLocations.filter { it != "Semua" }.forEach { loc ->
                        DropdownMenuItem(
                            text = { Text(loc) },
                            onClick = {
                                location = loc
                                showLocDropdown = false
                            }
                        )
                    }
                }
            }

            if (location == "Luar Kalsel (Masa Tunggu)") {
                OutlinedTextField(
                    value = customLocationDetail,
                    onValueChange = { customLocationDetail = it; errorMsg = null },
                    label = { Text("Masukkan Nama Kota/Daerah Anda") },
                    placeholder = { Text("misal: Balikpapan, Jakarta Selatan, Sleman") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("regpartner_custom_location_detail"),
                    singleLine = true
                )

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f),
                        contentColor = MaterialTheme.colorScheme.onErrorContainer
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, "Peringatan Eksklusivitas", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Wilayah Daftar Tunggu (Waitlist)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "JASAin saat ini memprioritaskan perilisan dan operasional penuh di wilayah Kalimantan Selatan. Pendaftaran Anda di luar Kalsel akan masuk antrean dengan estimasi WAKTU TUNGGU sekitar 14 hingga 30 hari kerja sampai ekspansi ke daerah Anda diaktifkan.",
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            OutlinedTextField(
                value = description,
                onValueChange = { description = it; errorMsg = null },
                label = { Text("Deskripsi Keahlian & Jaminan Layanan") },
                placeholder = { Text("Tulis rincian servis, jam operasional, jaminan garansi 30 hari dll...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("regpartner_description")
            )

            // Estimasi Tarif
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("Estimasi Harga Jasa (Rp)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("regpartner_price"),
                    singleLine = true
                )

                Box(modifier = Modifier.weight(0.8f)) {
                    OutlinedTextField(
                        value = priceUnit,
                        onValueChange = { },
                        label = { Text("Satuan") },
                        readOnly = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showUnitDropdown = true },
                        trailingIcon = { Icon(Icons.Default.ArrowDropDown, "Unit") }
                    )
                    DropdownMenu(
                        expanded = showUnitDropdown,
                        onDismissRequest = { showUnitDropdown = false }
                    ) {
                        listOf("jam", "unit", "sesi", "m2", "kegiatan", "kunjungan").forEach { u ->
                            DropdownMenuItem(
                                text = { Text(u) },
                                onClick = {
                                    priceUnit = u
                                    showUnitDropdown = false
                                }
                            )
                        }
                    }
                }
            }

            if (errorMsg != null) {
                Text(
                    text = errorMsg!!,
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = {
                    val priceVal = priceText.toDoubleOrNull() ?: 0.0
                    if (location == "Luar Kalsel (Masa Tunggu)" && customLocationDetail.isBlank()) {
                        errorMsg = "Harap cantumkan nama kota atau daerah asal pendaftaran Anda!"
                    } else if (businessName.isBlank() || phone.isBlank() || description.isBlank() || priceVal <= 0.0) {
                        errorMsg = "Mohon isi semua data pendaftaran dengan benar!"
                    } else {
                        viewModel.registerPartnerAction(
                            businessName = businessName,
                            category = selectedCategory,
                            phone = phone,
                            location = if (location == "Luar Kalsel (Masa Tunggu)") "Luar Kalsel: $customLocationDetail" else location,
                            description = description,
                            availability = "Senin - Sabtu (Terjadwal)",
                            price = priceVal,
                            priceUnit = priceUnit
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .height(50.dp)
                    .testTag("regpartner_submit_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Daftar Mitra JASAin", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}

@Composable
fun StarRatingInput(
    rating: Int,
    onRatingSelected: (Int) -> Unit,
    modifier: Modifier = Modifier,
    starCount: Int = 5,
    starSize: androidx.compose.ui.unit.Dp = 36.dp
) {
    Row(
        modifier = modifier.testTag("star_rating_input_row"),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        (1..starCount).forEach { star ->
            val isSelected = star <= rating
            IconButton(
                onClick = { onRatingSelected(star) },
                modifier = Modifier
                    .size(48.dp)
                    .testTag("star_input_$star")
            ) {
                Icon(
                    imageVector = if (isSelected) Icons.Default.Star else Icons.Default.StarOutline,
                    contentDescription = "$star Bintang",
                    tint = if (isSelected) JasaInAccent else Color.Gray.copy(alpha = 0.6f),
                    modifier = Modifier.size(starSize)
                )
            }
        }
    }
}

@Composable
fun MyBookingsDashboardSection(
    bookings: List<Booking>,
    onWriteReview: (Booking) -> Unit,
    viewModel: JasaInViewModel,
    showSeeAll: Boolean = true
) {
    // Show active and recently completed bookings (last 4 bookings)
    val displayedBookings = remember(bookings) {
        bookings.filter { it.status == "Diajukan" || it.status == "Diterima" || it.status == "Selesai" }
            .take(4)
    }

    if (displayedBookings.isEmpty()) return

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.BookmarkBorder,
                    contentDescription = "Pesanan Saya",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Pesanan Saya (My Bookings)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
            if (showSeeAll) {
                Text(
                    text = "Lihat Semua",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .clickable { viewModel.navigateTo("PELANGGAN_TRANSAKSI") }
                        .testTag("my_bookings_see_all")
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 2.dp)
        ) {
            items(displayedBookings) { booking ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    border = BorderStroke(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
                    ),
                    modifier = Modifier
                        .width(230.dp)
                        .testTag("dashboard_booking_card_${booking.id}")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Mini category icon
                            val categoryColor = when (booking.serviceCategory) {
                                "Rumah Tangga" -> Color(0xFF006A60)
                                "Elektronik" -> Color(0xFF0284C7)
                                "Edukasi" -> Color(0xFFE0533C)
                                "Kecantikan & Kesehatan" -> Color(0xFFD97706)
                                else -> MaterialTheme.colorScheme.primary
                            }

                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(categoryColor.copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center
                            ) {
                                CategoryIconMapper(
                                    category = booking.serviceCategory,
                                    modifier = Modifier.size(14.dp),
                                    tint = categoryColor
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = booking.serviceTitle,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Mitra: ${booking.partnerName}",
                                    fontSize = 9.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Status indicator badge
                            val (statusText, statusColor, statusIcon) = when (booking.status) {
                                "Diajukan" -> Triple("Pending", Color(0xFFD97706), Icons.Default.AccessTime)
                                "Diterima" -> Triple("Active", Color(0xFF0284C7), Icons.Default.Cached)
                                "Selesai" -> Triple("Done", Color(0xFF16A34A), Icons.Default.CheckCircle)
                                else -> Triple(booking.status, Color.Gray, Icons.Default.Info)
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(statusColor.copy(alpha = 0.1f))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = statusIcon,
                                        contentDescription = statusText,
                                        tint = statusColor,
                                        modifier = Modifier.size(9.dp)
                                    )
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(
                                        text = statusText,
                                        color = statusColor,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }

                            Text(
                                text = booking.bookingDate,
                                fontSize = 8.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                            )
                        }

                        // Compact Rating row if Selesai
                        if (booking.status == "Selesai") {
                            Spacer(modifier = Modifier.height(4.dp))
                            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                            Spacer(modifier = Modifier.height(3.dp))
                            if (booking.rating == null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Beri Rating:",
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    var localRatedStars by remember { mutableStateOf(0) }
                                    StarRatingInput(
                                        rating = localRatedStars,
                                        onRatingSelected = { star ->
                                            localRatedStars = star
                                            viewModel.submitReview(booking.id, star, "Ulasan kilat dari dashboard")
                                        },
                                        starSize = 14.dp
                                    )
                                }
                            } else {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        tint = Color(0xFFFBBF24),
                                        modifier = Modifier.size(10.dp)
                                    )
                                    Text(
                                        text = "Ulasan: ${booking.rating}/5 \u2605",
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF16A34A)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ServiceProviderDetailDialog(
    listing: ServiceListing,
    onDismiss: () -> Unit,
    onBookNow: () -> Unit,
    viewModel: JasaInViewModel
) {
    val categoryColor = getCategoryColor(listing.category)
    val imgRes = getCategoryDrawableId(listing.category)

    // User Testimonials based on category
    val testimonials = when (listing.category) {
        "Rumah Tangga", "Kebersihan", "Pertukangan", "Kebersihan & Laundry", "Pertukangan & Renovasi" -> listOf(
            Pair("Ibu Susi (Cilandak)", "Pekerjaan sangat rapi dan bersih. Datang tepat waktu dan sopan sekali."),
            Pair("Bp. Joko (Kebayoran)", "Sangat direkomendasikan! Lantai mengkilap dan pengerjaan cepat.")
        )
        "Elektronik", "Servis AC & Elektronik" -> listOf(
            Pair("Bp. Budi (Pondok Indah)", "AC saya jadi dingin lagi seperti baru. Harganya jujur dan transparan."),
            Pair("Ibu Rini (Tebet)", "Sangat ahli memperbaiki mesin cuci. Sangat profesional.")
        )
        "Edukasi", "Les Privat & Konsultasi" -> listOf(
            Pair("Bp. Gunawan (Kemang)", "Anak saya nilainya langsung naik drastis setelah diajar oleh beliau."),
            Pair("Siti (Depok)", "Tutornya sabar banget dan penjelasannya sangat gampang dimengerti.")
        )
        "Kecantikan & Kesehatan", "Kecantikan, Pijat & Spa", "Layanan Kesehatan" -> listOf(
            Pair("Ibu Maria (Menteng)", "Pijatannya mantap sekali, langsung segar dan pegal-pegal hilang!"),
            Pair("Bp. Anton (Pluit)", "Refleksinya sangat professional dan higienis. Sumpah enak banget.")
        )
        else -> listOf(
            Pair("Pelanggan Setia", "Layanan yang professional dan memuaskan. Sangat ramah dan direkomendasikan.")
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .fillMaxWidth(0.92f)
            .wrapContentHeight()
            .clip(RoundedCornerShape(24.dp))
            .testTag("provider_detail_dialog"),
        confirmButton = {
            Button(
                onClick = onBookNow,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("detail_dialog_book_button")
            ) {
                Text("Book Now")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("detail_dialog_dismiss_button")
            ) {
                Text("Tutup")
            }
        },
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Profil Penyedia Jasa",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, "Tutup")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 450.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Banner Top using generated high-quality images
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(14.dp))
                ) {
                    Image(
                        painter = painterResource(id = imgRes),
                        contentDescription = listing.category,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(categoryColor)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = listing.category,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Service & Provider Name
                Text(
                    text = listing.title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Mitra: ${listing.partnerName}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Clickable Rating
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
                                .clickable {
                                    onDismiss() // Close detail dialog to show reviews
                                    viewModel.openReviewsFor(listing.partnerName)
                                }
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                                .testTag("detail_dialog_rating_badge")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Rating",
                                tint = JasaInAccent,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = listing.partnerRating.toString(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Verified,
                                    contentDescription = "Verified",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(11.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Verified",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Price Section
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = formatRupiah(listing.price),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = " / ${listing.priceUnit}",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = Color.LightGray.copy(alpha = 0.3f))
                Spacer(modifier = Modifier.height(12.dp))

                // Full Profile Description
                Text(
                    text = "Tentang Penyedia Jasa:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = listing.description,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Testimonials List
                Text(
                    text = "Ulasan & Testimoni Pelanggan:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))

                testimonials.forEach { t ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = t.first,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = "Star",
                                        tint = JasaInAccent,
                                        modifier = Modifier.size(11.dp)
                                    )
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(
                                        text = "5.0",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "\"${t.second}\"",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                            )
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun TarikSaldoDialog(
    onDismiss: () -> Unit,
    viewModel: JasaInViewModel
) {
    var amountText by remember { mutableStateOf("") }
    val methods = listOf("GoPay", "OVO", "DANA", "ShopeePay", "LinkAja", "Bank BCA", "Bank Mandiri", "Bank BRI", "Bank BNI")
    var selectedMethod by remember { mutableStateOf("GoPay") }
    var accountNo by remember { mutableStateOf("") }
    var accountName by remember { mutableStateOf("") }
    
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    if (successMessage != null) {
        AlertDialog(
            onDismissRequest = {
                successMessage = null
                onDismiss()
            },
            title = { Text("Penarikan Berhasil", fontWeight = FontWeight.Bold) },
            text = { Text(successMessage!!) },
            confirmButton = {
                Button(
                    onClick = {
                        successMessage = null
                        onDismiss()
                    },
                    modifier = Modifier.testTag("tarik_success_ok_button")
                ) {
                    Text("OK")
                }
            }
        )
    } else {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Tarik Saldo JASApay", fontWeight = FontWeight.Black) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "Tarik dana dari saldo Dompet JASApay Anda dengan mudah & instan ke Bank atau E-Wallet pilihan Anda.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Pilih Metode Transfer:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        methods.forEach { method ->
                            val isSelected = selectedMethod == method
                            Surface(
                                modifier = Modifier
                                    .clickable { selectedMethod = method }
                                    .testTag("customer_withdraw_chip_$method"),
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = if (!isSelected) BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant) else null
                            ) {
                                Text(
                                    text = method,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = accountNo,
                        onValueChange = { accountNo = it },
                        label = { Text(if (selectedMethod.startsWith("Bank")) "Nomor Rekening Anda" else "Nomor HP Akun E-Wallet") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("customer_withdraw_account_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = accountName,
                        onValueChange = { accountName = it },
                        label = { Text("Nama Lengkap Pemilik Rekening") },
                        modifier = Modifier.fillMaxWidth().testTag("customer_withdraw_name_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it },
                        label = { Text("Nominal Penarikan (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("customer_withdraw_amount_input"),
                        singleLine = true
                    )

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorMessage!!,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = amountText.toDoubleOrNull() ?: 0.0
                        if (amount <= 0) {
                            errorMessage = "Nominal penarikan harus lebih besar dari 0!"
                        } else if (accountNo.isBlank() || accountName.isBlank()) {
                            errorMessage = "Formulir harus diisi dengan lengkap!"
                        } else {
                            val success = viewModel.withdrawBalance(amount)
                            if (success) {
                                errorMessage = null
                                successMessage = "Selamat! Penarikan dana sebesar ${formatRupiah(amount)} sukses ditransfer melalui $selectedMethod ke rekening $accountNo atas nama $accountName. Silakan cek berkala!"
                            } else {
                                errorMessage = "Saldo tidak cukup untuk penarikan sebesar ${formatRupiah(amount)}!"
                            }
                        }
                    },
                    modifier = Modifier.testTag("customer_withdraw_confirm_btn")
                ) {
                    Text("Tarik Saldo")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("customer_withdraw_cancel_btn")
                ) {
                    Text("Batal")
                }
            }
        )
    }
}

@Composable
fun IsiSaldoDialog(
    onDismiss: () -> Unit,
    viewModel: JasaInViewModel
) {
    var amountText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    if (successMessage != null) {
        AlertDialog(
            onDismissRequest = {
                successMessage = null
                onDismiss()
            },
            title = { Text("Isi Saldo Berhasil", fontWeight = FontWeight.Bold) },
            text = { Text(successMessage!!) },
            confirmButton = {
                Button(
                    onClick = {
                        successMessage = null
                        onDismiss()
                    },
                    modifier = Modifier.testTag("topup_success_ok_button")
                ) {
                    Text("OK")
                }
            }
        )
    } else {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Isi Saldo JASApay", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        text = "Isi saldo instant & nikmati kemudahan bertransaksi di JASAin.",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it },
                        label = { Text("Jumlah Top Up (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("topup_amount_input"),
                        singleLine = true
                    )
                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorMessage!!,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = amountText.toDoubleOrNull() ?: 0.0
                        if (amt < 10000) {
                            errorMessage = "Minimal isi saldo adalah Rp10.000!"
                        } else {
                            viewModel.topupBalance(amt)
                            errorMessage = null
                            successMessage = "Selamat! Isi saldo akun JASApay sebesar ${formatRupiah(amt)} sukses dilakukan."
                        }
                    },
                    modifier = Modifier.testTag("topup_confirm_btn")
                ) {
                    Text("Isi Saldo")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("topup_cancel_btn")
                ) {
                    Text("Batal")
                }
            }
        )
    }
}

@Composable
fun ProfilePhotoDialog(
    onDismiss: () -> Unit,
    viewModel: JasaInViewModel,
    currentPhotoUri: String?
) {
    var customUrl by remember { mutableStateOf(currentPhotoUri ?: "") }
    
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            customUrl = it.toString()
        }
    }
    
    val presetAvatars = listOf(
        Pair("https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=200&auto=format&fit=crop", "Sara (Edukasi)"),
        Pair("https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop", "Agung (Teknologi)"),
        Pair("https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200&auto=format&fit=crop", "Dewi (Kecantikan)"),
        Pair("https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=200&auto=format&fit=crop", "Budi (Mekanik AC)"),
        Pair("https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop", "Siti (Kebersihan)")
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically, 
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Default.PhotoCamera, 
                    "Foto Profil", 
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    "Pilih Foto Profil", 
                    fontWeight = FontWeight.Black, 
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Lengkapi profil Anda dengan memilih avatar profesional atau tempelkan tautan (URL) gambar kustom Anda di bawah.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Current Preview
                Text("Pratinjau Foto:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .align(Alignment.CenterHorizontally),
                    contentAlignment = Alignment.Center
                ) {
                    if (customUrl.isNotBlank()) {
                        AsyncImage(
                            model = customUrl,
                            contentDescription = "Preview",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(
                            Icons.Default.Person,
                            "Belum ada foto",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(44.dp)
                        )
                    }
                }

                OutlinedButton(
                    onClick = { galleryLauncher.launch("image/*") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("choose_from_gallery_btn"),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = "Pilih dari Galeri",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Ambil dari Galeri Foto")
                }

                // Preset Avatars
                Text("Preset Avatar Profesional:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    items(presetAvatars) { (url, label) ->
                        val isSelected = customUrl == url
                        Card(
                            modifier = Modifier
                                .width(110.dp)
                                .clickable { customUrl = url },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                            ),
                            border = BorderStroke(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                AsyncImage(
                                    model = url,
                                    contentDescription = label,
                                    modifier = Modifier
                                        .size(54.dp)
                                        .clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = label,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                // Custom URL Input
                Text("Atau Masukkan URL Gambar:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                OutlinedTextField(
                    value = customUrl,
                    onValueChange = { customUrl = it },
                    placeholder = { Text("https://example.com/foto.jpg", fontSize = 12.sp) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_photo_url_input"),
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp),
                    singleLine = true,
                    leadingIcon = {
                        Icon(Icons.Default.Link, "Link", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    },
                    trailingIcon = {
                        if (customUrl.isNotEmpty()) {
                            IconButton(onClick = { customUrl = "" }) {
                                Icon(Icons.Default.Clear, "Hapus", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    viewModel.updateProfilePicture(customUrl)
                    onDismiss()
                },
                modifier = Modifier.testTag("confirm_photo_button")
            ) {
                Text("Simpan Foto")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_photo_button")
            ) {
                Text("Batal")
            }
        }
    )
}

@Composable
fun ChangePasswordDialog(
    onDismiss: () -> Unit,
    viewModel: JasaInViewModel
) {
    var oldPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    
    var errorText by remember { mutableStateOf<String?>(null) }
    var successText by remember { mutableStateOf<String?>(null) }
    
    val currentPin by viewModel.userPassword.collectAsState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Default.Lock,
                    "Lock",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    "Ganti PIN / Password",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Ganti PIN transaksi JASApay dan PIN masuk Anda. Gunakan minimal 4 digit angka/karakter.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (errorText != null) {
                    Text(
                        text = errorText!!,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (successText != null) {
                    Text(
                        text = successText!!,
                        color = Color(0xFF16A34A),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Old Password
                OutlinedTextField(
                    value = oldPin,
                    onValueChange = { 
                        oldPin = it
                        errorText = null
                    },
                    label = { Text("PIN Lama") },
                    placeholder = { Text("Masukkan PIN lama") },
                    modifier = Modifier.fillMaxWidth().testTag("old_password_input"),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true
                )

                // New Password
                OutlinedTextField(
                    value = newPin,
                    onValueChange = { 
                        newPin = it
                        errorText = null
                    },
                    label = { Text("PIN Baru") },
                    placeholder = { Text("Masukkan PIN baru") },
                    modifier = Modifier.fillMaxWidth().testTag("new_password_input"),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true
                )

                // Confirm New Password
                OutlinedTextField(
                    value = confirmPin,
                    onValueChange = { 
                        confirmPin = it
                        errorText = null
                    },
                    label = { Text("Konfirmasi PIN Baru") },
                    placeholder = { Text("Masukkan ulang PIN baru") },
                    modifier = Modifier.fillMaxWidth().testTag("confirm_password_input"),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (oldPin != currentPin) {
                        errorText = "PIN Lama salah!"
                    } else if (newPin.length < 4) {
                        errorText = "PIN Baru minimal 4 karakter!"
                    } else if (newPin != confirmPin) {
                        errorText = "Konfirmasi PIN Baru tidak sesuai!"
                    } else {
                        viewModel.updatePassword(newPin)
                        successText = "PIN berhasil diperbarui!"
                        oldPin = ""
                        newPin = ""
                        confirmPin = ""
                    }
                },
                modifier = Modifier.testTag("save_password_btn")
            ) {
                Text("Simpan PIN")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_password_btn")
            ) {
                Text("Batal")
            }
        }
    )
}

@Composable
fun ServiceReviewsDialog(
    partnerName: String,
    onDismiss: () -> Unit,
    viewModel: JasaInViewModel
) {
    val allBookings by viewModel.allBookings.collectAsState()
    
    // Filter real reviews
    val realReviews = allBookings.filter { it.partnerName == partnerName && it.rating != null }
    
    var userRating by remember { mutableStateOf(5) }
    var userComment by remember { mutableStateOf("") }
    var successText by remember { mutableStateOf<String?>(null) }
    var errorText by remember { mutableStateOf<String?>(null) }
    
    // Preset placeholder testimonials if no actual reviews exist yet
    val presetReviews = listOf(
        Pair("Susi Lestari (Cilandak)", "Pekerjaan sangat rapi dan bersih. Datang tepat waktu dan sangat sopan sekali."),
        Pair("Joko Supriyanto (Kebayoran)", "Sangat direkomendasikan! Lantai mengkilap dan pengerjaan cepat.")
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = "Review",
                    tint = JasaInAccent,
                    modifier = Modifier.size(28.dp)
                )
                Column {
                    Text(
                        text = "Ulasan & Feedback",
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = partnerName,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 410.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Leaving Feedback Section
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Tulis Ulasan Anda",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        
                        // Star Selection Row
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            (1..5).forEach { starIndex ->
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = "$starIndex Star",
                                    tint = if (starIndex <= userRating) JasaInAccent else Color.LightGray,
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clickable { userRating = starIndex }
                                        .testTag("star_select_$starIndex")
                                )
                            }
                        }
                        
                        // Comment text field
                        OutlinedTextField(
                            value = userComment,
                            onValueChange = { 
                                userComment = it
                                errorText = null
                            },
                            placeholder = { Text("Tulis umpan balik atau pengalaman Anda...", fontSize = 12.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(85.dp)
                                .testTag("review_input_text"),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp),
                            maxLines = 3
                        )
                        
                        if (errorText != null) {
                            Text(errorText!!, color = MaterialTheme.colorScheme.error, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                        if (successText != null) {
                            Text(successText!!, color = Color(0xFF16A34A), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                        
                        Button(
                            onClick = {
                                if (userComment.isBlank()) {
                                    errorText = "Silakan tulis ulasan teks terlebih dahulu!"
                                } else {
                                    viewModel.submitDirectPartnerReview(partnerName, userRating, userComment)
                                    successText = "Ulasan berhasil dikirim!"
                                    userComment = ""
                                    userRating = 5
                                    errorText = null
                                }
                            },
                            modifier = Modifier
                                .align(Alignment.End)
                                .height(34.dp)
                                .testTag("submit_direct_review_btn"),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Kirim Ulasan", fontSize = 11.sp)
                        }
                    }
                }
                
                // Historical Reviews List Section
                Text(
                    text = "Semua Ulasan Pelanggan",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                if (realReviews.isEmpty()) {
                    // Show seed reviews so some feed is always visible and beautiful
                    presetReviews.forEach { (reviewer, text) ->
                        ReviewItem(name = reviewer, rating = 5, comment = text)
                    }
                } else {
                    realReviews.forEach { booking ->
                        ReviewItem(
                            name = booking.customerName,
                            rating = booking.rating ?: 5,
                            comment = booking.reviewText ?: "",
                            partnerResponse = booking.partnerResponse
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                modifier = Modifier.testTag("close_reviews_btn")
            ) {
                Text("Selesai")
            }
        }
    )
}

@Composable
fun ReviewItem(
    name: String,
    rating: Int,
    comment: String,
    partnerResponse: String? = null
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = name,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    repeat(5) { index ->
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Star",
                            tint = if (index < rating) JasaInAccent else Color.LightGray,
                            modifier = Modifier.size(10.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = rating.toString(),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "\"$comment\"",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                lineHeight = 16.sp
            )
            
            if (!partnerResponse.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
                        .padding(8.dp)
                ) {
                    Column {
                        Text(
                            text = "Balasan Mitra:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = partnerResponse,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

private fun bitmapToBase64(bitmap: android.graphics.Bitmap): String {
    val byteArrayOutputStream = java.io.ByteArrayOutputStream()
    bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, byteArrayOutputStream)
    val byteArray = byteArrayOutputStream.toByteArray()
    return android.util.Base64.encodeToString(byteArray, android.util.Base64.DEFAULT)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PelangganVisionScreen(viewModel: JasaInViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val result = viewModel.arVisionResult
    val isAnalyzing = viewModel.isArAnalyzing

    var capturedBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var capturedBase64 by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        if (viewModel.arCameraLogs.isEmpty()) {
            viewModel.addArCameraLog("Memulai modul asisten JASAin-AR Vision Expert...")
            viewModel.addArCameraLog("Sensor kamera HP: SIAP.")
            viewModel.addArCameraLog("Engine pengenalan objek & klasifikasi visual: AKTIF.")
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            capturedBitmap = bitmap
            capturedBase64 = bitmapToBase64(bitmap)
            viewModel.addArCameraLog("Kamera HP sukses mengambil gambar: ${bitmap.width}x${bitmap.height} px.")
        } else {
            viewModel.addArCameraLog("Pengambilan foto dibatalkan oleh pengguna atau sensor gagal merespons.", isError = true)
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val bitmap = android.graphics.BitmapFactory.decodeStream(inputStream)
                if (bitmap != null) {
                    capturedBitmap = bitmap
                    capturedBase64 = bitmapToBase64(bitmap)
                    viewModel.addArCameraLog("Gambar galeri sukses dimuat dari URI: $uri.")
                } else {
                    viewModel.addArCameraLog("File terpilih dari galeri gagal dikonversi ke Bitmap.", isError = true)
                }
            } catch (e: Exception) {
                viewModel.addArCameraLog("Terjadi pengecualian saat memuat gambar galeri: ${e.message}.", isError = true)
                android.widget.Toast.makeText(context, "Gagal memuat gambar dari galeri: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            }
        } else {
            viewModel.addArCameraLog("Pemilihan gambar dari galeri dibatalkan oleh pengguna.")
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.addArCameraLog("Izin akses kamera (CAMERA) DSETUJUI oleh pengguna.")
            try {
                viewModel.addArCameraLog("Mengaktifkan jendela bidik kamera perangkat...")
                cameraLauncher.launch(null)
            } catch (e: Exception) {
                viewModel.addArCameraLog("Kesalahan inisialisasi modul kamera: ${e.message}.", isError = true)
                android.widget.Toast.makeText(context, "Gagal membuka kamera: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            }
        } else {
            viewModel.addArCameraLog("Izin kamera ditolak oleh pengguna. Tidak dapat memulai pengambilan gambar.", isError = true)
            android.widget.Toast.makeText(context, "Izin kamera diperlukan untuk mengambil foto.", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    val presets = listOf(
        Triple(
            "Pipa Wastafel Bocor",
            com.example.R.drawable.cat_rumah_tangga_1782034913734,
            "Pipa saluran pembuangan di bawah wastafel bocor dan terus meneteskan air."
        ),
        Triple(
            "Kulkas/AC Mati",
            com.example.R.drawable.cat_elektronik_1782034929844,
            "Evaporator AC kotor, berdebu tebal, dan udara tidak dingin sama sekali."
        ),
        Triple(
            "Plafon Atap Rembes",
            com.example.R.drawable.cat_rumah_tangga_1782034913734,
            "Plafon gypsum ruang tamu kecokelatan dan timbul flek rembesan air hujan."
        )
    )

    var selectedPresetIndex by remember { mutableStateOf<Int?>(0) }
    var customUrlInput by remember { mutableStateOf("") }
    var userQueryInput by remember { mutableStateOf("Berapa estimasi ukuran kerusakan ini, tingkat keparahannya, dan apakah penanganan pertamanya?") }

    Scaffold(
        topBar = {
            JasaInTopAppBar(
                title = "JASAin-AR Vision Expert",
                onBackClick = { viewModel.navigateTo("PELANGGAN_HOME") }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Intro Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(MaterialTheme.colorScheme.primary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SmartToy,
                            contentDescription = "Vision AI",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "Selamat datang di JASAin-AR Vision!",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Gunakan asisten multimodal kami untuk menganalisis foto kerusakan, mengukur skala visual, dan merekomendasikan solusi instan.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }

            // Preview & Input Section
            Text("Langkah 1: Pilih atau Masukkan Gambar", fontWeight = FontWeight.Bold, fontSize = 13.sp)

            Text("Pilih dari Skenario Kerusakan Preset:", fontSize = 11.sp, color = Color.Gray)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                presets.forEachIndexed { index, (title, resId, desc) ->
                    val isSelected = selectedPresetIndex == index
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                selectedPresetIndex = index
                                customUrlInput = ""
                                capturedBitmap = null
                                capturedBase64 = null
                                viewModel.addArCameraLog("Memilih gambar preset: '${presets[index].first}'")
                            }
                            .testTag("preset_select_$index"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = if (index == 0) Icons.Default.Build else Icons.Default.Settings,
                                contentDescription = title,
                                modifier = Modifier.size(20.dp),
                                tint = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(title, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                }
            }

            Text("Atau Ambil Foto Langsung Menggunakan Kamera HP / Pilih Galeri:", fontSize = 11.sp, color = Color.Gray)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        viewModel.addArCameraLog("Menginisialisasi modul kamera...")
                        val hasCameraPermission = androidx.core.content.ContextCompat.checkSelfPermission(
                            context,
                            android.Manifest.permission.CAMERA
                        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

                        if (hasCameraPermission) {
                            try {
                                viewModel.addArCameraLog("Membuka jendela bidik kamera (TakePicturePreview)...")
                                cameraLauncher.launch(null)
                            } catch (e: Exception) {
                                viewModel.addArCameraLog("Gagal meluncurkan kamera: ${e.message}", isError = true)
                                android.widget.Toast.makeText(context, "Gagal membuka kamera: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                            }
                        } else {
                            viewModel.addArCameraLog("Meminta izin akses CAMERA dari sistem Android...")
                            permissionLauncher.launch(android.Manifest.permission.CAMERA)
                        }
                        selectedPresetIndex = null
                        customUrlInput = ""
                    },
                    modifier = Modifier.weight(1f).testTag("vision_camera_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.PhotoCamera, contentDescription = "Camera Icon")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Ambil Kamera", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        try {
                            viewModel.addArCameraLog("Membuka pemilih media galeri sistem...")
                            galleryLauncher.launch("image/*")
                        } catch (e: Exception) {
                            viewModel.addArCameraLog("Gagal meluncurkan pemilih galeri: ${e.message}", isError = true)
                            android.widget.Toast.makeText(context, "Gagal membuka galeri: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                        }
                        selectedPresetIndex = null
                        customUrlInput = ""
                    },
                    modifier = Modifier.weight(1f).testTag("vision_gallery_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Image, contentDescription = "Gallery Icon")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Pilih Galeri", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                if (capturedBitmap != null) {
                    Button(
                        onClick = {
                            capturedBitmap = null
                            capturedBase64 = null
                            selectedPresetIndex = 0
                            viewModel.addArCameraLog("Mengatur ulang pratinjau gambar ke preset pertama.")
                        },
                        modifier = Modifier.weight(1f).testTag("vision_clear_camera_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Clear Camera")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Hapus Foto", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Text("Atau Tempelkan Tautan (URL) Gambar Kustom Anda:", fontSize = 11.sp, color = Color.Gray)
            OutlinedTextField(
                value = customUrlInput,
                onValueChange = {
                    customUrlInput = it
                    if (it.isNotBlank()) {
                        selectedPresetIndex = null
                        capturedBitmap = null
                        capturedBase64 = null
                    }
                },
                placeholder = { Text("https://example.com/foto_bocor.jpg", fontSize = 11.sp) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("vision_custom_url_input"),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp)
            )

            // Current Active Image Preview Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.DarkGray),
                    contentAlignment = Alignment.Center
                ) {
                    if (capturedBitmap != null) {
                        Image(
                            bitmap = capturedBitmap!!.asImageBitmap(),
                            contentDescription = "Foto Kamera JASAin-AR",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.6f))
                                .align(Alignment.BottomCenter)
                                .padding(10.dp)
                        ) {
                            Text(
                                "Foto berhasil diambil menggunakan kamera Jasain AR Vision Expert.",
                                color = Color.White,
                                fontSize = 11.sp,
                                maxLines = 2
                            )
                        }
                    } else if (selectedPresetIndex != null) {
                        Image(
                            painter = androidx.compose.ui.res.painterResource(presets[selectedPresetIndex!!].second),
                            contentDescription = presets[selectedPresetIndex!!].first,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.6f))
                                .align(Alignment.BottomCenter)
                                .padding(10.dp)
                        ) {
                            Text(
                                presets[selectedPresetIndex!!].third,
                                color = Color.White,
                                fontSize = 11.sp,
                                maxLines = 2
                            )
                        }
                    } else if (customUrlInput.isNotBlank()) {
                        AsyncImage(
                            model = customUrlInput,
                            contentDescription = "Custom visual input",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.PhotoCamera, "Belum ada gambar", tint = Color.LightGray, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Silakan pilih preset, ambil foto kamera, atau tempelkan URL gambar kustom Anda di atas.", color = Color.LightGray, fontSize = 11.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }

                    if (isAnalyzing) {
                        ArScanningOverlay()
                    }
                }
            }

            // Query Input Fields
            Text("Langkah 2: Isikan Pertanyaan Tambahan (Opsional)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            OutlinedTextField(
                value = userQueryInput,
                onValueChange = { userQueryInput = it },
                label = { Text("Apa yang ingin Anda tanyakan?") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("vision_query_input"),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp)
            )

            // Action trigger button
            Button(
                onClick = {
                    val activeResId = selectedPresetIndex?.let { presets[it].second }
                    val activeUrl = if (selectedPresetIndex == null && capturedBitmap == null) customUrlInput else null
                    viewModel.runArVisionAnalysis(context, activeUrl, activeResId, userQueryInput, capturedBase64)
                },
                enabled = !isAnalyzing && (selectedPresetIndex != null || customUrlInput.isNotBlank() || capturedBitmap != null),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("vision_analyze_button"),
                shape = RoundedCornerShape(10.dp)
            ) {
                if (isAnalyzing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("JASAin-AR Sedang Menganalisis...", fontSize = 13.sp)
                } else {
                    Icon(Icons.Default.Stars, contentDescription = "Spark")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Lakukan Analisis Visual JASAin-AR", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Results Section
            if (result != null) {
                Text("Langkah 3: Laporan Analisis JASAin-AR Vision", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("vision_result_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Objek Terdeteksi", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                Text(result.detectedObject, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Tingkat Keparahan", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                val badgeBgColor = when (result.severityLevel.lowercase()) {
                                    "high" -> Color(0xFFfee2e2)
                                    "medium" -> Color(0xFFfef3c7)
                                    else -> Color(0xFFdcfce7)
                                }
                                val badgeTextColor = when (result.severityLevel.lowercase()) {
                                    "high" -> Color(0xFFef4444)
                                    "medium" -> Color(0xFFf59e0b)
                                    else -> Color(0xFF22c55e)
                                }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = badgeBgColor),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        result.severityLevel.uppercase(),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = badgeTextColor
                                    )
                                }
                            }
                        }

                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.4f))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Kategori Masalah", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                Text(result.issueCategory, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Skala / Dimensi Desain", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                Text(result.estimatedScale, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.4f))

                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text("Rekomendasi Layanan Mitra JASAin", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    result.recommendedService,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Button(
                                    onClick = {
                                        viewModel.updateSearchQuery(result.recommendedService)
                                        viewModel.updateSelectedCategory("")
                                        viewModel.navigateTo("PELANGGAN_HOME")
                                    },
                                    shape = RoundedCornerShape(6.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text("Cari Jasa", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.4f))

                        if (result.safetyInstruction.isNotBlank()) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7ED)),
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFEDD5)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = "Instruksi Keselamatan",
                                        tint = Color(0xFFEA580C),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            "Langkah Keamanan / Penanganan Darurat:",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFC2410C)
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            result.safetyInstruction,
                                            fontSize = 11.sp,
                                            color = Color(0xFF9A3412)
                                        )
                                    }
                                }
                            }
                        }

                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.4f))

                        Text("Catatan Lengkap Expert AI:", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        Text(
                            text = result.rawText.substringBefore("[JSON_OUTPUT]"),
                            fontSize = 12.sp,
                            lineHeight = 18.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = "Disclaimer",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Ini adalah estimasi berbasis analisis visual, mohon tunggu teknisi profesional kami untuk pengecekan fisik.",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // AR Camera Developer Diagnostics Logs Card
            var isLogsExpanded by remember { mutableStateOf(false) }
            val cameraLogs = viewModel.arCameraLogs

            Card(
                modifier = Modifier.fillMaxWidth().testTag("ar_diagnostics_console_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isLogsExpanded = !isLogsExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.BugReport,
                                contentDescription = "Developer Logs",
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Konsol Diagnostik JASAin-AR (${cameraLogs.size} Log)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            imageVector = if (isLogsExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = if (isLogsExpanded) "Collapse Logs" else "Expand Logs",
                            tint = Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    if (isLogsExpanded) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp)
                                .background(Color.Black, RoundedCornerShape(6.dp))
                                .padding(8.dp)
                        ) {
                            if (cameraLogs.isEmpty()) {
                                Text(
                                    text = "Belum ada log aktivitas kamera / AI. Jalankan analisis atau berinteraksi dengan kamera untuk memulai pencatatan log.",
                                    color = Color.LightGray,
                                    fontSize = 11.sp,
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                )
                            } else {
                                androidx.compose.foundation.lazy.LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    items(cameraLogs.toList()) { logLine ->
                                        Text(
                                            text = logLine,
                                            color = if (logLine.contains("🔴")) Color(0xFFEF4444) else if (logLine.contains("🟢")) Color(0xFF10B981) else Color.White,
                                            fontSize = 10.sp,
                                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    viewModel.addArCameraLog("Menginisialisasi ulang sensor AR dan kamera...")
                                    viewModel.addArCameraLog("Status kamera: AKTIF. Sensor siap.")
                                },
                                modifier = Modifier.weight(1f).height(32.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                shape = RoundedCornerShape(4.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("Inisialisasi Sensor", fontSize = 10.sp)
                            }
                            Button(
                                onClick = {
                                    viewModel.arCameraLogs.clear()
                                    viewModel.addArCameraLog("Konsol log dibersihkan.")
                                },
                                modifier = Modifier.weight(1f).height(32.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.outline),
                                shape = RoundedCornerShape(4.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("Bersihkan Log", fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CustomFilterChip(
    selected: Boolean,
    onClick: () -> Unit,
    label: String,
    modifier: Modifier = Modifier
) {
    val containerColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
    val contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
    val borderColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(containerColor)
            .border(BorderStroke(1.dp, borderColor), RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = contentColor
        )
    }
}

@Composable
fun ArScanningOverlay() {
    val infiniteTransition = rememberInfiniteTransition(label = "ar_scanner")
    
    // Laser scan position animation (up and down)
    val laserYProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_y"
    )

    // Pulse animation for the scanning texts
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.4f)) // translucent dim overlay
    ) {
        // Hologram border effect
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            val pad = 12.dp.toPx()
            val len = 24.dp.toPx()
            val stroke = 3.dp.toPx()
            val color = Color(0xFF10B981) // Neon Green Emerald

            // Top-left corner
            drawRect(color, size = androidx.compose.ui.geometry.Size(len, stroke), topLeft = androidx.compose.ui.geometry.Offset(pad, pad))
            drawRect(color, size = androidx.compose.ui.geometry.Size(stroke, len), topLeft = androidx.compose.ui.geometry.Offset(pad, pad))

            // Top-right corner
            drawRect(color, size = androidx.compose.ui.geometry.Size(len, stroke), topLeft = androidx.compose.ui.geometry.Offset(size.width - pad - len, pad))
            drawRect(color, size = androidx.compose.ui.geometry.Size(stroke, len), topLeft = androidx.compose.ui.geometry.Offset(size.width - pad, pad))

            // Bottom-left corner
            drawRect(color, size = androidx.compose.ui.geometry.Size(len, stroke), topLeft = androidx.compose.ui.geometry.Offset(pad, size.height - pad))
            drawRect(color, size = androidx.compose.ui.geometry.Size(stroke, len), topLeft = androidx.compose.ui.geometry.Offset(pad, size.height - pad - len))

            // Bottom-right corner
            drawRect(color, size = androidx.compose.ui.geometry.Size(len, stroke), topLeft = androidx.compose.ui.geometry.Offset(size.width - pad - len, size.height - pad))
            drawRect(color, size = androidx.compose.ui.geometry.Size(stroke, len), topLeft = androidx.compose.ui.geometry.Offset(size.width - pad, size.height - pad - len))

            // Drawing the laser beam line
            val y = pad + (size.height - 2 * pad) * laserYProgress
            drawLine(
                color = color,
                start = androidx.compose.ui.geometry.Offset(pad, y),
                end = androidx.compose.ui.geometry.Offset(size.width - pad, y),
                strokeWidth = 4.dp.toPx(),
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
        }

        // Animated target tracking box in center
        Box(
            modifier = Modifier
                .size(100.dp)
                .align(Alignment.Center)
                .background(Color(0xFF10B981).copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                .border(
                    width = 1.dp,
                    color = Color(0xFF10B981).copy(alpha = pulseAlpha),
                    shape = RoundedCornerShape(8.dp)
                )
        ) {
            Icon(
                imageVector = Icons.Default.Adjust,
                contentDescription = "Tracking Focus",
                tint = Color(0xFF10B981).copy(alpha = pulseAlpha),
                modifier = Modifier
                    .size(24.dp)
                    .align(Alignment.Center)
            )
        }

        // Status text overlay
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(Color.Red, CircleShape)
                )
                Text(
                    text = "AI SCANNING ENVIRONMENT...",
                    color = Color(0xFF10B981),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(color = Color.Black, blurRadius = 4f))
                )
            }
            Text(
                text = "Mengklasifikasikan Objek & Kerusakan Properti",
                color = Color.LightGray,
                fontSize = 9.sp,
                style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(color = Color.Black, blurRadius = 4f))
            )
        }
    }
}
